import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./mobile-cad.css";
import "./brand.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  interactiveWidget: "resizes-content",
  themeColor: "#202329",
};

export const metadata: Metadata = {
  title: "Pixar Plus Print & Copy Studio — CAD · DXF · DWG · Plot",
  description: "Pixar Plus Print & Copy Studio: веб CAD за DXF и DWG, леери, уредување и PDF плотирање, на компјутер и мобилен.",
  icons: {
    icon: "/pixar-plus-logo.jpg",
    shortcut: "/pixar-plus-logo.jpg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="mk">
      <body className="antialiased">{children}</body>
    </html>
  );
}
