"use client";
import CadApp from "@/components/cad/CadApp";
export default function Home() { return <CadApp />; }
