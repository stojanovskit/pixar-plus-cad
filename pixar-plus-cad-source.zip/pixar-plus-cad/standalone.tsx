import { createRoot } from 'react-dom/client';
import CadApp from './components/cad/CadApp';
import './app/globals.css';
import './app/mobile-cad.css';
import './app/brand.css';

const root = document.getElementById('root');
if (!root) throw new Error('Недостасува работната површина.');
createRoot(root).render(<CadApp/>);
