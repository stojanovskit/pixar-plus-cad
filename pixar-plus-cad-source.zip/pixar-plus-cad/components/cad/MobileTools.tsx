"use client";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { COMMANDS, GROUPS, type CommandGroup } from '@/lib/cad/commands';
import { Check, Hand, Layers, MousePointer2, PenLine, Search, Settings, SlidersHorizontal, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { COMMAND_ICONS } from './CadRibbon';

const groupLabels: Record<CommandGroup, string> = {
  Draw: 'Цртање', Modify: 'Измени', Annotate: 'Коти и текст', Layers: 'Леери',
  Blocks: 'Блокови', Selection: 'Избор', View: 'Поглед', Manage: 'Управување', Output: 'Plot', File: 'Фајл',
};

export default function MobileTools({ onRun, active, selected, undoAvailable, redoAvailable, busy, onSearch }: {
  onRun: (command: string) => void; active: string; selected: number;
  undoAvailable: boolean; redoAvailable: boolean; busy: boolean; onSearch: () => void;
}) {
  const [open, setOpen] = useState(false), [group, setGroup] = useState<CommandGroup>('Draw');
  const categories = useRef<HTMLDivElement>(null), skipRestore = useRef(false);
  useEffect(() => {
    if (!open) return;
    const frame = requestAnimationFrame(() => categories.current?.querySelector('[data-state="active"]')?.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
    return () => cancelAnimationFrame(frame);
  }, [open, group]);
  const show = (next: CommandGroup) => { skipRestore.current = false; setGroup(next); setOpen(true); };
  const run = (command: string) => { skipRestore.current = true; setOpen(false); onRun(command); };
  return <>
    <nav className="mobile-cad-toolbar" aria-label="CAD алатки за допир">
      <button disabled={busy} aria-pressed={active === 'SELECT'} onClick={() => onRun('SELECT')}><MousePointer2 size={21}/><span>Избор</span></button>
      <button disabled={busy} aria-pressed={active === 'PAN'} onClick={() => onRun('PAN')}><Hand size={21}/><span>Pan</span></button>
      <button disabled={busy} onClick={() => show('Draw')}><PenLine size={21}/><span>Цртај</span></button>
      <button disabled={busy} onClick={() => show('Modify')}><SlidersHorizontal size={21}/><span>Измени</span></button>
      <button disabled={busy} onClick={() => onRun('LAYER')}><Layers size={21}/><span>Леери</span></button>
      <button disabled={busy} onClick={() => show('File')}><Settings size={21}/><span>Алатки</span></button>
    </nav>
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="bottom" className="mobile-tools-sheet" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => { if (skipRestore.current) e.preventDefault(); }}>
        <SheetHeader><SheetTitle>CAD алатки</SheetTitle><SheetDescription>Избери категорија и команда.</SheetDescription></SheetHeader>
        <Tabs value={group} onValueChange={value => setGroup(value as CommandGroup)} className="mobile-tools-tabs">
          <TabsList ref={categories} className="mobile-tools-categories">{GROUPS.map(value => <TabsTrigger key={value} value={value}>{groupLabels[value]}</TabsTrigger>)}</TabsList>
          {GROUPS.map(value => <TabsContent key={value} value={value} className="mobile-tools-content">
            <div className="mobile-command-grid">{COMMANDS.filter(command => command.group === value).map(command => {
              const Icon = COMMAND_ICONS[command.name] ?? Settings;
              const disabled = !!(command.selection && !selected) || (command.name === 'UNDO' && !undoAvailable) || (command.name === 'REDO' && !redoAvailable);
              return <button key={command.name} disabled={disabled} aria-label={`${command.name} — ${command.description}`} aria-pressed={active === command.name} onClick={() => run(command.name)}>
                <Icon size={22}/><strong>{command.name}</strong><span>{command.description}</span>
              </button>;
            })}</div>
          </TabsContent>)}
        </Tabs>
        <div className="mobile-tools-footer"><span>{selected ? `${selected} избрани објекти` : 'За сивите команди прво избери објекти.'}</span><button onClick={() => { skipRestore.current = true; setOpen(false); onSearch(); }}><Search size={19}/>Пребарај</button></div>
      </SheetContent>
    </Sheet>
  </>;
}

export function MobileCommandActions({ name, canFinish, canClose, onFinish, onClose, onCancel }: {
  name: string; canFinish: boolean; canClose: boolean; onFinish: () => void; onClose: () => void; onCancel: () => void;
}) {
  return <div className="mobile-command-actions" aria-label="Активна команда">
    <span>{name}</span>
    {canFinish && <button onClick={onFinish}><Check size={18}/>Заврши</button>}
    {canClose && <button onClick={onClose}>Затвори</button>}
    <button onClick={onCancel} aria-label="Откажи команда"><X size={18}/><span>Откажи</span></button>
  </div>;
}
