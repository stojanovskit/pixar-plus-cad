"use client";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { COMMANDS, resolveCommand } from '@/lib/cad/commands';
import { CadGestures, pointerHitRadius, pointerTapSlop, resizeView } from '@/lib/cad/gestures';
import { Bounds, bounds, center, demoDrawing, distance, Drawing, Entity, hit, IDENTITY, Matrix, newDrawing, Point, point, polyline, rotation, scaling, transformEntities, translation, uid } from '@/lib/cad/model';
import { defaultPlot, download, exportDxf, PlotConfig, plotLayout, plotSvg } from '@/lib/cad/output';
import { parseProject, serializeProject } from '@/lib/cad/project';
import { fitView, screenToWorld, View } from '@/lib/cad/render';
import { SpatialIndex } from '@/lib/cad/spatial';
import { Check, CheckCheck, ChevronDown, CircleHelp, Command, Copy, Crosshair, Download, Eye, EyeOff, FilePlus2, FlipHorizontal2, FolderOpen, Grid3X3, Layers, LoaderCircle, Lock, LockOpen, Magnet, Maximize, Move, PanelLeftClose, PanelRightClose, Plus, Printer, Redo2, RotateCw, Scaling, SlidersHorizontal, Trash2, TriangleAlert, Type, Undo2, X, ZoomIn, ZoomOut } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import CadRibbon, { CadCommandPalette } from './CadRibbon';
import { Picker, ToolButton } from './Controls';
import PlotDialog from './PlotDialog';
import MobileTools, { MobileCommandActions } from './MobileTools';
import useCadViewport from './useCadViewport';
import useAdvancedCad, { advancedNames, advancedPrompt } from './useAdvancedCad';
import Workspace, { Box, Tool, transformPreview } from './Workspace';
const toolNames: Record<Tool, string> = { select: 'Селекција', pan: 'Pan', line: 'Линија', polyline: 'Полилинија', rectangle: 'Правоаголник', circle: 'Круг', arc: 'Лак', text: 'Текст', move: 'Move', copy: 'Copy', rotate: 'Rotate', scale: 'Scale', mirror: 'Mirror', measure: 'Растојание', dimension: 'Кота', window: 'Plot прозорец', ...advancedNames } as Record<Tool, string>;
const editTools: Tool[] = ['move', 'copy', 'rotate', 'scale', 'mirror'];
function number(n: number) { return Number.isFinite(n) ? n.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '—'; }
function promptFor(tool: Tool, n: number): string {
    const advanced = advancedPrompt(tool, n);
    if (advanced)
        return advanced;
    if (tool === 'select')
        return 'Кликни објект · Shift за повеќе · повлечи за прозорец';
    if (tool === 'pan')
        return 'Повлечи за поместување на погледот';
    if (editTools.includes(tool)) {
        if (!n)
            return tool === 'rotate' || tool === 'scale' ? 'Избери центар' : 'Избери базна точка';
        if (tool === 'rotate' || tool === 'scale')
            return n === 1 ? 'Избери референтна точка' : 'Избери нова точка';
        return tool === 'mirror' ? 'Избери втора точка на оската' : 'Избери целна точка';
    }
    if (tool === 'text')
        return 'Избери позиција за текстот';
    if (tool === 'arc')
        return ['Избери центар', 'Избери почеток на лакот', 'Избери крај на лакот'][n] ?? '';
    if (tool === 'polyline')
        return n ? 'Следна точка · Enter за крај · C за затворање' : 'Избери прва точка';
    return n ? (tool === 'circle' ? 'Избери радиус' : tool === 'dimension' ? 'Избери втора точка за кота' : 'Избери втора точка') : 'Избери прва точка';
}
export default function CadApp() {
    const keyboardOpen = useCadViewport();
    const [multiSelect, setMultiSelect] = useState(false);
    const gestures = useRef(new CadGestures()), pointerType = useRef('mouse');
    const [drawing, setDrawing] = useState<Drawing>(() => demoDrawing());
    const [selection, setSelection] = useState<Set<string>>(new Set());
    const [activeLayer, setActiveLayer] = useState('A-WALL');
    const [tool, setTool] = useState<Tool>('select');
    const [draft, setDraft] = useState<Point[]>([]);
    const [cursor, setCursor] = useState<Point | null>(null);
    const [snapped, setSnapped] = useState(false);
    const [view, setView] = useState<View>({ x: 0, y: 0, scale: .05 });
    const [size, setSize] = useState({ w: 0, h: 0 });
    const [grid, setGrid] = useState(true);
    const [snap, setSnap] = useState(true);
    const [ortho, setOrtho] = useState(false);
    const [box, setBox] = useState<Box | null>(null);
    const [dirty, setDirty] = useState(false);
    const [historyVersion, setHistoryVersion] = useState(0);
    const [command, setCommand] = useState('');
    const [lastMessage, setLastMessage] = useState('Подготвено. Отвори DXF / DWG или работи на примерот.');
    const [busy, setBusy] = useState('');
    const [plotOpen, setPlotOpen] = useState(false);
    const [plotWindow, setPlotWindow] = useState<Bounds>();
    const [helpOpen, setHelpOpen] = useState(false);
    const [warningOpen, setWarningOpen] = useState(false);
    const [newLayerOpen, setNewLayerOpen] = useState(false);
    const [newLayerName, setNewLayerName] = useState('');
    const [newLayerColor, setNewLayerColor] = useState('#72dcd2');
    const [textEdit, setTextEdit] = useState<{
        position: Point;
        id?: string;
    } | null>(null);
    const [textValue, setTextValue] = useState('');
    const [textHeight, setTextHeight] = useState('2.5');
    const [textAngle, setTextAngle] = useState('0');
    const [sidePanel, setSidePanel] = useState<'layers' | 'properties' | null>(null);
    const [layerFilter, setLayerFilter] = useState('');
    const [leftOpen, setLeftOpen] = useState(true);
    const [rightOpen, setRightOpen] = useState(true);
    const [pending, setPending] = useState<{
        label: string;
        run: () => void;
    } | null>(null);
    const [dx, setDx] = useState('0'), [dy, setDy] = useState('0'), [angle, setAngle] = useState('90'), [factor, setFactor] = useState('1');
    const [measurement, setMeasurement] = useState('');
    const [paletteOpen, setPaletteOpen] = useState(false), [historyOpen, setHistoryOpen] = useState(false), [commandLog, setCommandLog] = useState<string[]>([]), [space, setSpace] = useState<'model' | 'layout'>('model'), [pageConfig, setPageConfig] = useState<PlotConfig>(defaultPlot), [hidden, setHidden] = useState<Set<string>>(new Set()), [suggestion, setSuggestion] = useState(0);
    const issuedRef = useRef<string[]>([]), issuedIndex = useRef(-1), repeatRef = useRef(''), previousView = useRef<View | null>(null);
    const hostRef = useRef<HTMLDivElement>(null), fileRef = useRef<HTMLInputElement>(null), commandRef = useRef<HTMLInputElement>(null), workerRef = useRef<Worker | null>(null), timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null), undoRef = useRef<Drawing[]>([]), redoRef = useRef<Drawing[]>([]), spaceRef = useRef(false), clipboardRef = useRef<Entity[]>([]), fitPending = useRef(true);
    const selectable = useMemo(() => drawing.entities.filter(e => { const l = drawing.layers.find(l => l.name === e.layer); return l?.visible && !l.locked && !hidden.has(e.id); }), [drawing, hidden]);
    const spatial = useMemo(() => new SpatialIndex(selectable), [selectable]);
    const selected = useMemo(() => drawing.entities.filter(e => selection.has(e.id)), [drawing.entities, selection]);
    const selectedBounds = useMemo(() => bounds(selected), [selected]);
    const visibleCount = useMemo(() => drawing.entities.filter(e => drawing.layers.find(l => l.name === e.layer)?.visible !== false).length, [drawing]);
    const currentLayer = drawing.layers.find(l => l.name === activeLayer) ?? drawing.layers[0];
    const report = useCallback((s: string) => { setLastMessage(s); setCommandLog(log => [...log, s].slice(-200)); }, []);
    const commit = useCallback((next: Drawing, message: string) => {if(next.entities.length>150000){toast.error('Лимитот е 150 000 објекти.');return;}
        undoRef.current.push(drawing);
        if (undoRef.current.length > 40)
            undoRef.current.shift();
        redoRef.current = [];
        setDrawing(next);
        setDirty(true);
        setHistoryVersion(n => n + 1);
        report(message);
    }, [drawing, report]);
    const undo = () => {
        const prev = undoRef.current.pop();
        if (!prev)
            return;
        redoRef.current.push(drawing);
        setDrawing(prev);
        setSelection(new Set());
        setDraft([]);
        setDirty(true);
        setHistoryVersion(n => n + 1);
        report('Undo · промената е вратена.');
    };
    const redo = () => {
        const next = redoRef.current.pop();
        if (!next)
            return;
        undoRef.current.push(drawing);
        setDrawing(next);
        setSelection(new Set());
        setDraft([]);
        setDirty(true);
        setHistoryVersion(n => n + 1);
        report('Redo · промената е повторена.');
    };
    const fit = () => { previousView.current = view; const b = bounds(drawing.entities.filter(e => drawing.layers.find(l => l.name === e.layer)?.visible !== false)); setView(fitView(b, size.w, size.h)); };
    useEffect(() => {
        const el = hostRef.current;
        if (!el)
            return;
        let previous = { w: 0, h: 0 };
        const obs = new ResizeObserver(([entry]) => {
            const { width, height } = entry.contentRect, next = { w: Math.max(1, width), h: Math.max(1, height) };
            if (previous.w && previous.h && !fitPending.current) {
                const old = previous;
                setView(v => resizeView(v, old, next));
            }
            previous = next;
            setSize(next);
        });
        obs.observe(el);
        return () => obs.disconnect();
    }, []);
    useEffect(() => {
        if (fitPending.current && size.w > 100 && size.h > 100) {
            setView(fitView(bounds(drawing.entities), size.w, size.h));
            fitPending.current = false;
        }
    }, [drawing, size]);
    useEffect(() => () => {
        workerRef.current?.terminate();
        if (timeoutRef.current)
            clearTimeout(timeoutRef.current);
    }, []);
    const viewBounds: Bounds = { ...(() => { const a = screenToWorld(point(0, size.h), view), b = screenToWorld(point(size.w, 0), view); return { minX: a.x, minY: a.y, maxX: b.x, maxY: b.y }; })() };
    function activate(next: Tool) {
        setSpace('model');
        if (editTools.includes(next) && !selected.length) {
            toast.info('Прво селектирај еден или повеќе објекти.');
            return;
        }
        gestures.current.reset();
        setSidePanel(null);
        setTool(next);
        setDraft([]);
        setBox(null);
        report(promptFor(next, 0));
    }
    function cancel() { gestures.current.reset(); setDraft([]); setBox(null); setTool('select'); report('Командата е откажана.'); }
    function zoom(mult: number, p: Point = point(size.w / 2, size.h / 2)) { previousView.current = view; setView(v => { const w = screenToWorld(p, v), s = Math.max(1e-7, Math.min(1e6, v.scale * mult)); return { scale: s, x: p.x - w.x * s, y: p.y + w.y * s }; }); }
    function modifySelected(m: Matrix, copy = false) {
        const ids = new Set(selected.filter(e => !drawing.layers.find(l => l.name === e.layer)?.locked).map(e => e.id));
        if (!ids.size) {
            toast.info('Нема избрани објекти што можат да се менуваат.');
            return;
        }
        const next = transformEntities(drawing.entities, ids, m, copy);
        commit({ ...drawing, entities: next }, `${copy ? 'Копирани' : 'Изменети'} ${ids.size} објекти.`);
        if (copy)
            setSelection(new Set(next.slice(drawing.entities.length).map(e => e.id)));
        setDraft([]);
        setTool('select');
    }
    function numericTransform(type: 'move' | 'rotate' | 'scale', a?: number, b?: number) {
        const n = a ?? Number(type === 'move' ? dx : type === 'rotate' ? angle : factor), n2 = b ?? Number(dy);
        if (!Number.isFinite(n) || (type === 'move' && !Number.isFinite(n2)) || (type === 'scale' && n <= 0)) {
            toast.error('Внеси валидни броеви. Scale мора да биде поголем од 0.');
            return;
        }
        const c = draft[0] ?? center(selectedBounds);
        modifySelected(type === 'move' ? translation(n, n2) : type === 'rotate' ? rotation(n, c) : scaling(n, c));
    }
    function erase() {
        if (!selection.size)
            return;
        const ids = new Set(selected.filter(e => !drawing.layers.find(l => l.name === e.layer)?.locked).map(e => e.id));
        commit({ ...drawing, entities: drawing.entities.filter(e => !ids.has(e.id)) }, `Избришани ${ids.size} објекти.`);
        setSelection(new Set());
        setDraft([]);
        setTool('select');
    }
    function save() { download(exportDxf(drawing), drawing.name.replace(/[^\p{L}\p{N}\s._-]/gu, '_') + '.dxf', 'application/dxf'); setDirty(false); report('DXF е подготвен за преземање.'); toast.success('Зачуван DXF цртеж.'); }
    function saveProject() { download(serializeProject(drawing), drawing.name.replace(/[^\p{L}\p{N}\s._-]/gu, '_') + '.nookcad', 'application/json'); setDirty(false); report('Pixar Plus CAD проектот е зачуван со дефинициите на блоковите и групите.'); }
    function protect(label: string, run: () => void) {
        if (dirty)
            setPending({ label, run });
        else
            run();
    }
    function replaceDrawing(next: Drawing) { setHidden(new Set()); setSpace('model'); setPageConfig(defaultPlot); undoRef.current = []; redoRef.current = []; setDrawing(next); setSelection(new Set()); setActiveLayer(next.layers.find(l => l.visible && !l.locked)?.name ?? next.layers[0].name); setDraft([]); setTool('select'); setDirty(false); setPlotWindow(undefined); setMeasurement(''); setHistoryVersion(n => n + 1); fitPending.current = true; setView(fitView(bounds(next.entities), size.w, size.h)); report(`${next.name} · ${next.entities.length} објекти · ${next.layers.length} леери`); }
    function cancelImport() {
        workerRef.current?.terminate();
        workerRef.current = null;
        if (timeoutRef.current)
            clearTimeout(timeoutRef.current);
        setBusy('');
        report('Отворањето е откажано.');
    }
    async function importFile(file: File) {
        if (file.size > 50 * 1024 * 1024) {
            toast.error('Максималната големина во оваа верзија е 50 MB.');
            return;
        }
        if (/\.nookcad$/i.test(file.name)) {
            try {
                replaceDrawing(parseProject(await file.text()));
                toast.success('Отворен проект ' + file.name);
            }
            catch (e) {
                toast.error(e instanceof Error ? e.message : 'Невалиден проект.');
            }
            return;
        }
        if (!/\.(dxf|dwg)$/i.test(file.name)) {
            toast.error('Избери .dxf или .dwg фајл.');
            return;
        }
        cancelImport();
        setBusy('Се отвора ' + file.name + '…');
        try {
            const worker = new Worker(new URL('../../lib/cad/import.worker.ts', import.meta.url), { type: 'module' });
            workerRef.current = worker;
            const finish = () => {
                worker.terminate();
                workerRef.current = null;
                if (timeoutRef.current)
                    clearTimeout(timeoutRef.current);
                setBusy('');
            };
            worker.onmessage = e => {
                if (e.data.progress)
                    setBusy(e.data.progress);
                else if (e.data.error) {
                    finish();
                    toast.error(e.data.error, { duration: 10000 });
                    report(e.data.error);
                }
                else if (e.data.drawing) {
                    finish();
                    replaceDrawing(e.data.drawing);
                    toast.success('Отворен ' + file.name);
                    if (e.data.drawing.warnings.length)
                        setWarningOpen(true);
                }
            };
            worker.onerror = () => { finish(); toast.error('Читачот не се вчита. Освежи ја страницата и пробај повторно.'); };
            timeoutRef.current = setTimeout(() => { finish(); toast.error('Читањето трае предолго. Пробај помал фајл или ASCII DXF.'); }, 120000);
            worker.postMessage({ buffer: await file.arrayBuffer(), name: file.name });
        }
        catch (error) {
            cancelImport();
            toast.error(error instanceof Error ? error.message : 'Неуспешно отворање.');
        }
    }
    function updateLayer(name: string, changes: Partial<Drawing['layers'][number]>) {
        commit({ ...drawing, layers: drawing.layers.map(l => l.name === name ? { ...l, ...changes } : l) }, 'Леерот е ажуриран.');
        if (changes.visible === false || changes.locked)
            setSelection(new Set(selected.filter(e => e.layer !== name).map(e => e.id)));
    }
    function batchLayers(changes: {
        name: string;
        visible?: boolean;
        locked?: boolean;
        plot?: boolean;
    }[]) {
        if (!Array.isArray(changes) || changes.some(x => !drawing.layers.some(l => l.name === x.name) || ['visible', 'locked', 'plot'].some(k => (x as any)[k] !== undefined && typeof (x as any)[k] !== 'boolean')))
            throw Error('Invalid layer changes');
        commit({ ...drawing, layers: drawing.layers.map(l => ({ ...l, ...changes.find(x => x.name === l.name) })) }, 'Леерите се ажурирани.');
        setSelection(new Set());
        return { updated: changes.length };
    }
    function appendEntities(list: Entity[], message: string) {
        if (!currentLayer?.visible || currentLayer.locked) {
            toast.error('Активниот леер е скриен или заклучен. Избери друг леер.');
            setDraft([]);
            return;
        }
        commit({ ...drawing, entities: [...drawing.entities, ...list] }, message);
    }
    function finishPolyline(closed = false) {
        if (draft.length < 2) {
            cancel();
            return;
        }
        appendEntities([polyline(draft, activeLayer, closed)], 'Додадена полилинија.');
        setDraft([]);
        setTool('select');
    }
    const advanced = useAdvancedCad({ drawing, selected, selection, activeLayer, tool, draft, view, commit, append: appendEntities, setSelection, setActiveLayer, setTool, setDraft, report, hidden, setHidden, find: p => spatial.candidates(p, pointerHitRadius(pointerType.current) / view.scale).reverse().find(e => hit(e, p, pointerHitRadius(pointerType.current) / view.scale)), fitBounds: b => { previousView.current = view; setView(fitView(b, size.w, size.h)); } });
    function acceptPoint(p: Point) {
        if (advanced.consumePoint(p))
            return;
        if (editTools.includes(tool)) {
            if (!selected.length) {
                cancel();
                return;
            }
            if (!draft.length) {
                setDraft([p]);
                return;
            }
            if ((tool === 'rotate' || tool === 'scale') && draft.length === 1) {
                if (distance(p, draft[0]) < 1e-9) {
                    toast.info('Референтната точка мора да се разликува од центарот.');
                    return;
                }
                setDraft([...draft, p]);
                return;
            }
            const m = transformPreview(tool, draft, p);
            if (m)
                modifySelected(m, tool === 'copy' || tool === 'mirror');
            return;
        }
        if (tool === 'text') {
            setTextEdit({ position: p });
            setTextValue('');
            setTextHeight(String(Math.max(2.5, (bounds(drawing.entities).maxX - bounds(drawing.entities).minX) / 100)));
            setTextAngle('0');
            return;
        }
        if (tool === 'polyline') {
            setDraft([...draft, p]);
            return;
        }
        if (!draft.length) {
            setDraft([p]);
            return;
        }
        const a = draft[0];
        if (tool === 'line') {
            if (distance(a, p) < 1e-9)
                return;
            appendEntities([polyline([a, p], activeLayer)], 'Додадена линија.');
            setDraft([p]);
        }
        else if (tool === 'rectangle') {
            appendEntities([polyline([a, point(p.x, a.y), p, point(a.x, p.y)], activeLayer, true)], 'Додаден правоаголник.');
            setDraft([]);
        }
        else if (tool === 'circle') {
            if (distance(a, p) < 1e-9)
                return;
            appendEntities([{ id: uid(), kind: 'circle', layer: activeLayer, matrix: [...IDENTITY], center: a, radius: distance(a, p) }], 'Додаден круг.');
            setDraft([]);
        }
        else if (tool === 'arc') {
            if (draft.length === 1) {
                setDraft([...draft, p]);
                return;
            }
            appendEntities([{ id: uid(), kind: 'arc', layer: activeLayer, matrix: [...IDENTITY], center: a, radius: distance(a, draft[1]), start: Math.atan2(draft[1].y - a.y, draft[1].x - a.x), end: Math.atan2(p.y - a.y, p.x - a.x) }], 'Додаден лак.');
            setDraft([]);
        }
        else if (tool === 'measure') {
            const s = `${number(distance(a, p))} ${drawing.unit} · ΔX ${number(p.x - a.x)} · ΔY ${number(p.y - a.y)}`;
            setMeasurement(s);
            report('Растојание: ' + s);
            setDraft([]);
            setTool('select');
            toast.info('Растојание: ' + s, { duration: 7000 });
        }
        else if (tool === 'dimension') {
            const len = distance(a, p);
            if (!len)
                return;
            const off = 24 / view.scale, u = point((p.x - a.x) / len, (p.y - a.y) / len), n = point(-u.y, u.x), a2 = point(a.x + n.x * off, a.y + n.y * off), p2 = point(p.x + n.x * off, p.y + n.y * off), s = 6 / view.scale, h = 12 / view.scale, list = [polyline([a, a2, p2, p], activeLayer), polyline([point(a2.x - s, a2.y - s), point(a2.x + s, a2.y + s)], activeLayer), polyline([point(p2.x - s, p2.y - s), point(p2.x + s, p2.y + s)], activeLayer), { id: uid(), kind: 'text' as const, layer: activeLayer, matrix: [...IDENTITY] as Matrix, center: point((a2.x + p2.x) / 2 + n.x * h, (a2.y + p2.y) / 2 + n.y * h), text: number(len), height: h, rotation: Math.atan2(u.y, u.x), align: 'center' as const }];
            appendEntities(list, 'Додадена кота.');
            setDraft([]);
            setTool('select');
        }
        else if (tool === 'window') {
            setPlotWindow({ minX: Math.min(a.x, p.x), minY: Math.min(a.y, p.y), maxX: Math.max(a.x, p.x), maxY: Math.max(a.y, p.y) });
            setDraft([]);
            setTool('select');
            setPlotOpen(true);
        }
    }
    function location(e: {
        clientX: number;
        clientY: number;
        currentTarget: HTMLCanvasElement;
    }) { const r = e.currentTarget.getBoundingClientRect(); return point(e.clientX - r.left, e.clientY - r.top); }
    function precise(screen: Point) {
        let p = screenToWorld(screen, view);
        const radius = pointerType.current === 'touch' ? 18 : 10;
        let found = snap ? spatial.snap(p, radius / view.scale) : undefined;
        if (found)
            p = found;
        else if (ortho && draft.length && ['line', 'polyline', 'rectangle', 'move', 'copy', 'mirror', 'measure', 'leader'].includes(tool)) {
            const a = draft[draft.length - 1];
            p = Math.abs(p.x - a.x) > Math.abs(p.y - a.y) ? point(p.x, a.y) : point(a.x, p.y);
        }
        setSnapped(!!found);
        return p;
    }
    function down(e: React.PointerEvent<HTMLCanvasElement>) {
        if (busy)
            return;
        pointerType.current = e.pointerType;
        e.currentTarget.focus({ preventScroll: true });
        e.currentTarget.setPointerCapture(e.pointerId);
        const s = location(e);
        const mode = e.button === 1 || e.button === 2 || tool === 'pan' || spaceRef.current ? 'pan' : tool === 'select' ? 'select' : 'draw';
        const g = gestures.current.down(e.pointerId, s, view, mode, e.shiftKey || multiSelect, e.pointerType);
        setBox(g?.mode === 'select' ? { start: s, end: s } : null);
    }
    function move(e: React.PointerEvent<HTMLCanvasElement>) {
        const s = location(e);
        const motion = gestures.current.move(e.pointerId, s);
        if (motion.view) setView(motion.view);
        if (motion.cursor) { pointerType.current = e.pointerType; setCursor(precise(motion.cursor)); }
        if (motion.box) setBox(motion.box);
    }
    function up(e: React.PointerEvent<HTMLCanvasElement>) {
        const g = gestures.current.up(e.pointerId, view);
        if (!g)
            return;
        const s = location(e);
        if (g.mode === 'select') {
            setBox(null);
            const ids = g.extend ? new Set(selection) : new Set<string>();
            if (distance(g.start, s) < pointerTapSlop(g.pointerType)) {
                const tolerance = pointerHitRadius(g.pointerType) / view.scale;
                const p = screenToWorld(s, view), candidate = spatial.candidates(p, tolerance).reverse().find(x => hit(x, p, tolerance));
                if (candidate) {
                    if (g.extend && ids.has(candidate.id)) {
                        ids.delete(candidate.id);
                        const group = candidate.groupId ?? candidate.blockId;
                        if (group)
                            for (const e of selectable)
                                if ((e.groupId ?? e.blockId) === group)
                                    ids.delete(e.id);
                    }
                    else {
                        ids.add(candidate.id);
                        const group = candidate.groupId ?? candidate.blockId;
                        if (group)
                            for (const e of selectable)
                                if ((e.groupId ?? e.blockId) === group)
                                    ids.add(e.id);
                    }
                }
            }
            else {
                const a = screenToWorld(g.start, view), b = screenToWorld(s, view), rect = { minX: Math.min(a.x, b.x), maxX: Math.max(a.x, b.x), minY: Math.min(a.y, b.y), maxY: Math.max(a.y, b.y) }, contain = s.x >= g.start.x;
                for (const e of selectable) {
                    const eb = bounds([e]);
                    if (contain ? eb.minX >= rect.minX && eb.maxX <= rect.maxX && eb.minY >= rect.minY && eb.maxY <= rect.maxY : eb.maxX >= rect.minX && eb.minX <= rect.maxX && eb.maxY >= rect.minY && eb.minY <= rect.maxY)
                        ids.add(e.id);
                }
            }
            setSelection(ids);
            report(ids.size ? `${ids.size} избрани објекти.` : 'Подготвено за селекција.');
        }
        else if (g.mode === 'draw')
            acceptPoint(precise(s));
    }
    function pointerCancel(e: React.PointerEvent<HTMLCanvasElement>) {
        gestures.current.up(e.pointerId, view, true);
        setBox(null);
    }
    function wheel(e: WheelEvent) { e.preventDefault(); const r = (e.currentTarget as HTMLCanvasElement).getBoundingClientRect(); zoom(Math.exp(-Math.max(-150, Math.min(150, e.deltaY)) * .002), point(e.clientX - r.left, e.clientY - r.top)); }
    function editTextEntity() {
        const e = selected[0];
        if (e?.kind !== 'text')
            return;
        setTextEdit({ position: e.center ?? point(0, 0), id: e.id });
        setTextValue(e.text ?? '');
        setTextHeight(String(e.height ?? 2.5));
        setTextAngle(String((e.rotation ?? 0) * 180 / Math.PI));
    }
    function applyText() {
        const h = Number(textHeight), a = Number(textAngle);
        if (!textEdit || !textValue.trim() || !Number.isFinite(h) || h <= 0 || !Number.isFinite(a)) {
            toast.error('Внеси текст, позитивна висина и валиден агол.');
            return;
        }
        if (textEdit.id) {
            commit({ ...drawing, entities: drawing.entities.map(e => e.id === textEdit.id ? { ...e, text: textValue, height: h, rotation: a * Math.PI / 180 } : e) }, 'Текстот е изменет.');
        }
        else
            appendEntities([{ id: uid(), kind: 'text', layer: activeLayer, matrix: [...IDENTITY], center: textEdit.position, text: textValue, height: h, rotation: a * Math.PI / 180 }], 'Додаден текст.');
        setTextEdit(null);
        setDraft([]);
        setTool('select');
    }
    function addLayer() {
        const name = newLayerName.trim();
        if (!name || /[<>\/\\":;?*|=]/.test(name)) {
            toast.error('Внеси име без специјални знаци.');
            return;
        }
        if (drawing.layers.some(l => l.name.toLowerCase() === name.toLowerCase())) {
            toast.error('Веќе постои леер со тоа име.');
            return;
        }
        commit({ ...drawing, layers: [...drawing.layers, { name, color: newLayerColor, visible: true, locked: false, plot: true, lineWidth: .25 }] }, 'Додаден леер ' + name);
        setActiveLayer(name);
        setNewLayerOpen(false);
        setNewLayerName('');
    }
    function paste() {
        if (!clipboardRef.current.length)
            return;
        const c = center(bounds(clipboardRef.current)), target = cursor ?? point(c.x + 30 / view.scale, c.y - 30 / view.scale), copies = transformEntities(clipboardRef.current, new Set(clipboardRef.current.map(e => e.id)), translation(target.x - c.x, target.y - c.y), true).slice(clipboardRef.current.length);
        commit({ ...drawing, entities: [...drawing.entities, ...copies] }, 'Залепени објекти.');
        setSelection(new Set(copies.map(e => e.id)));
    }
    function finishTouchCommand(closed = false) {
        if (tool === 'polyline') finishPolyline(closed);
        else if (!advanced.finish(closed)) {
            gestures.current.reset(); setDraft([]); setBox(null); setTool('select'); report('Командата е завршена.');
        }
    }
    const touchCanFinish = ['trim', 'extend', 'matchprop', 'point'].includes(tool)
        || (tool === 'line' && draft.length > 0)
        || (['polyline', 'leader'].includes(tool) && draft.length >= 2)
        || (['spline', 'solid', 'area'].includes(tool) && draft.length >= 3);
    function runCommand(value: string) {
        gestures.current.reset();
        setBox(null);
        let str = value.trim();
        setCommand('');
        setSuggestion(0);
        if (!str) {
            if (advanced.finish())
                return;
            if (tool === 'polyline') {
                finishPolyline();
                return;
            }
            if (draft.length) {
                cancel();
                return;
            }
            str = repeatRef.current;
            if (!str)
                return;
        }
        else {
            issuedRef.current = [...issuedRef.current, str].slice(-100);
            issuedIndex.current = issuedRef.current.length;
        }
        report('Command: ' + str);
        const coord = /^(@)?(-?\d*\.?\d+)\s*[, ]\s*(-?\d*\.?\d+)$/.exec(str), polar = /^@(-?\d*\.?\d+)<(-?\d*\.?\d+)$/.exec(str);
        if (coord || polar) {
            if (tool === 'select' || tool === 'pan') {
                toast.info('Прво избери команда за цртање или трансформација.');
                return;
            }
            const last = draft[draft.length - 1] ?? point(0, 0);
            let p: Point;
            if (coord) {
                p = point(Number(coord[2]), Number(coord[3]));
                if (coord[1])
                    p = point(last.x + p.x, last.y + p.y);
            }
            else {
                const r = Number(polar![1]), a = Number(polar![2]) * Math.PI / 180;
                p = point(last.x + r * Math.cos(a), last.y + r * Math.sin(a));
            }
            acceptPoint(p);
            setCursor(p);
            return;
        }
        if (/^[-+]?\d*\.?\d+$/.test(str) && draft.length) {
            const n = Number(str);
            if (tool === 'circle' && n > 0) {
                acceptPoint(point(draft[0].x + n, draft[0].y));
                return;
            }
            if (tool === 'rotate') {
                numericTransform('rotate', n);
                return;
            }
            if (tool === 'scale') {
                numericTransform('scale', n);
                return;
            }
            if (['line', 'polyline'].includes(tool) && cursor) {
                const a = draft[draft.length - 1], len = distance(a, cursor);
                if (len > 1e-9) {
                    acceptPoint(point(a.x + (cursor.x - a.x) * n / len, a.y + (cursor.y - a.y) * n / len));
                    return;
                }
            }
        }
        const [raw, ...args] = str.split(/\s+/), cmd = resolveCommand(raw)?.name ?? raw.toUpperCase();
        if (raw.toUpperCase() === 'C' && ['polyline', 'spline', 'solid', 'area'].includes(tool) && draft.length > 1) {
            if (tool === 'polyline')
                finishPolyline(true);
            else
                advanced.finish(true);
            return;
        }
        repeatRef.current = str;
        const aliases: Record<string, Tool> = { SELECT: 'select', PAN: 'pan', LINE: 'line', PLINE: 'polyline', RECTANG: 'rectangle', CIRCLE: 'circle', ARC: 'arc', MTEXT: 'text', MOVE: 'move', COPY: 'copy', ROTATE: 'rotate', SCALE: 'scale', MIRROR: 'mirror', DIST: 'measure' };
        if (cmd === 'COPY' && args.length && selected.length) {
            const nums = args.join(' ').split(/[, ]+/).map(Number);
            if (Number.isFinite(nums[0]) && Number.isFinite(nums[1] ?? 0))
                modifySelected(translation(nums[0], nums[1] ?? 0), true);
            else
                toast.error('Внеси ΔX,ΔY.');
            return;
        }
        if (['MOVE', 'ROTATE', 'SCALE'].includes(cmd) && args.length && selected.length) {
            const nums = args.join(' ').split(/[, ]+/).map(Number);
            numericTransform(cmd.toLowerCase() as 'move' | 'rotate' | 'scale', nums[0], nums[1] ?? 0);
            return;
        }
        if (!['MODEL', 'LAYOUT', 'PREVIEW', 'PLOT', 'PAGESETUP'].includes(cmd))
            setSpace('model');
        setDraft([]);
        setBox(null);
        setTool('select');
        if (advanced.execute(cmd, args))
            return;
        if (aliases[cmd])
            activate(aliases[cmd]);
        else if (cmd === 'ZOOM') {
            const arg = args[0]?.toUpperCase();
            if (arg === 'P' || arg === 'PREVIOUS') {
                if (previousView.current) {
                    const old = previousView.current;
                    previousView.current = view;
                    setView(old);
                }
            }
            else if (arg === 'W' || arg === 'WINDOW')
                advanced.execute('ZOOMWINDOW');
            else if (arg === 'S' || arg === 'SELECTION') {
                if (selected.length) {
                    previousView.current = view;
                    setView(fitView(selectedBounds, size.w, size.h));
                }
                else
                    toast.info('Прво селектирај објекти.');
            }
            else if (arg && /^\d*\.?\d+X?$/i.test(arg))
                zoom(Number(arg.replace(/X$/i, '')));
            else
                fit();
        }
        else if (cmd === 'ZOOMPREVIOUS') {
            if (previousView.current) {
                const old = previousView.current;
                previousView.current = view;
                setView(old);
            }
            else
                report('Нема претходен поглед.');
        }
        else if (cmd === 'REGEN')
            fit();
        else if (cmd === 'ERASE')
            erase();
        else if (cmd === 'UNDO')
            undo();
        else if (cmd === 'REDO')
            redo();
        else if (cmd === 'PLOT' || cmd === 'PAGESETUP')
            setPlotOpen(true);
        else if (cmd === 'LAYOUT' || cmd === 'PREVIEW')
            setSpace('layout');
        else if (cmd === 'MODEL')
            setSpace('model');
        else if (cmd === 'OPEN')
            fileRef.current?.click();
        else if (cmd === 'SAVE')
            save();
        else if (cmd === 'SAVEAS')
            saveProject();
        else if (cmd === 'NEW')
            protect('Нов цртеж', () => replaceDrawing(newDrawing()));
        else if (cmd === 'CANCEL')
            cancel();
        else if (cmd === 'HELP')
            setHelpOpen(true);
        else if (cmd === 'COMMANDS')
            setPaletteOpen(true);
        else if (cmd === 'LAYER') {
            setLeftOpen(true);
            if (window.matchMedia('(max-width: 1024px), (max-height: 500px) and (pointer: coarse)').matches)
                setSidePanel('layers');
        }
        else if (cmd === 'LAYERNEW')
            setNewLayerOpen(true);
        else if (cmd === 'LAYERSPANEL') {
            if (window.matchMedia('(max-width: 1024px), (max-height: 500px) and (pointer: coarse)').matches)
                setSidePanel('layers');
            else
                setLeftOpen(v => !v);
        }
        else if (cmd === 'PROPERTIESPANEL') {
            if (window.matchMedia('(max-width: 1024px), (max-height: 500px) and (pointer: coarse)').matches)
                setSidePanel('properties');
            else
                setRightOpen(v => !v);
        }
        else if (cmd === 'CLEANSCREEN') {
            const open = !leftOpen && !rightOpen;
            setLeftOpen(open);
            setRightOpen(open);
        }
        else if (cmd === 'DDEDIT') {
            if (selected.length === 1 && selected[0].kind === 'text')
                editTextEntity();
            else
                toast.info('Избери точно еден текст.');
        }
        else if (cmd === 'GRID')
            setGrid(v => args[0] ? args[0] !== '0' && args[0].toUpperCase() !== 'OFF' : !v);
        else if (cmd === 'OSNAP')
            setSnap(v => args[0] ? args[0] !== '0' && args[0].toUpperCase() !== 'OFF' : !v);
        else if (cmd === 'ORTHO')
            setOrtho(v => args[0] ? args[0] !== '0' && args[0].toUpperCase() !== 'OFF' : !v);
        else if (cmd === 'COPYCLIP') {
            clipboardRef.current = selected;
            report('Копирани објекти во меѓумеморија.');
        }
        else if (cmd === 'CUTCLIP') {
            clipboardRef.current = selected;
            erase();
        }
        else if (cmd === 'PASTECLIP')
            paste();
        else
            toast.error('Командата не е имплементирана. COMMANDS го отвора каталогот на поддржаните команди.');
    }
    const suggestions = useMemo(() => command.trim() && !/[ ,@<]/.test(command) ? COMMANDS.filter(c => [c.name, ...c.aliases].some(s => s.startsWith(command.toUpperCase()))).slice(0, 7) : [], [command]);
    const visibleDrawing = useMemo(() => hidden.size ? { ...drawing, entities: drawing.entities.filter(e => !hidden.has(e.id)) } : drawing, [drawing, hidden]);
    const paperSvg = useMemo(() => space === 'layout' ? plotSvg(visibleDrawing, pageConfig, selection, viewBounds, plotWindow) : '', [space, visibleDrawing, pageConfig, selection, view.x, view.y, view.scale, size, plotWindow]);
    const paperLayout = space === 'layout' ? plotLayout(visibleDrawing, pageConfig, selection, viewBounds, plotWindow) : null;
    const actions = useRef<any>({});
    actions.current = { drawing, selection, selected, view, batchLayers, modifySelected, runCommand, undo, redo, save, erase, paste, fit, cancel, activate, protect, replaceDrawing };
    useEffect(() => {
        const key = (e: KeyboardEvent) => {
            if ((e.target as HTMLElement)?.closest('input,textarea,[contenteditable=true],[role=dialog],[role=alertdialog]'))
                return;
            const a = actions.current, ctrl = e.ctrlKey || e.metaKey;
            if (ctrl) {
                if (['z', 'y', 's', 'o', 'p', 'a', 'c', 'v', 'd', 'k'].includes(e.key.toLowerCase()))
                    e.preventDefault();
                if (e.key.toLowerCase() === 'k')
                    setPaletteOpen(true);
                if (e.key.toLowerCase() === 'z')
                    e.shiftKey ? a.redo() : a.undo();
                if (e.key.toLowerCase() === 'y')
                    a.redo();
                if (e.key.toLowerCase() === 's')
                    a.save();
                if (e.key.toLowerCase() === 'o')
                    fileRef.current?.click();
                if (e.key.toLowerCase() === 'p')
                    setPlotOpen(true);
                if (e.key.toLowerCase() === 'a')
                    setSelection(new Set(a.drawing.entities.filter((x: Entity) => { const l = a.drawing.layers.find((l: any) => l.name === x.layer); return l.visible && !l.locked; }).map((x: Entity) => x.id)));
                if (e.key.toLowerCase() === 'c') {
                    clipboardRef.current = a.selected;
                    report('Објектите се копирани во меѓумеморијата.');
                }
                if (e.key.toLowerCase() === 'v')
                    a.paste();
                if (e.key.toLowerCase() === 'd')
                    a.modifySelected(translation(30 / (actions.current.view?.scale ?? .05), 0), true);
                return;
            }
            if (e.key === 'Escape') {
                e.preventDefault();
                a.cancel();
                setSelection(new Set());
            }
            else if (e.key === 'Delete' || e.key === 'Backspace') {
                e.preventDefault();
                a.erase();
            }
            else if (e.key === ' ') {
                e.preventDefault();
                spaceRef.current = true;
            }
            else if (e.key === 'F1') {
                e.preventDefault();
                setHelpOpen(true);
            }
            else if (e.key === 'F2') {
                e.preventDefault();
                setHistoryOpen(v => !v);
            }
            else if (e.key === 'F8') {
                e.preventDefault();
                setOrtho(v => !v);
            }
            else if (e.key === 'F3') {
                e.preventDefault();
                setSnap(v => !v);
            }
            else if (e.key === 'F7') {
                e.preventDefault();
                setGrid(v => !v);
            }
            else if (e.key === 'Enter') {
                e.preventDefault();
                a.runCommand('');
            }
            else if (/^[a-z]$/i.test(e.key)) {
                e.preventDefault();
                setCommand(e.key.toUpperCase());
                commandRef.current?.focus();
            }
        };
        const up = (e: KeyboardEvent) => {
            if (e.key === ' ')
                spaceRef.current = false;
        };
        window.addEventListener('keydown', key);
        window.addEventListener('keyup', up);
        return () => { window.removeEventListener('keydown', key); window.removeEventListener('keyup', up); };
    }, [report]);
    useEffect(() => {
        const unload = (e: BeforeUnloadEvent) => {
            if (dirty) {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', unload);
        return () => window.removeEventListener('beforeunload', unload);
    }, [dirty]);
    useEffect(() => {
        const context = (document as any).modelContext;
        if (!context?.registerTool)
            return;
        const lifecycle = new AbortController();
        const register = (config: any) => {
            try {
                Promise.resolve(context.registerTool(config, { signal: lifecycle.signal })).catch(() => { });
            }
            catch { }
        };
        register({name:'get_cad_commands',title:'CAD command catalogue',description:'Read implemented CAD command names, aliases, descriptions and selection requirements.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:false},execute:()=>({commands:COMMANDS,scope:'2D drafting; commands and their available options are defined by this catalogue.'})});
        register({ name: 'get_cad_drawing', title: 'Drawing summary', description: 'Read the open drawing, its layers and current selection.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: true }, execute: () => { const a = actions.current; return { name: a.drawing.name, units: a.drawing.unit, entities: a.drawing.entities.length, layers: a.drawing.layers, selection: [...a.selection], warnings: a.drawing.warnings }; } });
        register({ name: 'set_cad_layers', title: 'Update CAD layers', description: 'Set visibility, locking or plot inclusion for existing named layers. Commits changes to the drawing.', inputSchema: { type: 'object', properties: { changes: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, visible: { type: 'boolean' }, locked: { type: 'boolean' }, plot: { type: 'boolean' } }, required: ['name'], additionalProperties: false } } }, required: ['changes'], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute: async (input: any) => { const result = actions.current.batchLayers(input.changes); await new Promise<void>(r => requestAnimationFrame(() => requestAnimationFrame(() => r()))); return result; } });
        register({ name: 'transform_cad_selection', title: 'Transform selection', description: 'Move, rotate around selection center or scale the current selection. Commits the transformation.', inputSchema: { type: 'object', properties: { operation: { enum: ['move', 'rotate', 'scale'] }, x: { type: 'number' }, y: { type: 'number' }, angle: { type: 'number' }, factor: { type: 'number' } }, required: ['operation'], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute: async (input: any) => {
                const a = actions.current;
                if (!a.selected.length)
                    throw Error('Select objects first');
                const c = center(bounds(a.selected));
                let m: Matrix;
                if (input.operation === 'move' && Number.isFinite(input.x) && Number.isFinite(input.y))
                    m = translation(input.x, input.y);
                else if (input.operation === 'rotate' && Number.isFinite(input.angle))
                    m = rotation(input.angle, c);
                else if (input.operation === 'scale' && Number.isFinite(input.factor) && input.factor > 0)
                    m = scaling(input.factor, c);
                else
                    throw Error('Invalid transformation');
                a.modifySelected(m);
                await new Promise<void>(r => requestAnimationFrame(() => requestAnimationFrame(() => r())));
                return { transformed: a.selected.length };
            } });
        return () => lifecycle.abort();
    }, []);
    const layerPanel = <div className="panel-inner"><div className="panel-heading"><div><Layers size={16}/><h2>Леери</h2><span className="count">{drawing.layers.length}</span></div><button className="quiet-icon" aria-label="Додај леер" onClick={() => setNewLayerOpen(true)}><Plus size={17}/></button></div><div className="layer-filter"><input aria-label="Пребарај леери" placeholder="Пребарај леер…" value={layerFilter} onChange={e => setLayerFilter(e.target.value)}/></div><div className="layer-columns"><span>Име / боја</span><span>Приказ · lock · plot</span></div><div className="layer-list">{drawing.layers.filter(l => l.name.toLowerCase().includes(layerFilter.toLowerCase())).map(l => <div key={l.name} className={`layer-row ${activeLayer === l.name ? 'current' : ''} ${!l.visible ? 'hidden-layer' : ''}`}><input type="color" aria-label={`Боја ${l.name}`} value={l.color} onChange={e => updateLayer(l.name, { color: e.target.value })}/><button className="layer-name" title={l.name} onClick={() => {
                if (l.locked) {
                    toast.info('Отклучи го леерот за да црташ на него.');
                    return;
                }
                setActiveLayer(l.name);
            }}>{l.name}</button><button aria-label={`${l.visible ? 'Скриј' : 'Прикажи'} ${l.name}`} className="layer-icon" onClick={() => updateLayer(l.name, { visible: !l.visible })}>{l.visible ? <Eye size={14}/> : <EyeOff size={14}/>}</button><button aria-label={`${l.locked ? 'Отклучи' : 'Заклучи'} ${l.name}`} className={`layer-icon ${l.locked ? 'locked' : ''}`} onClick={() => updateLayer(l.name, { locked: !l.locked })}>{l.locked ? <Lock size={14}/> : <LockOpen size={14}/>}</button><button aria-label={`${l.plot ? 'Исклучи' : 'Вклучи'} плотирање ${l.name}`} className={`layer-icon ${!l.plot ? 'off' : ''}`} onClick={() => updateLayer(l.name, { plot: !l.plot })}><Printer size={14}/></button></div>)}</div><div className="layer-bottom"><button onClick={() => batchLayers(drawing.layers.map(l => ({ name: l.name, visible: true })))}>Прикажи сите</button><button disabled={!selection.size} onClick={() => { const names = new Set(selected.map(e => e.layer)); batchLayers(drawing.layers.map(l => ({ name: l.name, visible: names.has(l.name) }))); }}>Изолирај избор</button></div><div className="panel-section"><p className="section-label">АКТИВЕН ЛЕЕР</p><div className="current-layer-info"><span style={{ background: currentLayer?.color }}/>{activeLayer}</div><label className="field-label">Дебелина за плотирање</label><Picker value={String(currentLayer?.lineWidth ?? .25)} label="Дебелина на линија" options={[.05, .09, .13, .15, .18, .2, .25, .3, .35, .4, .5, .6, .7, .8, 1, 1.2, 1.5, 2].map(n => ({ value: String(n), label: `${n.toFixed(2)} mm` }))} onChange={s => updateLayer(activeLayer, { lineWidth: Number(s) })}/></div><div className="file-card"><div className="file-card-head"><span className="file-format">{drawing.source === 'DEMO' ? 'DXF DEMO' : drawing.source === 'NEW' ? '2D CAD' : drawing.source}</span><span>{drawing.unit}</span></div><p>{drawing.name}</p><div className="file-counts"><span>{number(drawing.entities.length)} објекти</span><span>{visibleCount} видливи</span></div>{drawing.warnings.length > 0 && <button className="warning-link" onClick={() => setWarningOpen(true)}><TriangleAlert size={14}/>{drawing.warnings.length} забелешки при увоз</button>}<button className="text-link" onClick={() => setHelpOpen(true)}><CircleHelp size={14}/>Команди и помош</button></div></div>;
    const propertiesPanel = <div className="panel-inner"><div className="panel-heading"><div><SlidersHorizontal size={16}/><h2>Својства</h2></div><span className="count">{selected.length}</span></div><div className="selection-card"><p className="section-label">СЕЛЕКЦИЈА</p><h3>{selected.length === 1 ? (selected[0].sourceType ?? selected[0].kind).toUpperCase() : selected.length ? `${selected.length} објекти` : 'Нема избрани објекти'}</h3><p>{selected.length ? 'Измени со алатка или внеси точни вредности.' : 'Кликни на објект или повлечи прозорец за селекција.'}</p>{selected.length > 0 && <div className="selection-dimensions"><div><span>Ширина</span><strong>{number(selectedBounds.maxX - selectedBounds.minX)} {drawing.unit}</strong></div><div><span>Висина</span><strong>{number(selectedBounds.maxY - selectedBounds.minY)} {drawing.unit}</strong></div></div>}</div><div className={`property-fields ${!selected.length ? 'inactive-fields' : ''}`}><label className="field-label">Леер на избраните објекти</label><Picker label="Премести избор во леер" disabled={!selected.length} value={selected.length && selected.every(e => e.layer === selected[0].layer) ? selected[0].layer : 'mixed'} options={[{ value: 'mixed', label: selected.length ? 'Различни леери' : '—' }, ...drawing.layers.filter(l => !l.locked).map(l => ({ value: l.name, label: l.name }))]} onChange={v => {
            if (v === 'mixed')
                return;
            commit({ ...drawing, entities: drawing.entities.map(e => selection.has(e.id) ? { ...e, layer: v } : e) }, 'Леерот на изборот е изменет.');
        }}/>
 <div className="transform-section"><h3><Move size={15}/>Move <span>ΔX / ΔY</span></h3><div className="input-pair"><label>X<input aria-label="Move X" type="number" step="any" value={dx} onChange={e => setDx(e.target.value)} disabled={!selected.length}/></label><label>Y<input aria-label="Move Y" type="number" step="any" value={dy} onChange={e => setDy(e.target.value)} disabled={!selected.length}/></label></div><button className="apply-button" disabled={!selected.length} onClick={() => numericTransform('move')}>Помести</button></div>
 <div className="transform-section"><h3><RotateCw size={15}/>Rotate <span>степени</span></h3><div className="inline-field"><input aria-label="Агол на ротација" type="number" step="any" value={angle} onChange={e => setAngle(e.target.value)} disabled={!selected.length}/><button disabled={!selected.length} onClick={() => numericTransform('rotate')}>Ротирај</button></div><p className="field-note">Околу {draft[0] ? 'избраната базна точка' : 'центарот на селекцијата'}</p></div>
 <div className="transform-section"><h3><Scaling size={15}/>Scale <span>фактор</span></h3><div className="inline-field"><input aria-label="Фактор на скалирање" type="number" min="0.00001" step="any" value={factor} onChange={e => setFactor(e.target.value)} disabled={!selected.length}/><button disabled={!selected.length} onClick={() => numericTransform('scale')}>Скалирај</button></div></div>
 {selected.length === 1 && selected[0].kind === 'text' && <button className="apply-button" onClick={editTextEntity}><Type size={15}/>Измени текст</button>}
 <div className="selection-actions"><ToolButton icon={Copy} label="Копирај" small disabled={!selected.length} onClick={() => activate('copy')}/><ToolButton icon={FlipHorizontal2} label="Mirror" small disabled={!selected.length} onClick={() => activate('mirror')}/><ToolButton icon={Trash2} label="Избриши" small disabled={!selected.length} onClick={erase}/></div></div><div className="panel-section drawing-units"><label className="field-label">Единици на цртежот</label><Picker value={drawing.unit} label="Единици на цртеж" options={[{ value: 'mm', label: 'Милиметри (mm)' }, { value: 'cm', label: 'Сантиметри (cm)' }, { value: 'm', label: 'Метри (m)' }, { value: 'in', label: 'Инчи (in)' }]} onChange={unit => commit({ ...drawing, unit: unit as Drawing['unit'] }, 'Единиците се изменети; координатите остануваат исти.')}/><p className="field-note">Единиците се користат за размерот при Plot.</p></div></div>;
    return <TooltipProvider delayDuration={350}><main className={`cad-app ${keyboardOpen ? 'keyboard-open' : ''}`}><input ref={fileRef} type="file" accept=".dxf,.dwg,.nookcad" hidden onChange={e => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (file)
                protect('Отвори ' + file.name, () => importFile(file));
        }}/><header className="app-header"><div className="brand" aria-label="Pixar Plus Print & Copy Studio"><img className="brand-logo" src="pixar-plus-logo.jpg" alt="Лого на Pixar Plus Print & Copy Studio" width={40} height={40}/><span className="brand-copy"><strong className="brand-name">Pixar <span>Plus</span></strong><span className="brand-studio">Print &amp; Copy Studio</span><span className="mobile-document-name" title={drawing.name}>{drawing.name}{dirty && <span aria-label="Незачувани измени"> *</span>}</span></span><span className="edition">CAD · DXF · DWG · Plot</span></div><div className="file-actions"><ToolButton icon={FilePlus2} label="Нов" onClick={() => protect('Нов цртеж', () => replaceDrawing(newDrawing()))}/><button className="open-button" onClick={() => fileRef.current?.click()} disabled={!!busy}><FolderOpen size={17}/><span>Отвори</span><small>DXF / DWG</small></button><ToolButton icon={Download} label="Зачувај DXF" onClick={save}/></div><div className="quick-history"><ToolButton icon={Undo2} label="Undo" small disabled={!undoRef.current.length} onClick={undo}/><ToolButton icon={Redo2} label="Redo" small disabled={!redoRef.current.length} onClick={redo}/></div><div className="header-end"><button className="header-command-search" onClick={() => setPaletteOpen(true)}><Command size={15}/>Commands</button><ToolButton icon={CircleHelp} label="Помош" small onClick={() => setHelpOpen(true)}/><button className="plot-button" onClick={() => setPlotOpen(true)}><Printer size={17}/><span>Plot / PDF</span></button></div></header>
 <CadRibbon onRun={runCommand} active={tool==='measure'?'DIST':resolveCommand(tool)?.name ?? tool} selected={selected.length} undoAvailable={!!undoRef.current.length} redoAvailable={!!redoRef.current.length} onSearch={() => setPaletteOpen(true)}/>
 <MobileTools onRun={runCommand} active={tool === 'measure' ? 'DIST' : resolveCommand(tool)?.name ?? tool.toUpperCase()} selected={selected.length} undoAvailable={!!undoRef.current.length} redoAvailable={!!redoRef.current.length} busy={!!busy} onSearch={() => setPaletteOpen(true)}/>
 <div className="document-bar"><div className="document-tab"><span className="document-symbol">⌑</span><span>{drawing.name}</span>{dirty && <span className="unsaved" title="Има незачувани измени"/>}</div><span className="document-status">{dirty ? 'Изменето' : drawing.source === 'DEMO' ? 'Пример за работа' : 'Подготвено'}</span><div className="mobile-panel-buttons"><button className="mobile-save" onClick={save} aria-label="Зачувај DXF"><Download size={15}/></button><button onClick={() => setSidePanel('layers')}><Layers size={16}/>Леери</button><button onClick={() => setSidePanel('properties')}><SlidersHorizontal size={16}/>Својства</button></div><div className="panel-toggles"><ToolButton icon={PanelLeftClose} label="Панел со леери" small active={leftOpen} onClick={() => setLeftOpen(v => !v)}/><ToolButton icon={PanelRightClose} label="Панел со својства" small active={rightOpen} onClick={() => setRightOpen(v => !v)}/></div></div>
 <div className={`work-area ${!leftOpen ? 'hide-left' : ''} ${!rightOpen ? 'hide-right' : ''}`}><aside className="layers-panel">{layerPanel}</aside><section className="canvas-column"><div className="canvas-meta"><div><span className="model-tag">{space.toUpperCase()}</span><span>Поглед одозгора</span><button className="mobile-space-switch" onClick={() => setSpace(space === 'model' ? 'layout' : 'model')} aria-label={space === 'model' ? 'Отвори Layout преглед' : 'Врати Model цртеж'}>{space === 'model' ? 'Model' : 'Layout 1'}</button></div><div className="active-layer-picker"><span className="color-chip" style={{ background: currentLayer?.color }}/><Picker value={activeLayer} options={drawing.layers.filter(l => !l.locked).map(l => ({ value: l.name, label: l.name }))} label="Активен леер" onChange={setActiveLayer}/></div><button className="mobile-properties-button" onClick={() => setSidePanel('properties')} aria-label="Отвори својства"><SlidersHorizontal size={20}/>{selected.length > 0 && <span>{selected.length}</span>}</button></div><div ref={hostRef} className="canvas-host" onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }} onDrop={e => {
            e.preventDefault();
            const f = e.dataTransfer.files[0];
            if (f)
                protect('Отвори ' + f.name, () => importFile(f));
        }}><Workspace drawing={visibleDrawing} view={view} size={size} selection={selection} grid={grid} draft={draft} cursor={cursor} snapped={snapped} tool={tool} box={box} activeLayer={activeLayer} onDown={down} onMove={move} onUp={up} onCancel={pointerCancel} onWheel={wheel} onDouble={() => advanced.finish() ? undefined : tool === 'polyline' ? finishPolyline() : tool === 'select' && selected[0]?.kind === 'text' ? editTextEntity() : undefined}/>
 {space === 'layout' && paperLayout && <div className="layout-workspace"><div className="layout-workspace-toolbar"><span>Layout 1 · {pageConfig.paper} · {paperLayout.w} × {paperLayout.h} mm · 1 : {paperLayout.denominator.toFixed(2)}</span><button onClick={() => setPlotOpen(true)}><Printer size={16}/>Page setup / Plot</button></div><div className="layout-paper" dangerouslySetInnerHTML={{ __html: paperSvg }}/><span className="layout-note">Paper Space preview · област и размер според Page setup</span></div>}
 <div className="canvas-tool-label"><span>{toolNames[tool]}</span><small>{tool === 'select' ? (multiSelect ? 'ПОВЕЌЕ ОБЈЕКТИ' : 'SHIFT · MULTI SELECT') : draft.length ? 'ESC · CANCEL' : 'MODEL SPACE'}</small></div><div className="view-controls"><ToolButton icon={ZoomIn} label="Зголеми" small onClick={() => zoom(1.4)}/><ToolButton icon={ZoomOut} label="Намали" small onClick={() => zoom(1 / 1.4)}/><ToolButton icon={Maximize} label="Прикажи цел цртеж" small shortcut="Z" onClick={fit}/></div>{['polyline', 'spline', 'solid', 'leader', 'area'].includes(tool) && draft.length > 1 && <div className="draft-controls"><button onClick={() => advanced.finish() || finishPolyline()}><Check size={15}/>Заврши</button><button onClick={() => advanced.finish(true) || finishPolyline(true)}>Затвори</button></div>}
 {!drawing.entities.length && <div className="empty-workspace"><h2>Нов цртеж</h2><p>Избери алатка за цртање или отвори DXF / DWG.</p><button className="open-button" onClick={() => fileRef.current?.click()}><FolderOpen size={17}/>Отвори цртеж</button><button className="text-link" onClick={() => protect('Отвори пример', () => replaceDrawing(demoDrawing()))}>Отвори пример</button></div>}
 {busy && <div className="busy-overlay"><div><LoaderCircle className="spin" size={26}/><p>{busy}</p><span>Цртежот се обработува на твојот уред.</span><button onClick={cancelImport}>Откажи</button></div></div>}
 </div>{space === 'model' && tool !== 'select' && tool !== 'pan' && <MobileCommandActions name={toolNames[tool]} canFinish={touchCanFinish} canClose={['polyline', 'spline'].includes(tool) && draft.length >= 3} onFinish={() => finishTouchCommand()} onClose={() => finishTouchCommand(true)} onCancel={cancel}/>}
 <div className="model-layout-tabs"><button className={space === 'model' ? 'active' : ''} onClick={() => setSpace('model')}>Model</button><button className={space === 'layout' ? 'active' : ''} onClick={() => setSpace('layout')}>Layout 1</button><button onClick={() => setPlotOpen(true)} title="Page setup / Plot"><Printer size={14}/></button><span>{space === 'model' ? 'WCS · Top · 2D Wireframe' : 'PAPER · Plot preview'}</span>{hidden.size > 0 && <button onClick={() => setHidden(new Set())} className="hidden-objects-notice">{hidden.size} hidden · Restore</button>}</div><div className="command-area"><div className="command-history"><button className="history-mark" onClick={() => setHistoryOpen(true)} title="F2 · Command history">›</button><span title={lastMessage}>{lastMessage}</span>{measurement && <button className="measurement-result" onClick={() => setMeasurement('')} title="Отстрани мерење">{measurement}<X size={12}/></button>}</div><form onSubmit={e => { e.preventDefault(); runCommand(command); }}>{suggestions.length > 0 && <div className="command-suggestions" role="listbox" aria-label="Предлози на команди">{suggestions.map((c, i) => <button type="button" role="option" aria-selected={i === suggestion} className={i === suggestion ? 'active' : ''} key={c.name} onMouseDown={e => e.preventDefault()} onClick={() => runCommand(c.name)}><strong>{c.name}</strong><span>{c.description}</span><kbd>{c.aliases[0]}</kbd></button>)}</div>}<Command size={15}/><label htmlFor="cad-command">{tool === 'select' ? 'Команда' : toolNames[tool]}:</label><input ref={commandRef} id="cad-command" value={command} onChange={e => { setCommand(e.target.value); setSuggestion(0); }} placeholder={promptFor(tool, draft.length)} autoComplete="off" autoCapitalize="off" autoCorrect="off" enterKeyHint="go" spellCheck={false} onKeyDown={e => {
            if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();setPaletteOpen(true);}else if(['F1','F2','F3','F7','F8'].includes(e.key)){e.preventDefault();if(e.key==='F1')setHelpOpen(true);if(e.key==='F2')setHistoryOpen(v=>!v);if(e.key==='F3')setSnap(v=>!v);if(e.key==='F7')setGrid(v=>!v);if(e.key==='F8')setOrtho(v=>!v);}else if (e.key === 'Enter' && suggestions.length && !resolveCommand(command.trim())) {
                e.preventDefault();
                runCommand(suggestions[suggestion]?.name ?? suggestions[0].name);
            }
            else if (e.key === 'Escape') {
                setCommand('');
                cancel();
                e.currentTarget.blur();
            }
            else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                if (suggestions.length)
                    setSuggestion(v => (v + (e.key === 'ArrowDown' ? 1 : -1) + suggestions.length) % suggestions.length);
                else {
                    issuedIndex.current = Math.max(0, Math.min(issuedRef.current.length - 1, issuedIndex.current + (e.key === 'ArrowUp' ? -1 : 1)));
                    setCommand(issuedRef.current[issuedIndex.current] ?? '');
                }
            }
            else if (e.key === 'Tab' && suggestions.length) {
                e.preventDefault();
                setCommand(suggestions[suggestion]?.name ?? suggestions[0].name);
            }
        }}/><button type="button" className="mobile-keyboard-dismiss" aria-label="Затвори тастатура" onClick={() => commandRef.current?.blur()}><ChevronDown size={20}/></button><button type="submit" aria-label="Изврши команда">Enter</button></form></div></section><aside className="properties-panel">{propertiesPanel}</aside></div>
 <footer className="status-bar"><div className="coordinates"><span>X <b>{number(cursor?.x ?? 0)}</b></span><span>Y <b>{number(cursor?.y ?? 0)}</b></span><span>{drawing.unit}</span></div><div className="status-toggles"><button className={grid ? 'on' : ''} onClick={() => setGrid(v => !v)} aria-pressed={grid} aria-label="Мрежа"><Grid3X3 size={14}/><span>Мрежа</span></button><button className={snap ? 'on' : ''} onClick={() => setSnap(v => !v)} aria-pressed={snap}><Magnet size={14}/><span>Snap</span></button><button className={ortho ? 'on' : ''} onClick={() => setOrtho(v => !v)} aria-pressed={ortho}><Crosshair size={14}/><span>Ortho</span></button></div><div className="mobile-status-actions"><ToolButton icon={CheckCheck} label="Избор на повеќе објекти" small active={multiSelect} onClick={() => { setMultiSelect(v => !v); if (tool !== 'select') activate('select'); }}/><ToolButton icon={Undo2} label="Undo" small disabled={!undoRef.current.length} onClick={undo}/><ToolButton icon={Redo2} label="Redo" small disabled={!redoRef.current.length} onClick={redo}/></div><div className="status-end"><span>{selected.length} избрани</span><span>2D / {drawing.unit}</span></div></footer>
 <PlotDialog open={plotOpen} onOpenChange={setPlotOpen} drawing={visibleDrawing} selection={selection} viewBounds={viewBounds} config={pageConfig} onConfigChange={setPageConfig} windowBounds={plotWindow} onChooseWindow={() => { setPlotOpen(false); activate('window'); }}/>
 {advanced.dialogs}<CadCommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} onRun={runCommand}/>
 <Dialog open={historyOpen} onOpenChange={setHistoryOpen}><DialogContent className="cad-dialog history-dialog"><DialogHeader><DialogTitle>Command history · F2</DialogTitle><DialogDescription>Последните 200 команди и резултати.</DialogDescription></DialogHeader><div className="full-command-history">{commandLog.length ? commandLog.map((m, i) => <p key={i}>{m}</p>) : <p>Подготвено за работа.</p>}</div></DialogContent></Dialog>
 <Sheet open={!!sidePanel} onOpenChange={open => {
            if (!open)
                setSidePanel(null);
        }}><SheetContent side={sidePanel === 'layers' ? 'left' : 'right'} className="cad-sheet" onOpenAutoFocus={e => e.preventDefault()}><SheetHeader><SheetTitle>{sidePanel === 'layers' ? 'Леери' : 'Својства'}</SheetTitle>{sidePanel === 'layers' && <button className="sheet-add-layer" aria-label="Додај леер" onClick={() => setNewLayerOpen(true)}><Plus size={21}/></button>}<SheetDescription>{sidePanel === 'layers' ? 'Контрола на приказот и плотирањето.' : 'Селекција и трансформации.'}</SheetDescription></SheetHeader>{sidePanel === 'layers' ? layerPanel : propertiesPanel}</SheetContent></Sheet>
 <Dialog open={newLayerOpen} onOpenChange={setNewLayerOpen}><DialogContent className="cad-dialog compact-dialog"><DialogHeader><DialogTitle>Нов леер</DialogTitle><DialogDescription>Организирај ја геометријата во посебен леер.</DialogDescription></DialogHeader><label className="field-label">Име<input autoFocus value={newLayerName} onChange={e => setNewLayerName(e.target.value)} onKeyDown={e => {
            if (e.key === 'Enter')
                addLayer();
        }} placeholder="A-WALL" maxLength={100}/></label><label className="color-field">Боја<input type="color" value={newLayerColor} onChange={e => setNewLayerColor(e.target.value)}/></label><button className="primary-button" onClick={addLayer}>Додај леер</button></DialogContent></Dialog>
 <Dialog open={!!textEdit} onOpenChange={open => {
            if (!open)
                setTextEdit(null);
        }}><DialogContent className="cad-dialog compact-dialog"><DialogHeader><DialogTitle>{textEdit?.id ? 'Измени текст' : 'Додај текст'}</DialogTitle><DialogDescription>Текстот се поставува на избраната точка.</DialogDescription></DialogHeader><label className="field-label">Текст<textarea autoFocus value={textValue} onChange={e => setTextValue(e.target.value)} rows={3} maxLength={10000}/></label><div className="input-pair"><label>Висина ({drawing.unit})<input type="number" min=".001" step="any" value={textHeight} onChange={e => setTextHeight(e.target.value)}/></label><label>Агол (°)<input type="number" step="any" value={textAngle} onChange={e => setTextAngle(e.target.value)}/></label></div><button className="primary-button" onClick={applyText}>Примени</button></DialogContent></Dialog>
 <Dialog open={warningOpen} onOpenChange={setWarningOpen}><DialogContent className="cad-dialog compact-dialog"><DialogHeader><DialogTitle>Забелешки за цртежот</DialogTitle><DialogDescription>Провери ги овие детали пред уредување или плотирање.</DialogDescription></DialogHeader><ul className="warning-list">{drawing.warnings.map((w, i) => <li key={i}><TriangleAlert size={16}/><span>{w}</span></li>)}</ul><button className="primary-button" onClick={() => setWarningOpen(false)}>Продолжи</button></DialogContent></Dialog>
 <Dialog open={helpOpen} onOpenChange={setHelpOpen}><DialogContent className="cad-dialog help-dialog"><DialogHeader><DialogTitle>Pixar Plus CAD · помош</DialogTitle><DialogDescription>2D цртање со ribbon, каталог на команди и командна линија.</DialogDescription></DialogHeader><div className="help-content"><div className="studio-help-brand"><img src="pixar-plus-logo.jpg" alt="Лого на Pixar Plus Print & Copy Studio" width={56} height={56}/><div><strong>Pixar Plus</strong><span>Print &amp; Copy Studio</span></div></div><h3>Работа со цртеж</h3><p>Отвори DXF / DWG или повлечи го фајлот врз цртежот. Тркалцето зумира околу покажувачот; Space + повлекување или средното копче го поместува погледот. На телефон избери Pan и повлечи со еден прст. Со два прста истовремено зумираш и го поместуваш погледот. „Цртај“, „Измени“ и „Алатки“ ги отвораат сите категории со постојните команди.</p><p>Клик избира објект. Shift додава или отстранува од изборот. На телефон вклучи „Избор на повеќе објекти“ (иконата со две ознаки долу), па допри ги објектите. За крај на цртањето користи „Заврши“, „Затвори“ или „Откажи“. Прозорец од лево надесно избира објекти внатре, а од десно налево избира објекти чии граници го допираат прозорецот. Скриените и заклучените леери не се селектираат.</p><h3>Команди</h3><p>Ctrl+K или COMMANDS отвора каталог со сите имплементирани команди. Tab го дополнува внесот, ↑/↓ избира предлог или претходен внес, F2 ја отвора историјата. Празен Enter ја повторува последната команда. TRIM/EXTEND користат избрани граници или сите видливи објекти. FILLET/CHAMFER бараат точно две прави линии. MIRROR ја задржува оригиналната геометрија и создава огледална копија.</p><div className="shortcut-grid">{[['L', 'Линија'], ['PL', 'Полилинија'], ['REC', 'Правоаголник'], ['C / ARC', 'Круг / лак'], ['T', 'Текст'], ['M / RO', 'Move / Rotate'], ['CO / MI', 'Copy / Mirror'], ['SC', 'Scale'], ['DI / DIM', 'Мерење / кота'], ['Z', 'Цел цртеж'], ['Ctrl+Z / Ctrl+Y', 'Undo / Redo'], ['Ctrl+S / Ctrl+P', 'DXF / Plot']].map(([key, desc]) => <div key={key}><kbd>{key}</kbd><span>{desc}</span></div>)}</div><p>По изборот на алатка внеси <code>100,200</code> за точни координати, <code>@50,0</code> за релативна точка или <code>@100&lt;45</code> за растојание и агол. За избрани објекти може и <code>MOVE 100,0</code>, <code>ROTATE 90</code> или <code>SCALE 2</code>. Enter завршува полилинија, C ја затвора, Esc ја откажува командата.</p><h3>Plot и формати</h3><p>Plot извезува векторски PDF или SVG со избраниот формат, размер, маргини и дебелини. За печатење во размер, во PDF прегледувачот избери „Actual size / 100%“ и истиот формат на хартија. „Fit“ пресметува размер за целиот цртеж.</p><p>Оваа верзија работи со 2D Model Space. Не поддржува 3D solids, параметарски ограничувања, Xrefs, оригинални AutoCAD layouts, CTB/STB, LISP и SHX фонтови. Layout 1 е преглед на хартија според Page setup. DWG компатибилноста зависи од читачот LibreDWG. ASCII DXF е најпредвидлив за размена. Блоковите и котите од DXF/DWG се отвораат како геометрија; новите Pixar Plus CAD блокови и групи се задржуваат во проектот (.nookcad). Котите се групирана геометрија; не се задржуваат како параметарски CAD објекти. Spline, елипси и заоблени полилинии може да се зачуваат како сегменти. TRIM и BREAK на криви создаваат сегментирана патека; OFFSET на полилинии користи остри споеви. Низите се независни копии, а котите не се асоцијативни.</p><p>Фајловите се обработуваат локално. Зачувај DXF или Pixar Plus CAD проект пред да ја затвориш страницата. SAVEAS зачувува проект со блокови, групи и пополнувања; SAVE извезува DXF. Имплементирани се 2D команди од каталогот; ова не е целосен AutoCAD.  нема DWG извоз.</p><div className="license-note"><span>Pixar Plus CAD · GPL-3.0</span><a href="pixar-plus-cad-source.zip" download>Изворен код</a><a href="https://github.com/mlightcad/libredwg-web" target="_blank" rel="noreferrer">LibreDWG</a></div></div></DialogContent></Dialog>
 <AlertDialog open={!!pending} onOpenChange={open => {
            if (!open)
                setPending(null);
        }}><AlertDialogContent className="cad-dialog compact-dialog"><AlertDialogHeader><AlertDialogTitle>Има незачувани измени</AlertDialogTitle><AlertDialogDescription>Зачувај DXF за да ги задржиш измените пред да продолжиш со „{pending?.label}“.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Назад</AlertDialogCancel><button className="secondary-button" onClick={save}>Зачувај DXF</button><AlertDialogAction onClick={() => { const run = pending?.run; setPending(null); run?.(); }}>Продолжи</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
 </main><Toaster theme="dark" richColors position="bottom-center"/></TooltipProvider>;
}
