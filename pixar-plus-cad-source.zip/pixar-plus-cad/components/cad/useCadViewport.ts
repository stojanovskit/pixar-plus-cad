"use client";
import { useEffect, useState } from 'react';

/** Follow the available screen when a phone's virtual keyboard opens. */
export default function useCadViewport() {
  const [keyboardOpen, setKeyboardOpen] = useState(false);
  useEffect(() => {
    const viewport = window.visualViewport;
    let width = window.innerWidth, baseline = viewport?.height ?? window.innerHeight, keyboard = false;
    let frame = 0;
    const update = () => {
      const focused = document.activeElement;
      const editing = focused instanceof HTMLInputElement || focused instanceof HTMLTextAreaElement;
      if (viewport && viewport.scale !== 1) {
        if (!editing) { keyboard = false; setKeyboardOpen(false); }
        return;
      }
      const height = viewport?.height ?? window.innerHeight;
      if (Math.abs(window.innerWidth - width) > 40) { width = window.innerWidth; baseline = editing && keyboard ? height + 121 : height; }
      baseline = Math.max(baseline, height);
      document.documentElement.style.setProperty('--cad-viewport-height', `${height}px`);
      keyboard = editing && baseline - height > 120;
      setKeyboardOpen(keyboard);
    };
    const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(update); };
    update();
    viewport?.addEventListener('resize', schedule);
    window.addEventListener('resize', schedule);
    document.addEventListener('focusin', schedule);
    document.addEventListener('focusout', schedule);
    return () => {
      cancelAnimationFrame(frame);
      viewport?.removeEventListener('resize', schedule);
      window.removeEventListener('resize', schedule);
      document.removeEventListener('focusin', schedule);
      document.removeEventListener('focusout', schedule);
      document.documentElement.style.removeProperty('--cad-viewport-height');
    };
  }, []);
  return keyboardOpen;
}
