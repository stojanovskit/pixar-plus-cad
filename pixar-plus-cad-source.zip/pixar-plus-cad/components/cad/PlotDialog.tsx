"use client";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Bounds, Drawing } from '@/lib/cad/model';
import { PlotConfig, createPdf, download, plotLayout, plotSvg } from '@/lib/cad/output';
import { Crop, Download, FileImage, LoaderCircle, Printer, TriangleAlert } from 'lucide-react';
import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Picker } from './Controls';
export default function PlotDialog({ open, onOpenChange, drawing, selection, viewBounds, windowBounds, onChooseWindow, config, onConfigChange }: {
    open: boolean;
    onOpenChange: (b: boolean) => void;
    drawing: Drawing;
    selection: Set<string>;
    viewBounds: Bounds;
    windowBounds?: Bounds;
    onChooseWindow: () => void;
    config: PlotConfig;
    onConfigChange: (p: PlotConfig) => void;
}) {
    const [busy, setBusy] = useState(false);
    const update = (p: Partial<PlotConfig>) => onConfigChange({ ...config, ...p });
    const layout = useMemo(() => plotLayout(drawing, config, selection, viewBounds, windowBounds), [drawing, config, selection, viewBounds, windowBounds]);
    const svg = useMemo(() => open ? plotSvg(drawing, config, selection, viewBounds, windowBounds) : '', [open, drawing, config, selection, viewBounds, windowBounds]);
    const valid = Number.isFinite(config.margin) && config.margin >= 0 && config.margin < Math.min(layout.w, layout.h) / 2 && Number.isFinite(config.denominator) && config.denominator > 0 && Number.isFinite(config.customWidth) && config.customWidth >= 20 && config.customWidth <= 2000 && Number.isFinite(config.customHeight) && config.customHeight >= 20 && config.customHeight <= 2000 && layout.entities.length > 0 && (config.area !== 'window' || !!windowBounds);
    async function exportPdf() { if (!valid) {
        toast.error('Провери ги форматот, размерот и областа за плотирање.');
        return;
    } setBusy(true); try {
        const pdf = await createPdf(drawing, config, selection, viewBounds, windowBounds);
        pdf.save(drawing.name.replace(/[^\p{L}\p{N}\s._-]/gu, '_') + '_' + config.paper + '.pdf');
        toast.success('PDF е подготвен за преземање.');
    }
    catch (error) {
        toast.error(error instanceof Error ? error.message : 'Неуспешен PDF извоз.');
    }
    finally {
        setBusy(false);
    } }
    return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="cad-dialog plot-dialog"><DialogHeader><DialogTitle><Printer size={20}/>Plot / PDF</DialogTitle><DialogDescription>Постави хартија, област и размер за печатење.</DialogDescription></DialogHeader><div className="plot-layout"><div className="plot-settings"><label className="field-label">Формат на хартија<Picker label="Формат на хартија" value={config.paper} options={['A4', 'A3', 'A2', 'A1', 'A0', 'custom'].map(v => ({ value: v, label: v === 'custom' ? 'Сопствен формат' : v }))} onChange={paper => update({ paper })}/></label>{config.paper === 'custom' && <div className="input-pair"><label>Ширина (mm)<input aria-label="Сопствена ширина" type="number" min="20" max="2000" value={config.customWidth} onChange={e => update({ customWidth: Number(e.target.value) })}/></label><label>Висина (mm)<input aria-label="Сопствена висина" type="number" min="20" max="2000" value={config.customHeight} onChange={e => update({ customHeight: Number(e.target.value) })}/></label></div>}<label className="field-label">Ориентација<Picker label="Ориентација" value={config.orientation} options={[{ value: 'landscape', label: 'Хоризонтално' }, { value: 'portrait', label: 'Вертикално' }]} onChange={orientation => update({ orientation: orientation as PlotConfig['orientation'] })}/></label><label className="field-label">Област за плотирање<Picker label="Област за плотирање" value={config.area} options={[{ value: 'extents', label: 'Цел видлив цртеж' }, { value: 'selection', label: `Селекција (${selection.size})` }, { value: 'view', label: 'Тековен поглед' }, { value: 'window', label: 'Избран прозорец' }]} onChange={area => update({ area: area as PlotConfig['area'] })}/></label><button className="choose-window" onClick={() => { update({ area: 'window' }); onChooseWindow(); }}><Crop size={16}/>{windowBounds ? 'Смени Plot прозорец' : 'Избери Plot прозорец'}</button>
 <div className="plot-divider"/><div className="switch-row"><label htmlFor="plot-fit">Вклопи на хартија</label><Switch id="plot-fit" checked={config.fit} onCheckedChange={fit => update({ fit })}/></div><label className="field-label">Размер<div className="scale-input"><span>1 :</span><input aria-label="Размер за плотирање" type="number" step="any" min=".001" value={config.denominator} disabled={config.fit} onChange={e => update({ denominator: Number(e.target.value) })}/></div></label>{config.fit && <p className="field-note">Пресметан размер 1 : {layout.denominator.toFixed(2)}</p>}<label className="field-label">Маргини (mm)<input aria-label="Маргини во милиметри" type="number" min="0" step="1" value={config.margin} onChange={e => update({ margin: Number(e.target.value) })}/></label><div className="plot-divider"/><div className="switch-row"><label htmlFor="plot-monochrome">Црно-бело</label><Switch id="plot-monochrome" checked={config.monochrome} onCheckedChange={monochrome => update({ monochrome })}/></div><div className="switch-row"><label htmlFor="plot-lineweights">Дебелини на линии</label><Switch id="plot-lineweights" checked={config.lineweights} onCheckedChange={lineweights => update({ lineweights })}/></div><p className="field-note">Се печатат видливите леери со вклучено Plot.</p></div>
 <div className="plot-preview-column"><div className="preview-header"><span>ПРЕГЛЕД НА ЛИСТОТ</span><strong>{layout.w} × {layout.h} mm</strong></div><div className="paper-preview"><div className="paper-sheet" style={{ aspectRatio: `${layout.w} / ${layout.h}` }} dangerouslySetInnerHTML={{ __html: svg }}/></div><div className="plot-summary"><span>{layout.entities.length.toLocaleString()} објекти</span><span>1 : {layout.denominator.toFixed(2)}</span><span>{config.monochrome ? 'Црно-бело' : 'Во боја'}</span></div>{layout.overflow && <p className="plot-warning"><TriangleAlert size={16}/>Цртежот е поголем од областа за печатење и ќе биде исечен. Смени го размерот или вклучи вклопување.</p>}{config.area === 'window' && !windowBounds && <p className="plot-warning"><Crop size={16}/>Избери прозорец од цртежот.</p>}{!layout.entities.length && <p className="plot-warning">Нема објекти во избраната област. Провери ги леерите или селекцијата.</p>}<p className="print-note"><Printer size={15}/>Во PDF прегледувачот печати со „Actual size / 100%“.</p></div></div><div className="plot-footer"><span>Векторски извоз · {drawing.unit} → mm</span><div><button className="secondary-button" disabled={!valid || busy} onClick={() => download(svg, drawing.name + '.svg', 'image/svg+xml')}><FileImage size={16}/>SVG</button><button className="primary-button" disabled={!valid || busy} onClick={exportPdf}>{busy ? <LoaderCircle size={17} className="spin"/> : <Download size={17}/>}Преземи PDF</button></div></div></DialogContent></Dialog>;
}
