"use client";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Bounds, bounds, center, distance, Drawing, Entity, IDENTITY, multiply, Point, point, polyline, rotation, samples, scaling, translation, uid } from '@/lib/cad/model';
import * as op from '@/lib/cad/operations';
import { download, exportDxf } from '@/lib/cad/output';
import type { View } from '@/lib/cad/render';
import { useRef, useState } from 'react';
import { toast } from 'sonner';
import { Picker } from './Controls';
import type { Tool } from './Workspace';
type Field = {
    key: string;
    label: string;
    value: string;
    type?: 'number' | 'text' | 'color';
    options?: {
        value: string;
        label: string;
    }[];
};
type Params = {
    title: string;
    description: string;
    fields: Field[];
    run: (v: Record<string, string>) => void;
};
type Options = {
    drawing: Drawing;
    selected: Entity[];
    selection: Set<string>;
    activeLayer: string;
    tool: Tool;
    draft: Point[];
    view: View;
    commit: (d: Drawing, message: string) => void;
    append: (e: Entity[], message: string) => void;
    setSelection: (s: Set<string>) => void;
    setActiveLayer: (s: string) => void;
    setTool: (s: Tool) => void;
    setDraft: (s: Point[]) => void;
    report: (s: string) => void;
    find: (p: Point) => Entity | undefined;
    fitBounds: (b: Bounds) => void;
    hidden: Set<string>;
    setHidden: (s: Set<string>) => void;
};
const field = (key: string, label: string, value: string | number, type: 'number' | 'text' = 'number'): Field => ({ key, label, value: String(value), type });
const choose = (key: string, label: string, value: string, options: string[] | {
    value: string;
    label: string;
}[]): Field => ({ key, label, value, options: options.map(s => typeof s === 'string' ? { value: s, label: s } : s) });
const advancedTools: Tool[] = ['ellipse', 'polygon', 'point', 'spline', 'solid', 'donut', 'leader', 'dimlinear', 'dimaligned', 'dimradius', 'dimdiameter', 'dimangular', 'trim', 'extend', 'offset', 'break', 'breakatpoint', 'stretch', 'align', 'matchprop', 'insert', 'area', 'id', 'zoomwindow'];
export const advancedNames: Partial<Record<Tool, string>> = { ellipse: 'Ellipse', polygon: 'Polygon', point: 'Point', spline: 'Spline', solid: 'Solid', donut: 'Donut', leader: 'Multileader', dimlinear: 'Dimlinear', dimaligned: 'Dimaligned', dimradius: 'Dimradius', dimdiameter: 'Dimdiameter', dimangular: 'Dimangular', trim: 'Trim', extend: 'Extend', offset: 'Offset', break: 'Break', breakatpoint: 'Break at point', stretch: 'Stretch', align: 'Align', matchprop: 'Match properties', insert: 'Insert block', area: 'Area', id: 'ID point', zoomwindow: 'Zoom window' };
export function advancedPrompt(tool: Tool, n: number) { const list: Partial<Record<Tool, string[]>> = { ellipse: ['Избери центар', 'Избери главна полуоска', 'Избери мала полуоска'], polygon: ['Избери центар', 'Избери радиус до теме'], point: ['Избери точка'], spline: ['Точки за SPLINE · Enter завршува'], solid: ['Темиња за SOLID · Enter завршува'], donut: ['Избери центар на прстен'], leader: ['Точки за стрелка · Enter за текст'], trim: ['Кликни сегмент за отстранување · Esc завршува'], extend: ['Кликни крај за продолжување · Esc завршува'], offset: ['Избери објект за офсет', 'Кликни на страната за копија'], break: ['Избери објект', 'Прва точка на прекин', 'Втора точка на прекин'], breakatpoint: ['Избери објект', 'Точка на прекин'], stretch: ['Прв агол на прозорец', 'Втор агол на прозорец', 'Базна точка', 'Целна точка'], align: ['Прва изворна точка', 'Прва целна точка', 'Втора изворна точка', 'Втора целна точка'], matchprop: ['Избери извор за својствата', 'Избери цел · Esc завршува'], insert: ['Избери позиција за блокот'], dimlinear: ['Прва точка за кота', 'Втора точка за кота', 'Избери позиција на котата'], dimaligned: ['Прва точка за кота', 'Втора точка за кота', 'Избери позиција на котата'], dimradius: ['Избери круг/лак', 'Постави ја ознаката за радиус'], dimdiameter: ['Избери круг/лак', 'Постави ја ознаката за дијаметар'], dimangular: ['Постави ја аголната кота'], area: ['Кликни темиња за плоштина · Enter завршува'], id: ['Избери точка за координати'], zoomwindow: ['Прв агол за зум', 'Втор агол за зум'] }; const p = list[tool]; return p ? p[Math.min(n, p.length - 1)] : undefined; }
export default function useAdvancedCad(o: Options) {
    const [params, setParams] = useState<Params | null>(null), [values, setValues] = useState<Record<string, string>>({}), [error, setError] = useState(''), [detail, setDetail] = useState<{
        title: string;
        text: string;
    } | null>(null);
    const settings = useRef({ offset: 100, sides: 6, inner: 100, outer: 200, alignScale: false, dimHeight: 0, insertName: '', insertScale: 1, insertAngle: 0 });
    const target = useRef<string | undefined>(undefined), layerStates = useRef<Drawing['layers'] | null>(null);
    const editable = o.selected.filter(e => { const l = o.drawing.layers.find(l => l.name === e.layer); return l?.visible && !l.locked; });
    const h = () => settings.current.dimHeight || 12 / o.view.scale;
    const safe = (run: () => void) => {
        try {
            run();
        }
        catch (e) {
            toast.error(e instanceof Error ? e.message : 'Командата не успеа.');
        }
    };
    function ask(title: string, description: string, fields: Field[], run: Params['run']) { setParams({ title, description, fields, run }); setValues(Object.fromEntries(fields.map(f => [f.key, f.value]))); setError(''); }
    function need(n = 1) {
        if (editable.length < n)
            throw Error(`Прво селектирај ${n === 1 ? 'еден или повеќе' : n} отклучени објекти.`);
        return editable;
    }
    function replace(ids: Set<string>, list: Entity[], message: string) { const remaining = o.drawing.entities.filter(e => !ids.has(e.id)); o.commit({ ...o.drawing, entities: [...remaining, ...list] }, message); o.setSelection(new Set(list.map(e => e.id))); }
    function change(list: Entity[], message: string) { const changed = new Map(list.map(e => [e.id, e])); o.commit({ ...o.drawing, entities: o.drawing.entities.map(e => changed.get(e.id) ?? e) }, message); }
    function start(tool: Tool) { target.current = undefined; o.setDraft([]); o.setTool(tool); o.report(advancedPrompt(tool, 0) ?? tool); }
    function layerChange(cmd: string) {
        const names = new Set(editable.map(e => e.layer)), all = ['LAYON', 'LAYTHW', 'LAYUNLOCK'].includes(cmd);
        if (!all && cmd !== 'LAYUNISO')
            need();
        if (cmd === 'LAYMCUR') {
            o.setActiveLayer(editable[0].layer);
            o.report('Активен леер: ' + editable[0].layer);
            return;
        }
        if (cmd === 'LAYCUR') {
            change(editable.map(e => ({ ...e, layer: o.activeLayer })), 'Изборот е во активниот леер.');
            return;
        }
        if (cmd === 'LAYISO')
            layerStates.current = o.drawing.layers.map(l => ({ ...l }));
        if (cmd === 'LAYUNISO' && !layerStates.current)
            throw Error('Нема претходна LAYISO состојба.');
        const layers = o.drawing.layers.map(l => {
            if (cmd === 'LAYUNISO')
                return { ...l, visible: layerStates.current?.find(p => p.name === l.name)?.visible ?? l.visible };
            if (cmd === 'LAYISO')
                return { ...l, visible: names.has(l.name) };
            if (all)
                return { ...l, ...(cmd === 'LAYUNLOCK' ? { locked: false } : { visible: true }) };
            if (names.has(l.name))
                return { ...l, ...(cmd === 'LAYLOCK' ? { locked: true } : { visible: false }) };
            return l;
        });
        o.commit({ ...o.drawing, layers }, cmd + ' · леерите се ажурирани.');
        o.setSelection(new Set());
        if (cmd === 'LAYUNISO')
            layerStates.current = null;
        const current = layers.find(l => l.name === o.activeLayer);
        if (!current?.visible || current.locked) {
            const next = layers.find(l => l.visible && !l.locked);
            if (next)
                o.setActiveLayer(next.name);
        }
    }
    function execute(cmd: string, args: string[] = []) {
        let handled = true;
        safe(() => {
            const d = o.drawing, n = Number(args[0]);
            if (['ELLIPSE', 'SPLINE', 'POINT', 'SOLID', 'TRIM', 'EXTEND', 'BREAK', 'BREAKATPOINT', 'STRETCH', 'MATCHPROP', 'DIMALIGNED', 'DIMLINEAR', 'DIMRADIUS', 'DIMDIAMETER', 'ID', 'ZOOMWINDOW'].includes(cmd)) {
                start(({ DIMALIGNED: 'dimaligned', DIMLINEAR: 'dimlinear', DIMRADIUS: 'dimradius', DIMDIAMETER: 'dimdiameter', BREAKATPOINT: 'breakatpoint', MATCHPROP: 'matchprop', ZOOMWINDOW: 'zoomwindow' } as any)[cmd] ?? cmd.toLowerCase());
                return;
            }
            if (cmd === 'POLYGON') {
                ask('POLYGON', 'Правилен многуаголник. По поставките избери центар и радиус до теме.', [field('n', 'Број на страни', settings.current.sides)], v => {
                    const n = Number(v.n);
                    if (!Number.isInteger(n) || n < 3 || n > 1024)
                        throw Error('Внеси 3–1024 страни.');
                    settings.current.sides = n;
                    start('polygon');
                });
                return;
            }
            if (cmd === 'OFFSET') {
                const run = (v: Record<string, string>) => {
                    const a = Number(v.distance);
                    if (!Number.isFinite(a) || a <= 0)
                        throw Error('Внеси позитивно растојание.');
                    settings.current.offset = a;
                    start('offset');
                };
                if (args.length)
                    run({ distance: args[0] });
                else
                    ask('OFFSET', 'Избери објект, па страна за паралелната копија.', [field('distance', 'Растојание (' + d.unit + ')', settings.current.offset)], run);
                return;
            }
            if (cmd === 'DONUT') {
                ask('DONUT', 'По поставките кликни на центарот. Дијаметрите се во ' + d.unit + '.', [field('inner', 'Внатрешен дијаметар', settings.current.inner), field('outer', 'Надворешен дијаметар', settings.current.outer)], v => {
                    const a = Number(v.inner), b = Number(v.outer);
                    if (!Number.isFinite(a) || !Number.isFinite(b) || a < 0 || b <= a)
                        throw Error('Надворешниот дијаметар мора да биде поголем од внатрешниот.');
                    settings.current.inner = a;
                    settings.current.outer = b;
                    start('donut');
                });
                return;
            }
            if (cmd === 'FILLET' || cmd === 'CHAMFER') {
                need(2);
                if (editable.length !== 2)
                    throw Error('Избери точно две прави линии.');
                const run = (v: Record<string, string>) => replace(new Set(editable.map(e => e.id)), cmd === 'FILLET' ? op.fillet(editable[0], editable[1], Number(v.radius)) : op.chamfer(editable[0], editable[1], Number(v.first), Number(v.second)), cmd + ' · аголот е изменет.');
                if (args.length)
                    run(cmd === 'FILLET' ? { radius: args[0] } : { first: args[0], second: args[1] ?? args[0] });
                else
                    ask(cmd, 'Се менува аголот на двете избрани прави линии.', cmd === 'FILLET' ? [field('radius', 'Радиус (' + d.unit + ')', 0)] : [field('first', 'Прво растојание', 100), field('second', 'Второ растојание', 100)], run);
                return;
            }
            if (cmd === 'JOIN' || cmd === 'BOUNDARY') {
                need(2);
                const e = op.join(editable);
                if (cmd === 'BOUNDARY' && !e.closed)
                    throw Error('Избраните линии не формираат затворена граница.');
                if (cmd === 'JOIN')
                    replace(new Set(editable.map(e => e.id)), [e], 'Патеките се споени.');
                else
                    o.append([e], 'Додадена граница.');
                return;
            }
            if (cmd === 'EXPLODE') {
                need();
                replace(new Set(editable.map(e => e.id)), editable.flatMap(op.explode), 'Изборот е разделен.');
                return;
            }
            if (cmd === 'REVERSE') {
                need();
                change(editable.map(e => e.kind === 'polyline' ? { ...e, points: [...(e.points ?? [])].reverse() } : e), 'Превртен редослед на темиња.');
                return;
            }
            if (cmd === 'PEDIT') {
                need();
                if (editable.some(e => e.kind !== 'polyline'))
                    throw Error('PEDIT бара полилинија.');
                ask('PEDIT', 'Измени ги избраните полилинии.', [choose('mode', 'Операција', 'close', [{ value: 'close', label: 'Close — затвори' }, { value: 'open', label: 'Open — отвори' }, { value: 'reverse', label: 'Reverse — преврти' }])], v => change(editable.map(e => v.mode === 'reverse' ? { ...e, points: [...(e.points ?? [])].reverse() } : { ...e, closed: v.mode === 'close' }), 'Полилинијата е изменета.'));
                return;
            }
            if (cmd === 'LENGTHEN') {
                need();
                const run = (v: Record<string, string>) => change(editable.map(e => op.lengthen(e, Number(v.length))), 'LENGTHEN · должината е изменета.');
                if (args.length)
                    run({ length: args[0] });
                else
                    ask('LENGTHEN', 'Вкупна должина од почетната точка на правата линија.', [field('length', 'Вкупна должина', distance(samples(editable[0])[0], samples(editable[0]).at(-1)!))], run);
                return;
            }
            if (cmd === 'ARRAYRECT') {
                need();
                ask('ARRAYRECT', 'Оригиналот е првиот елемент. Копиите се независна геометрија.', [field('rows', 'Редови', 2), field('cols', 'Колони', 3), field('dx', 'Растојание меѓу колони', Math.max(1, bounds(editable).maxX - bounds(editable).minX) * 1.2), field('dy', 'Растојание меѓу редови', Math.max(1, bounds(editable).maxY - bounds(editable).minY) * 1.2)], v => o.append(op.arrayRect(editable, Number(v.rows), Number(v.cols), Number(v.dx), Number(v.dy)), 'Додадена правоаголна низа.'));
                return;
            }
            if (cmd === 'ARRAYPOLAR') {
                need();
                const c = center(bounds(editable));
                ask('ARRAYPOLAR', 'Копии околу центарот. 360° прави цел круг без дупликат на почетокот.', [field('count', 'Број на елементи', 6), field('x', 'Центар X', c.x), field('y', 'Центар Y', c.y), field('angle', 'Вкупен агол (°)', 360), choose('rotate', 'Ротирај ги копиите', 'yes', [{ value: 'yes', label: 'Да' }, { value: 'no', label: 'Не' }])], v => o.append(op.arrayPolar(editable, Number(v.count), point(Number(v.x), Number(v.y)), Number(v.angle), v.rotate === 'yes'), 'Додадена кружна низа.'));
                return;
            }
            if (cmd === 'ALIGN') {
                need();
                ask('ALIGN', 'Избери прва изворна/целна точка, па втора изворна/целна точка.', [choose('scale', 'Скалирај според парот точки', 'no', [{ value: 'no', label: 'Не — само Move и Rotate' }, { value: 'yes', label: 'Да — Move, Rotate и Scale' }])], v => { settings.current.alignScale = v.scale === 'yes'; start('align'); });
                return;
            }
            if (cmd === 'CHPROP') {
                need();
                ask('Properties', 'Промените се применуваат на избраните објекти.', [choose('layer', 'Леер', editable[0].layer, d.layers.filter(l => !l.locked && l.visible).map(l => l.name)), field('color', 'Боја (#RRGGBB или ByLayer)', editable[0].color ?? 'ByLayer', 'text'), field('weight', 'Дебелина во mm (0 = ByLayer)', editable[0].lineWidth ?? 0), choose('dash', 'Тип на линија', 'Continuous', ['Continuous', 'Dashed', 'Hidden', 'Center'])], v => {
                    if (v.color.toLowerCase() !== 'bylayer' && !/^#[a-f0-9]{6}$/i.test(v.color))
                        throw Error('Внеси #RRGGBB или ByLayer.');
                    const weight = Number(v.weight);
                    if (!Number.isFinite(weight) || weight < 0 || weight > 10)
                        throw Error('Дебелината мора да е 0–10 mm.');
                    change(editable.map(e => ({ ...e, layer: v.layer, color: v.color.toLowerCase() === 'bylayer' ? undefined : v.color, lineWidth: weight || undefined, dash: ({ Dashed: [12, 6], Hidden: [6, 4], Center: [20, 5, 3, 5] } as any)[v.dash] })), 'Својствата се изменети.');
                });
                return;
            }
            if (cmd === 'HATCH') {
                need();
                ask('HATCH', 'Шрафура на секоја избрана затворена граница. Генерираните линии се групирани.', [choose('pattern', 'Шема', 'ansi31', [{ value: 'solid', label: 'SOLID — пополнување' }, { value: 'ansi31', label: 'ANSI31 — паралелни линии' }, { value: 'cross', label: 'Cross — вкрстени линии' }]), field('spacing', 'Растојание (' + d.unit + ')', 100), field('angle', 'Агол (°)', 45)], v => o.append(editable.flatMap(e => op.hatch(e, v.pattern as any, Number(v.spacing), Number(v.angle), o.activeLayer)), 'Додадена шрафура.'));
                return;
            }
            if (cmd === 'DIVIDE' || cmd === 'MEASURE') {
                need();
                ask(cmd, cmd === 'DIVIDE' ? 'Точки меѓу еднакви делови на патеката.' : 'Точки на зададен интервал по патеката.', [field('value', cmd === 'DIVIDE' ? 'Број на делови' : 'Интервал (' + d.unit + ')', cmd === 'DIVIDE' ? 5 : 100)], v => o.append(editable.flatMap(e => op.pathMarkers(e, Number(v.value), cmd === 'MEASURE')), 'Додадени точки по патеката.'));
                return;
            }
            if (cmd === 'DIMSTYLE') {
                ask('Dimension style', 'Стилот се користи за новите коти и стрелки. Внеси 0 за автоматска висина според погледот.', [field('height', 'Висина на текстот (' + d.unit + ')', settings.current.dimHeight)], v => {
                    const n = Number(v.height);
                    if (!Number.isFinite(n) || n < 0)
                        throw Error('Висината мора да е нула или позитивна.');
                    settings.current.dimHeight = n;
                    o.report('Поставен стил за нови коти.');
                });
                return;
            }
            if (cmd === 'DIMANGULAR') {
                need(2);
                if (editable.length !== 2)
                    throw Error('Избери точно две прави линии.');
                start('dimangular');
                return;
            }
            if (cmd === 'MLEADER') {
                start('leader');
                return;
            }
            if (cmd === 'AREA') {
                if (editable.length) {
                    const list = editable.map(op.areaPerimeter), area = list.filter(x => x.closed).reduce((s, x) => s + x.area, 0), perimeter = list.reduce((s, x) => s + x.perimeter, 0);
                    setDetail({ title: 'AREA', text: `Плоштина на затворени контури: ${area.toLocaleString('en-US', { maximumFractionDigits: 4 })} ${d.unit}²\nПериметар / должина: ${perimeter.toLocaleString('en-US', { maximumFractionDigits: 4 })} ${d.unit}\n${list.length} објекти. Преклопените плоштини се собираат.` });
                    o.report(`AREA: ${area.toFixed(2)} ${d.unit}² · PERIMETER: ${perimeter.toFixed(2)} ${d.unit}`);
                }
                else
                    start('area');
                return;
            }
            if (cmd === 'LIST') {
                need();
                setDetail({ title: 'LIST · ' + editable.length + ' објекти', text: editable.slice(0, 100).map(e => { const b = bounds([e]), m = op.areaPerimeter(e); return `${e.kind.toUpperCase()} · ${e.layer}\nID: ${e.id}\nMin: ${b.minX.toFixed(3)}, ${b.minY.toFixed(3)}   Max: ${b.maxX.toFixed(3)}, ${b.maxY.toFixed(3)}\nДолжина: ${m.perimeter.toFixed(3)} ${d.unit}${m.closed ? '   Плоштина: ' + m.area.toFixed(3) + ' ' + d.unit + '²' : ''}${e.blockName ? '\nБлок: ' + e.blockName : ''}${e.text ? '\nТекст: ' + e.text : ''}`; }).join('\n\n') });
                return;
            }
            if (/^LAY(OFF|ON|ISO|UNISO|LOCK|UNLOCK|FRZ|THW|MCUR|CUR)$/.test(cmd)) {
                layerChange(cmd);
                return;
            }
            if (cmd === 'LAYDEL') {
                const unused = d.layers.filter(l => l.name !== o.activeLayer && l.name !== '0' && !d.entities.some(e => e.layer === l.name) && !d.blocks?.some(b => b.entities.some(e => e.layer === l.name)));
                if (!unused.length)
                    throw Error('Нема празни леери за бришење.');
                ask('Delete layer', 'Се бришат само празни леери.', [choose('name', 'Леер', unused[0].name, unused.map(l => l.name))], v => o.commit({ ...d, layers: d.layers.filter(l => l.name !== v.name) }, 'Избришан празен леер.'));
                return;
            }
            if (cmd === 'RENAME') {
                ask('Rename layer', 'Името се менува и на објектите во леерот.', [choose('layer', 'Леер', o.activeLayer, d.layers.map(l => l.name)), field('name', 'Ново име', o.activeLayer, 'text')], v => {
                    const name = v.name.trim();
                    if (!name || /[<>/\\":;?*|=]/.test(name) || d.layers.some(l => l.name === name && l.name !== v.layer))
                        throw Error('Невалидно или веќе постоечко име.');
                    if (v.layer === '0')
                        throw Error('Леерот 0 не се преименува.');
                    o.commit({ ...d, layers: d.layers.map(l => l.name === v.layer ? { ...l, name } : l), entities: d.entities.map(e => e.layer === v.layer ? { ...e, layer: name } : e), blocks: d.blocks?.map(b => ({ ...b, entities: b.entities.map(e => e.layer === v.layer ? { ...e, layer: name } : e) })) }, 'Преименуван леер.');
                    if (o.activeLayer === v.layer)
                        o.setActiveLayer(name);
                });
                return;
            }
            if (cmd === 'BLOCK') {
                need();
                const c = center(bounds(editable));
                ask('Create block', 'Дефиницијата се зачувува во Pixar Plus CAD проектот. DXF извозот ја задржува геометријата.', [field('name', 'Име на блок', 'Block 01', 'text'), field('x', 'Базна точка X', c.x), field('y', 'Базна точка Y', c.y)], v => {
                    const name = v.name.trim();
                    if (!name || d.blocks?.some(b => b.name === name))
                        throw Error('Внеси уникатно име за блок.');
                    const x = Number(v.x), y = Number(v.y);
                    if (!Number.isFinite(x) || !Number.isFinite(y))
                        throw Error('Невалидна базна точка.');
                    const id = uid(), def = { name, entities: editable.map(e => ({ ...e, id: uid(), blockId: undefined, blockName: undefined, groupId: undefined, matrix: multiply(translation(-x, -y), e.matrix) })) };
                    o.commit({ ...d, blocks: [...(d.blocks ?? []), def], entities: d.entities.map(e => editable.some(x => x.id === e.id) ? { ...e, blockId: id, blockName: name, groupId: undefined } : e) }, 'Дефиниран блок ' + name);
                });
                return;
            }
            if (cmd === 'INSERT') {
                if (!d.blocks?.length)
                    throw Error('Нема дефинирани блокови. Избери геометрија и користи BLOCK.');
                ask('Insert block', 'По поставките избери позиција за вметнување.', [choose('name', 'Блок', d.blocks[0].name, d.blocks.map(b => b.name)), field('scale', 'Фактор на скалирање', 1), field('angle', 'Ротација (°)', 0)], v => {
                    const s = Number(v.scale), a = Number(v.angle);
                    if (!Number.isFinite(s) || s <= 0 || !Number.isFinite(a))
                        throw Error('Внеси позитивен размер и валиден агол.');
                    settings.current.insertName = v.name;
                    settings.current.insertScale = s;
                    settings.current.insertAngle = a;
                    start('insert');
                });
                return;
            }
            if (cmd === 'GROUP' || cmd === 'UNGROUP') {
                need();
                const groupId = cmd === 'GROUP' ? uid() : undefined;
                change(editable.map(e => ({ ...e, groupId })), 'Групирањето е изменето.');
                return;
            }
            if (cmd === 'WBLOCK') {
                need();
                download(exportDxf({ ...d, entities: editable }), d.name + '-selection.dxf', 'application/dxf');
                o.report('Селекцијата е извезена во DXF.');
                return;
            }
            if (cmd === 'SELECTALL') {
                o.setSelection(new Set(d.entities.filter(e => { const l = d.layers.find(l => l.name === e.layer); return l?.visible && !l.locked && !o.hidden.has(e.id); }).map(e => e.id)));
                return;
            }
            if (cmd === 'SELECTSIMILAR') {
                need();
                o.setSelection(new Set(d.entities.filter(e => { const l = d.layers.find(l => l.name === e.layer); return l?.visible && !l.locked && !o.hidden.has(e.id) && editable.some(x => x.kind === e.kind && x.layer === e.layer); }).map(e => e.id)));
                return;
            }
            if (cmd === 'QSELECT') {
                ask('Quick select', 'Селектира видливи и отклучени објекти според филтерот.', [choose('kind', 'Тип', 'all', [{ value: 'all', label: 'Сите' }, ...['polyline', 'circle', 'arc', 'ellipse', 'text', 'point'].map(value => ({ value, label: value.toUpperCase() }))]), choose('layer', 'Леер', 'all', [{ value: 'all', label: 'Сите' }, ...d.layers.map(l => ({ value: l.name, label: l.name }))])], v => { const list = d.entities.filter(e => { const l = d.layers.find(l => l.name === e.layer); return l?.visible && !l.locked && !o.hidden.has(e.id) && (v.kind === 'all' || v.kind === e.kind) && (v.layer === 'all' || v.layer === e.layer); }); o.setSelection(new Set(list.map(e => e.id))); o.report('QSELECT · ' + list.length + ' објекти.'); });
                return;
            }
            if (cmd === 'DESELECT') {
                o.setSelection(new Set());
                return;
            }
            if (cmd === 'HIDEOBJECTS' || cmd === 'ISOLATEOBJECTS') {
                need();
                o.setHidden(new Set(cmd === 'HIDEOBJECTS' ? [...o.hidden, ...editable.map(e => e.id)] : d.entities.filter(e => !o.selection.has(e.id)).map(e => e.id)));
                o.setSelection(new Set());
                o.report('Објектите се привремено сокриени; UNISOLATEOBJECTS ги враќа.');
                return;
            }
            if (cmd === 'UNISOLATEOBJECTS') {
                o.setHidden(new Set());
                return;
            }
            if (cmd === 'PURGE') {
                const used = new Set(d.entities.map(e => e.layer));
                for (const b of d.blocks ?? [])
                    for (const e of b.entities)
                        used.add(e.layer);
                const layers = d.layers.filter(l => l.name === '0' || l.name === o.activeLayer || used.has(l.name)), blocks = d.blocks?.filter(b => d.entities.some(e => e.blockName === b.name));
                o.commit({ ...d, layers, blocks }, `PURGE · отстранети ${d.layers.length - layers.length} леери и ${(d.blocks?.length ?? 0) - (blocks?.length ?? 0)} дефиниции.`);
                return;
            }
            if (cmd === 'OVERKILL') {
                const list = op.deduplicate(editable.length ? editable : d.entities.filter(e => !d.layers.find(l => l.name === e.layer)?.locked)), ids = new Set((editable.length ? editable : d.entities.filter(e => !d.layers.find(l => l.name === e.layer)?.locked)).map(e => e.id)), removed = ids.size - list.length;
                if (!removed) {
                    o.report('OVERKILL · нема дупликати со исти својства.');
                    return;
                }
                replace(ids, list, `OVERKILL · отстранети ${removed} дупликати.`);
                return;
            }
            if (cmd === 'AUDIT') {
                const issues: string[] = [];
                const names = new Set(d.layers.map(l => l.name)), ids = new Set<string>();
                for (const e of d.entities) {
                    if (ids.has(e.id))
                        issues.push('Дупликат ID: ' + e.id);
                    ids.add(e.id);
                    if (!names.has(e.layer))
                        issues.push('Недостига леер: ' + e.layer);
                    if (!e.matrix.every(Number.isFinite) || samples(e).some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y)))
                        issues.push('Невалидна геометрија: ' + e.id);
                }
                setDetail({ title: 'AUDIT', text: issues.length ? issues.slice(0, 100).join('\n') : `Проверени ${d.entities.length} објекти и ${d.layers.length} леери.\nНе се пронајдени невалидни координати, дупликат ID или врски со леери.\nУвезени неподдржани CAD типови: ${d.warnings.length} забелешки.` });
                return;
            }
            if (cmd === 'UNITS') {
                ask('Drawing units', 'Се менува мерната единица за плотирање; координатите остануваат исти.', [choose('unit', 'Единици', d.unit, ['mm', 'cm', 'm', 'in'])], v => o.commit({ ...d, unit: v.unit as Drawing['unit'] }, 'Единиците се изменети.'));
                return;
            }
            handled = false;
        });
        return handled;
    }
    function consumePoint(p: Point) {
        if (!advancedTools.includes(o.tool))
            return false;
        safe(() => {
            const { tool, draft } = o, a = draft[0], targetEntity = o.drawing.entities.find(e => e.id === target.current);
            const pick = () => {
                const e = o.find(p);
                if (!e)
                    throw Error('Кликни на видлив и отклучен објект.');
                return e;
            };
            const cutters = (e: Entity) => o.drawing.entities.filter(x => x.id !== e.id && o.drawing.layers.find(l => l.name === x.layer)?.visible && !o.hidden.has(x.id) && (o.selection.size === 0 || o.selection.has(x.id)));
            if (tool === 'trim' || tool === 'extend') {
                const e = pick(), list = tool === 'trim' ? op.trim(e, cutters(e), p) : [op.extend(e, cutters(e), p)];
                replace(new Set([e.id]), list, tool.toUpperCase() + ' · геометријата е изменета.');
                o.setSelection(new Set([...o.selection].filter(id => id !== e.id)));
                return;
            }
            if (tool === 'offset') {
                if (!targetEntity) {
                    const e = pick();
                    target.current = e.id;
                    o.setDraft([p]);
                    o.report('Кликни на страната за офсет.');
                }
                else {
                    o.append([op.offset(targetEntity, settings.current.offset, p)], 'Додаден офсет.');
                    target.current = undefined;
                    o.setDraft([]);
                }
                return;
            }
            if (tool === 'break' || tool === 'breakatpoint') {
                if (!targetEntity) {
                    target.current = pick().id;
                    o.setDraft([p]);
                    return;
                }
                if (tool === 'break' && draft.length === 1) {
                    o.setDraft([...draft, p]);
                    return;
                }
                replace(new Set([targetEntity.id]), op.breakPath(targetEntity, tool === 'break' ? draft[1] : p, p), 'Патеката е прекината.');
                o.setDraft([]);
                o.setTool('select');
                return;
            }
            if (tool === 'matchprop') {
                if (!targetEntity) {
                    target.current = pick().id;
                    o.setDraft([p]);
                    o.report('Избери цел за својствата.');
                }
                else {
                    const e = pick(), l = o.drawing.layers.find(l => l.name === targetEntity.layer);
                    if (l?.locked)
                        throw Error('Изворниот леер е заклучен.');
                    change([{ ...e, layer: targetEntity.layer, color: targetEntity.color, lineWidth: targetEntity.lineWidth, dash: targetEntity.dash }], 'Копирани својства.');
                }
                return;
            }
            if (tool === 'dimradius' || tool === 'dimdiameter') {
                if (!targetEntity) {
                    const e = pick();
                    if (!['circle', 'arc'].includes(e.kind))
                        throw Error('Избери круг или лак.');
                    target.current = e.id;
                    o.setDraft([p]);
                }
                else {
                    o.append(op.radialDimension(targetEntity, p, o.activeLayer, h(), tool === 'dimdiameter'), 'Додадена радијална кота.');
                    o.setTool('select');
                    o.setDraft([]);
                }
                return;
            }
            if (tool === 'dimangular') {
                need(2);
                o.append(op.angularDimension(editable[0], editable[1], p, o.activeLayer, h()), 'Додадена аголна кота.');
                o.setDraft([]);
                o.setTool('select');
                return;
            }
            if (tool === 'point') {
                o.append([{ id: uid(), kind: 'point', matrix: [...IDENTITY], layer: o.activeLayer, center: p }], 'Додадена точка.');
                return;
            }
            if (tool === 'id') {
                o.report(`ID · X=${p.x.toFixed(4)} · Y=${p.y.toFixed(4)} ${o.drawing.unit}`);
                toast.info(`X ${p.x.toFixed(4)} · Y ${p.y.toFixed(4)} ${o.drawing.unit}`);
                o.setTool('select');
                return;
            }
            if (tool === 'insert') {
                const b = o.drawing.blocks?.find(b => b.name === settings.current.insertName);
                if (!b)
                    throw Error('Дефиницијата на блокот не постои.');
                const s = settings.current, id = uid(), m = multiply(translation(p.x, p.y), multiply(rotation(s.insertAngle, point(0, 0)), scaling(s.insertScale, point(0, 0))));
                const list = b.entities.map(e => ({ ...e, id: uid(), layer: e.layer === '0' ? o.activeLayer : e.layer, blockId: id, blockName: b.name, matrix: multiply(m, e.matrix) }));
                o.append(list, 'Вметнат блок ' + b.name);
                o.setSelection(new Set(list.map(e => e.id)));
                o.setTool('select');
                return;
            }
            if (tool === 'donut') {
                const s = settings.current, n = 128, points = Array.from({ length: n }, (_, i) => point(p.x + s.outer / 2 * Math.cos(i * 2 * Math.PI / n), p.y + s.outer / 2 * Math.sin(i * 2 * Math.PI / n))), loops = s.inner > 0 ? [Array.from({ length: n }, (_, i) => point(p.x + s.inner / 2 * Math.cos(i * 2 * Math.PI / n), p.y + s.inner / 2 * Math.sin(i * 2 * Math.PI / n)))] : [];
                o.append([{ ...polyline(points, o.activeLayer, true), filled: true, loops }], 'Додаден прстен.');
                return;
            }
            if (['spline', 'solid', 'leader', 'area'].includes(tool)) {
                o.setDraft([...draft, p]);
                return;
            }
            if (!draft.length) {
                o.setDraft([p]);
                return;
            }
            if (tool === 'polygon') {
                o.append([op.polygon(a, distance(a, p), settings.current.sides, o.activeLayer, Math.atan2(p.y - a.y, p.x - a.x))], 'Додаден многуаголник.');
                o.setDraft([]);
                return;
            }
            if (tool === 'ellipse') {
                if (draft.length === 1) {
                    if (distance(a, p) < 1e-8)
                        throw Error('Главната полуоска мора да има должина.');
                    o.setDraft([...draft, p]);
                    return;
                }
                const v = point(draft[1].x - a.x, draft[1].y - a.y), r = distance(a, draft[1]), ry = Math.abs((p.x - a.x) * (-v.y / r) + (p.y - a.y) * (v.x / r));
                if (ry < 1e-8)
                    throw Error('Малата полуоска мора да има должина.');
                o.append([{ id: uid(), kind: 'ellipse', layer: o.activeLayer, matrix: [...IDENTITY], center: a, radius: r, ry, rotation: Math.atan2(v.y, v.x) }], 'Додадена елипса.');
                o.setDraft([]);
                return;
            }
            if (tool === 'dimlinear' || tool === 'dimaligned') {
                if (draft.length === 1) {
                    o.setDraft([...draft, p]);
                    return;
                }
                o.append(op.dimension(a, draft[1], p, o.activeLayer, h(), tool === 'dimlinear' ? 'linear' : 'aligned'), 'Додадена кота.');
                o.setDraft([]);
                o.setTool('select');
                return;
            }
            if (tool === 'zoomwindow') {
                o.fitBounds({ minX: Math.min(a.x, p.x), maxX: Math.max(a.x, p.x), minY: Math.min(a.y, p.y), maxY: Math.max(a.y, p.y) });
                o.setDraft([]);
                o.setTool('select');
                return;
            }
            if (tool === 'stretch') {
                if (draft.length < 3) {
                    o.setDraft([...draft, p]);
                    return;
                }
                const b = draft[1], rect = { minX: Math.min(a.x, b.x), maxX: Math.max(a.x, b.x), minY: Math.min(a.y, b.y), maxY: Math.max(a.y, b.y) }, list = o.drawing.entities.filter(e => { const l = o.drawing.layers.find(l => l.name === e.layer); return l?.visible && !l.locked && !o.hidden.has(e.id) && (!o.selection.size || o.selection.has(e.id)); });
                change(op.stretch(list, rect, point(p.x - draft[2].x, p.y - draft[2].y)), 'STRETCH · темињата се поместени.');
                o.setDraft([]);
                o.setTool('select');
                return;
            }
            if (tool === 'align') {
                if (draft.length < 3) {
                    o.setDraft([...draft, p]);
                    return;
                }
                need();
                const m = op.alignMatrix(draft[0], draft[2], draft[1], p, settings.current.alignScale);
                change(editable.map(e => ({ ...e, matrix: multiply(m, e.matrix) })), 'ALIGN · изборот е порамнет.');
                o.setDraft([]);
                o.setTool('select');
                return;
            }
        });
        return true;
    }
    function finish(closed = false) {
        if (!['spline', 'solid', 'leader', 'area'].includes(o.tool))
            return false;
        safe(() => {
            const pts = o.draft.filter((p, i, list) => i === 0 || distance(p, list[i - 1]) > 1e-8);
            if (o.tool === 'spline')
                o.append([op.spline(pts, o.activeLayer, closed)], 'Додадена мазна крива.');
            if (o.tool === 'solid') {
                if (pts.length < 3)
                    throw Error('SOLID бара најмалку три темиња.');
                o.append([{ ...polyline(pts, o.activeLayer, true), filled: true }], 'Додаден пополнет полигон.');
            }
            if (o.tool === 'area') {
                if (pts.length < 3)
                    throw Error('AREA бара најмалку три темиња.');
                const a = op.areaPerimeter(polyline(pts, o.activeLayer, true));
                o.report(`AREA · ${a.area.toFixed(3)} ${o.drawing.unit}² · PERIMETER ${a.perimeter.toFixed(3)} ${o.drawing.unit}`);
                setDetail({ title: 'AREA', text: `Плоштина: ${a.area.toFixed(3)} ${o.drawing.unit}²\nПериметар: ${a.perimeter.toFixed(3)} ${o.drawing.unit}` });
            }
            if (o.tool === 'leader') {
                if (pts.length < 2)
                    throw Error('MLEADER бара најмалку две точки.');
                ask('Multileader', 'Текст на крајот на стрелката.', [field('text', 'Текст', '', 'text'), field('height', 'Висина на текстот', h())], v => {
                    if (!v.text.trim() || Number(v.height) <= 0 || !Number.isFinite(Number(v.height)))
                        throw Error('Внеси текст и позитивна висина.');
                    const n = distance(pts[0], pts[1]), u = point((pts[1].x - pts[0].x) / n, (pts[1].y - pts[0].y) / n), size = Number(v.height), a = pts[0], groupId = uid(), arrow = polyline([a, point(a.x + u.x * size - u.y * size * .3, a.y + u.y * size + u.x * size * .3), point(a.x + u.x * size + u.y * size * .3, a.y + u.y * size - u.x * size * .3)], o.activeLayer, true), list = [polyline(pts, o.activeLayer), { ...arrow, filled: true }, { id: uid(), kind: 'text' as const, layer: o.activeLayer, matrix: [...IDENTITY] as Entity['matrix'], center: pts[pts.length - 1], text: v.text, height: size }].map(e => ({ ...e, groupId }));
                    o.append(list, 'Додадена стрелка со текст.');
                });
            }
            o.setDraft([]);
            o.setTool('select');
        });
        return true;
    }
    const dialogs = <><Dialog open={!!params} onOpenChange={v => {
            if (!v)
                setParams(null);
        }}><DialogContent className="cad-dialog compact-dialog"><DialogHeader><DialogTitle>{params?.title}</DialogTitle><DialogDescription>{params?.description}</DialogDescription></DialogHeader><form className="cad-params-form" onSubmit={e => {
            e.preventDefault();
            try {
                params?.run(values);
                setParams(null);
                setError('');
            }
            catch (e) {
                setError(e instanceof Error ? e.message : 'Невалидни параметри.');
            }
        }}>{params?.fields.map((f, i) => <label className="field-label" key={f.key}>{f.label}{f.options ? <Picker label={f.label} value={values[f.key] ?? ''} options={f.options} onChange={v => setValues({ ...values, [f.key]: v })}/> : <input autoFocus={i === 0} type={f.type ?? 'number'} step="any" value={values[f.key] ?? ''} onChange={e => setValues({ ...values, [f.key]: e.target.value })} maxLength={f.type === 'text' ? 200 : undefined}/>}</label>)}{error && <p className="parameter-error" role="alert">{error}</p>}<div className="parameter-footer"><button type="button" className="secondary-button" onClick={() => setParams(null)}>Откажи</button><button type="submit" className="primary-button">Примени</button></div></form></DialogContent></Dialog><Dialog open={!!detail} onOpenChange={v => {
            if (!v)
                setDetail(null);
        }}><DialogContent className="cad-dialog detail-dialog"><DialogHeader><DialogTitle>{detail?.title}</DialogTitle><DialogDescription>Податоци од тековниот цртеж.</DialogDescription></DialogHeader><pre className="cad-detail">{detail?.text}</pre><button className="primary-button" onClick={() => setDetail(null)}>Затвори</button></DialogContent></Dialog></>;
    return { execute, consumePoint, finish, dialogs };
}
