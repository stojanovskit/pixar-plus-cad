"""Build the matching, downloadable GPL application source without checkout state."""
import pathlib, zipfile, json
root = pathlib.Path(__file__).resolve().parent.parent
target = root / 'public/pixar-plus-cad-source.zip'
excluded = {'node_modules', '.git', '.sites-runtime', '.wrangler', 'dist', 'site', '.next', '.vinext', '.agents', '.codex', 'outputs', 'work', '__pycache__'}
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if not path.is_file() or path == target or any(p in excluded for p in rel.parts) or path.name.startswith('.env') or path.suffix == '.tsbuildinfo':
            continue
        if rel.as_posix() == '.openai/hosting.json':
            archive.writestr('pixar-plus-cad/.openai/hosting.json', json.dumps({'d1': None, 'r2': None}, indent=2)+'\n')
        else:
            archive.write(path, 'pixar-plus-cad/' + rel.as_posix())
print('SOURCE_ARCHIVE_OK', target.stat().st_size)
