"""Remove obsolete generated assets before a portable build."""
from pathlib import Path
from shutil import rmtree

output = Path(__file__).resolve().parent.parent / 'site'
if output.exists():
    rmtree(output)
