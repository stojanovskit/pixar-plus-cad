# Pixar Plus CAD 2

A 2D browser CAD workspace with a Macedonian interface and an AutoCAD-inspired ribbon. File parsing happens in a local browser worker; drawings are not uploaded to a conversion service.

## Working tools

The searchable command catalogue contains **111 commands and options**, with **202 command names and aliases**. This counts view, file, selection and layer actions alongside geometry commands; it is not a claim to implement all AutoCAD commands or every sub-option.

- Ribbon tabs: Home, Insert, Annotate, Modify, View, Manage and Output; quick access, File menu, Model/Layout tabs, layer/properties palettes and status controls.
- Command line with absolute, relative and polar coordinates, numeric radii and transform values, suggestions, Tab completion, command recall, empty Enter repeat, F2 history and Ctrl+K command search.
- Line, polyline, rectangle, circle, arc, ellipse, polygon, interpolated spline, point, donut and solid polygon.
- Move, copy, rotate, uniform scale, mirror, trim, extend, offset, fillet, chamfer, break, join, explode, stretch, lengthen, rectangular/polar arrays and two-pair alignment.
- Polyline close/open/reverse; match properties and selection properties; Divide/Measure markers.
- Multiline text, leaders, linear/aligned/radial/diameter/angular geometric dimensions, area/perimeter, distance, coordinates and object listing.
- Solid, ANSI31 and cross hatches, including compound boundaries. Solid fills and line patterns survive DXF export. Compound fills use even-odd rendering in canvas, SVG and PDF.
- Block definitions/insertions and groups in `.nookcad` projects. Selection DXF export with WBLOCK.
- Layer visibility, color, locking, plot inclusion, physical line weight, isolation, renaming and unused layer deletion.
- Select all/similar, Quick Select, object hide/isolate/restore, undo/redo, clipboard, Purge, duplicate removal and geometry audit.
- ASCII DXF and native DWG import through LibreDWG WebAssembly; validated `.nookcad` project import/export.
- Vector PDF/SVG plotting with A4–A0/custom paper, margins, fit or numeric scale, plot windows, view/selection areas, color/monochrome, line weights and embedded Cyrillic fonts.
- Layout 1 is an actual paper preview using the shared Page Setup / Plot settings.
- Mobile workspace with a compact touch toolbar, every command in category sheets, 44px controls, multi-selection without Shift, Finish/Close/Cancel actions, touch pan/pinch zoom and larger hit/snap tolerances. Layer/properties sheets and the Plot dialog fit phones in portrait or landscape. The command line follows the virtual keyboard; screen resizing preserves the center of the drawing. Cancelled gestures and navigation never commit geometry; touch double-taps do not finish a drawing accidentally.

The implementation catalogue and descriptions are in `lib/cad/commands.ts`. Commands operate on visible, unlocked geometry. FILLET/CHAMFER and angular dimensions require exactly two straight lines. TRIM/EXTEND use the preselected cutting boundaries, or all visible geometry when there is no selection. OFFSET requires an outline rather than a filled region. MIRROR retains the original and creates a reflected copy. SPLINE/SOLID/AREA/MLEADER finish with Enter.

## Compatibility and limits

This is an independent **2D drafting app**, not Autodesk AutoCAD or an exact GUI/engine replica. It does not implement 3D solids, constraints, LISP, Xrefs, original AutoCAD layouts, CTB/STB, SHX fonts, dynamic blocks or associative dimensions/arrays.

Imported block references and dimensions are expanded into editable geometry. New Pixar Plus CAD block definitions and group relationships survive in `.nookcad` projects; DXF export flattens these relationships into geometry. Imported patterned hatches retain their boundaries; solid hatch fills are retained. Splines, bulged polylines and non-circular transformed curves may be represented/exported as segments. TRIM/BREAK of curves generate segmented paths. Polyline OFFSET uses miter joints and does not resolve self-intersections. Unsupported input entities are reported rather than silently claimed as complete. Binary DXF must first be converted to ASCII DXF. DWG export is unavailable; import compatibility depends on LibreDWG.

Input limits: 50 MB and 150,000 entities. Array operations are limited to 30,000 resultant objects. This version has no cloud document storage/autosave: download DXF or a `.nookcad` project before closing. Project files preserve block definitions, groups, fills and entity properties; page setup/dimension style are session settings.

Plot uses declared drawing units. Print PDFs at **Actual Size / 100%** on matching paper. Layout 1 previews the plot result; it is not an imported AutoCAD paper space with editable viewports.

## Development and validation

React / Vinext / Vite, Node 22.13+. Run `pnpm install` and `pnpm dev`; the supplied scripts choose the Sites runtime profile. Build with `pnpm build`. Keep `public/wasm` and `public/fonts` in the deployment.

```bash
pnpm test:cad
node node_modules/typescript/bin/tsc --noEmit
```

Tests cover 48 geometry/serialization scenarios and 18 command flows, locked edits, React server rendering, command/alias uniqueness, DXF geometry/Unicode/layer/pattern/fill roundtrips, plot sizes/scales, snapping, DWG 2000/2018 conversion and a PDF with Cyrillic text. Mobile tests add 40 checks for pinch anchoring, two/three-finger gesture isolation, pointer cancellation/lost capture, Pan, selection, rotation/keyboard resizing and touch double-click suppression. React command and viewport tests exercise the actual state and callbacks without a browser. They do not replace visual/pointer QA in a browser or on a physical phone. The current build environment did not provide the supervised browser QA capability.

Set `CAD_TEST_OUTPUT=/absolute/path` for test PDF/SVG output; the runner creates the folder. DWG fixtures are from https://github.com/mlightcad/libredwg-web/tree/master/test/test-data under the upstream GPL license.

## License

Pixar Plus CAD is GPL-3.0. Matching source is downloadable from the app's Help panel. LibreDWG Web (`@mlightcad/libredwg-web` 0.7.14) is GPL-3.0: https://github.com/mlightcad/libredwg-web. DXF Parser and jsPDF are MIT. DejaVu Sans's license accompanies the font. Dependency versions and notices are identified in `package.json` and `pnpm-lock.yaml`.
