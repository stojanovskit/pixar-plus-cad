import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: { alias: { '@': fileURLToPath(new URL('.', import.meta.url)) } },
  worker: { format: 'es' },
  build: { outDir: 'site', emptyOutDir: true, chunkSizeWarningLimit: 1600 },
});
