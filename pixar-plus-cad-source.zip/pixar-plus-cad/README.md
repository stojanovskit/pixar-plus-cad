# Pixar Plus Print & Copy Studio — CAD за веб и мобилен

Брендирана апликација со оригиналното лого и CMYK боите на студиото. Ова е самостојната верзија на апликацијата со мобилниот распоред. Сите CAD операции и читањето на DXF/DWG се извршуваат во прелистувачот. Хостингот сервира HTML, CSS, JavaScript, фонтови и WebAssembly; на него не е потребен Node.js или PHP.

## GitHub Pages

1. Распакувај го ZIP-от на компјутерот.
2. На GitHub создај нов репозиториум, на пример `pixar-plus-cad`. За GitHub Free, избери **Public**. Репозиториумот и Pages страницата ќе бидат јавни.
3. Со **Add file → Upload files** качи ја содржината на `pixar-plus-cad` во коренот на репозиториумот. Не го качувај самиот ZIP како единствен фајл. Мора да се качат и `.github/workflows/pages.yml`, `package.json`, `pnpm-lock.yaml`, `public/`, `components/` и останатите фајлови. Ако го користиш GitHub Desktop, додај ја истата папка и направи Publish repository.
4. Во **Settings → Pages → Build and deployment → Source**, избери **GitHub Actions**.
5. Во **Actions**, отвори **Publish Pixar Plus CAD → Run workflow** на гранката `main` (или `master`). За следните промени објавувањето се активира автоматски при commit/push на таа гранка.
6. Почекај зелена ознака. Вистинскиот линк ќе се појави во **Settings → Pages** и во резултатот од објавата. Не е потребно рачно да менуваш адреси во кодот.

GitHub Actions ја гради апликацијата од изворниот код. Node.js се користи во build-от на GitHub, а не на твој сервер. Во пакетот има и веќе изградена верзија во `site/`.

## cPanel, FTP или друг статичен хостинг

1. Во ZIP-от отвори ја папката `pixar-plus-cad/site/`.
2. Качи ја **содржината** на `site/` во празна папка, на пример `public_html/cad/`. `index.html`, `assets/`, `wasm/` и `fonts/` треба да бидат директно во `public_html/cad/`.
3. Отвори ја адресата на таа папка во прелистувач, со завршна коса црта: `https://твој-домен/cad/`.

За поставување во коренот на доменот, качи ја истата содржина директно во `public_html/`. Сочувај ги постојните фајлови на твојот друг сајт; ако веќе има веб-страница, користи посебна папка како `cad/`.

Патеките работат и во корен и во потпапка, вклучително и GitHub Pages проект. Качи ги `wasm/`, `fonts/` и `pixar-plus-cad-source.zip` за да работат DWG, кириличниот PDF и преземањето на изворниот код. `.htaccess` е за Apache; GitHub Pages и Nginx го игнорираат. Ако твојот Apache враќа грешка 500 по поставувањето, провери дали дозволува `.htaccess` или отстрани го тој фајл и постави `application/wasm` MIME тип преку хостингот.

Не отворај `index.html` преку `file://`. Користи веб-сервер. Оваа верзија нема ChatGPT најава или ограничување на пристапот; приватноста на објавениот сајт ја определува твојот хостинг. Цртежите се обработуваат локално и апликацијата не ги качува на GitHub. Зачувај го резултатот како DXF или `.nookcad` пред затворање.

## Измена и нов build

На компјутер со Node.js 24 и pnpm 11.25:

```bash
pnpm install --frozen-lockfile
pnpm build
```

Новата верзија се создава во `site/`. За GitHub, направи commit/push на изменетиот изворен код и workflow-от автоматски ќе го изгради и објави. За cPanel/FTP, качи ја новата содржина од `site/`.

За локален преглед: `pnpm dev`. За проверките: `pnpm test:cad`.

## Опсег

111 постојни 2D команди и опции, DXF/DWG увоз, леери, Move/Rotate/Scale, блокови/групи, коти и PDF/SVG Plot. Не е целосен AutoCAD: нема 3D, LISP, DWG извоз или оригинални AutoCAD layouts. Во `README-SITES.md` се наведени деталните ограничувања на CAD моторот. Кодот и LibreDWG се GPL-3.0; зачувај ги лиценците и достапниот изворен код.

Автоматски се проверуваат build-от, CAD логиката, мобилните гестови и патеките за ресурси. Визуелна проверка на вистински телефон не е направена.

Официјална документација:

- https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
