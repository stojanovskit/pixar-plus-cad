import assert from 'node:assert/strict';
import { act, create, type ReactTestRenderer } from 'react-test-renderer';
import Workspace from '../components/cad/Workspace';
import useCadViewport from '../components/cad/useCadViewport';
import { CadGestures, pointerHitRadius, pointerTapSlop, resizeView } from '../lib/cad/gestures';
import { newDrawing, point } from '../lib/cad/model';
import { screenToWorld } from '../lib/cad/render';

(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
const view = { x: 20, y: 40, scale: 2 }, gestures = new CadGestures();
let assertions = 0;
function equal(actual: unknown, expected: unknown) { assert.deepEqual(actual, expected); assertions++; }

// Pinch remains anchored at its midpoint and never submits a drawing point.
gestures.down(1, point(100, 100), view, 'draw', false, 'touch');
equal(gestures.down(2, point(200, 100), view, 'draw', false, 'touch'), null);
const enlarged = gestures.move(2, point(300, 100)).view!;
equal(enlarged.scale, 4);
equal(screenToWorld(point(200, 100), enlarged), screenToWorld(point(150, 100), view));
equal(gestures.up(2, enlarged), null);
equal(gestures.move(1, point(150, 120)), {});
equal(gestures.up(1, enlarged), null);
equal(gestures.down(3, point(50, 50), enlarged, 'draw', false, 'touch')?.mode, 'draw');
equal(gestures.up(3, enlarged)?.mode, 'draw');

// A third finger pauses navigation; lifting it resumes without a jump.
gestures.down(4, point(100, 100), view, 'select', false, 'touch');
gestures.down(5, point(200, 100), view, 'select', false, 'touch');
gestures.down(6, point(300, 100), view, 'select', false, 'touch');
equal(gestures.move(4, point(90, 100)), {});
equal(gestures.up(6, view), null);
equal(gestures.move(4, point(90, 100)).view, view);
equal(gestures.up(4, view, true), null);
equal(gestures.up(5, view), null);

// Cancel/lost capture cannot commit a line, replace selection or leave stale pointers.
gestures.down(7, point(20, 20), view, 'draw', false, 'touch');
equal(gestures.up(7, view, true), null);
equal(gestures.up(7, view), null);
gestures.down(8, point(20, 20), view, 'select', true, 'touch');
equal(gestures.up(99, view, true), null);
equal(gestures.up(8, view)?.extend, true);
gestures.down(9, point(20, 20), view, 'draw', false, 'touch');
gestures.reset();
equal(gestures.up(9, view), null);

// Single-finger Pan and mouse gestures retain the original scale and behavior.
gestures.down(10, point(20, 30), view, 'pan', false, 'touch');
equal(gestures.move(10, point(50, 80)).view, { x: 50, y: 90, scale: 2 });
equal(gestures.up(10, view)?.mode, 'pan');
gestures.down(11, point(20, 30), view, 'select', true, 'mouse');
equal(gestures.move(11, point(90, 90)).box, { start: point(20, 30), end: point(90, 90) });
equal(gestures.up(11, view)?.extend, true);
equal([pointerTapSlop('mouse'), pointerTapSlop('touch')], [5, 12]);
equal([pointerHitRadius('mouse'), pointerHitRadius('pen'), pointerHitRadius('touch')], [8, 10, 16]);

// Rotation and keyboard resize preserve the world point at the screen's center.
const portrait = { w: 390, h: 500 }, landscape = { w: 844, h: 170 };
const rotated = resizeView(view, portrait, landscape);
equal(screenToWorld(point(landscape.w / 2, landscape.h / 2), rotated), screenToWorld(point(portrait.w / 2, portrait.h / 2), view));
equal(resizeView(rotated, landscape, portrait), view);

// Workspace routes cancellation separately and suppresses synthetic touch double-clicks.
let doubles = 0, cancelled = 0, released = 0, workspace: ReactTestRenderer;
await act(async () => { workspace = create(<Workspace drawing={newDrawing()} view={view} size={portrait} selection={new Set()} grid={false} draft={[]} cursor={null} snapped={false} tool="polyline" box={null} activeLayer="0" onDown={() => { }} onMove={() => { }} onUp={() => { released++; }} onCancel={() => { cancelled++; }} onWheel={() => { }} onDouble={() => { doubles++; }}/>); });
const canvas = workspace!.root.findByProps({ className: 'interaction-canvas tool-polyline' });
canvas.props.onPointerDown({ pointerType: 'touch' });
canvas.props.onDoubleClick();
equal(doubles, 0);
canvas.props.onPointerCancel({});
canvas.props.onLostPointerCapture({});
equal(cancelled, 2);
equal(released, 0);
canvas.props.onPointerDown({ pointerType: 'mouse' });
canvas.props.onDoubleClick();
equal(doubles, 1);
await act(async () => workspace!.unmount());

// Exercise the actual viewport hook against focus, keyboard, rotation and browser zoom events.
const viewport = Object.assign(new EventTarget(), { height: 800, scale: 1 });
const windowMock = Object.assign(new EventTarget(), { innerWidth: 390, innerHeight: 800, visualViewport: viewport });
class Input {}
class Textarea {}
const properties = new Map<string, string>();
const documentMock = Object.assign(new EventTarget(), { activeElement: null as unknown, documentElement: { style: { setProperty: (k: string, v: string) => properties.set(k, v), removeProperty: (k: string) => properties.delete(k) } } });
const frames = new Map<number, FrameRequestCallback>();
let nextFrame = 0;
Object.assign(globalThis, {
  window: windowMock, document: documentMock, HTMLInputElement: Input, HTMLTextAreaElement: Textarea,
  requestAnimationFrame: (callback: FrameRequestCallback) => { frames.set(++nextFrame, callback); return nextFrame; },
  cancelAnimationFrame: (id: number) => frames.delete(id),
});
let keyboard = false, harness: ReactTestRenderer;
function ViewportHarness() { keyboard = useCadViewport(); return <div/>; }
await act(async () => { harness = create(<ViewportHarness/>); });
async function dispatch(target: EventTarget, type: string) {
  await act(async () => { target.dispatchEvent(new Event(type)); const pending = [...frames.values()]; frames.clear(); pending.forEach(callback => callback(0)); });
}
equal(properties.get('--cad-viewport-height'), '800px');
equal(keyboard, false);
documentMock.activeElement = new Input();
viewport.height = 390;
await dispatch(viewport, 'resize');
equal(properties.get('--cad-viewport-height'), '390px');
equal(keyboard, true);
windowMock.innerWidth = 844; viewport.height = 230;
await dispatch(windowMock, 'resize');
equal(keyboard, true);
documentMock.activeElement = null;
await dispatch(documentMock, 'focusout');
equal(keyboard, false);
viewport.height = 390;
await dispatch(viewport, 'resize');
equal(properties.get('--cad-viewport-height'), '390px');
viewport.scale = 2; viewport.height = 195;
await dispatch(viewport, 'resize');
equal(properties.get('--cad-viewport-height'), '390px');
await act(async () => harness!.unmount());
equal(properties.has('--cad-viewport-height'), false);
await dispatch(viewport, 'resize');
equal(frames.size, 0);

console.log('MOBILE_OK ' + JSON.stringify({ assertions, pinchNeverDraws: true, cancellationNeverCommits: true, keyboardAndRotation: true, touchDoubleClickIgnored: true }));
