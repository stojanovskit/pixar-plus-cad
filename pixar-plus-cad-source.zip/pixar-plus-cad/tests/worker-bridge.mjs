// Node integration shim for the built worker's browser/WASM fetch path; no UI browser.
import { parentPort, workerData } from 'node:worker_threads';
const fetchReady = globalThis.fetch;
globalThis.self = globalThis;
globalThis.location = { href: workerData.url };
globalThis.WorkerGlobalScope = class WorkerGlobalScope {};
globalThis.postMessage = value => parentPort.postMessage(value);
globalThis.fetch = fetchReady;
globalThis.process = undefined;
await import(workerData.entry);
parentPort.on('message', data => self.onmessage({ data }));
parentPort.postMessage({ ready: true });
