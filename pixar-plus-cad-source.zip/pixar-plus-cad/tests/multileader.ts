import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseDxf } from '../lib/cad/import';
import { apply, transformEntities, translation } from '../lib/cad/model';
import { exportDxf, defaultPlot, plotSvg } from '../lib/cad/output';
import { serializeProject, parseProject } from '../lib/cad/project';

// Reduced real AutoCAD 2018 DWG export. It has just one leader-line vertex:
// the second point comes from the enclosing leader node, not the content anchor.
const text = fs.readFileSync('tests/fixtures/multileader-label.dxf', 'utf8');
const drawing = parseDxf(text, 'multileader-label.dxf');
assert.equal(drawing.entities.length, 3);
assert.ok(drawing.entities.every(e => e.sourceType === 'MULTILEADER' && e.layer === 'Annotations'));
assert.equal(new Set(drawing.entities.map(e => e.groupId)).size, 1);
assert.ok(drawing.entities[0].groupId);
const label = drawing.entities.find(e => e.kind === 'text')!;
assert.equal(label.text, 'xx\nxx');
assert.equal(label.height, 4);
assert.equal(label.center!.x, -2237.1284406528);
assert.equal(label.center!.y, 605.2183823688756);
const line = drawing.entities.find(e => e.kind === 'polyline' && !e.filled)!;
assert.deepEqual(line.points, [{ x: -2577.704248811191, y: 142.4285046562727 }, { x: -2239.4884406528, y: 607.2183823688756 }, { x: -2239.1284406528, y: 607.2183823688756 }]);
const arrow = drawing.entities.find(e => e.filled)!;
assert.equal(arrow.closed, true);
assert.deepEqual(arrow.points![0], line.points![0]);
assert.ok(!drawing.warnings.some(w => /MULTILEADER.*неподдржани објекти/.test(w)));

// A second, separate branch tests nesting and multiple arrows on one annotation.
const secondBranch = '302\nLEADER{\n290\n1\n291\n1\n10\n30\n20\n40\n11\n-1\n21\n0\n40\n8\n304\nLEADER_LINE{\n10\n10\n20\n20\n10\n15\n20\n30\n92\n-1023410171\n305\n}\n303\n}\n';
const multiple = parseDxf(text.replace('301\n}', secondBranch + '301\n}'), 'multiple.dxf');
assert.equal(multiple.entities.length, 5);
assert.equal(multiple.entities.filter(e => e.kind === 'text').length, 1);
const branch = multiple.entities.find(e => e.points?.[0].x === 10 && !e.filled)!;
assert.deepEqual(branch.points, [{ x: 10, y: 20 }, { x: 15, y: 30 }, { x: 30, y: 40 }, { x: 22, y: 40 }]);
assert.equal(branch.color, '#0000ff');
const byLayer = parseDxf(text.replace('8\nAnnotations\n', '8\nAnnotations\n420\n16711680\n').replace('91\n-1056964608\n', '91\n-1073741824\n'), 'bylayer.dxf');
assert.equal(byLayer.entities.find(e => e.kind === 'polyline' && !e.filled)?.color, undefined);
assert.equal(new Set(multiple.entities.map(e => e.groupId)).size, 1);
assert.equal(parseDxf(text.replace('0\nMULTILEADER\n', '0\nMLEADER\n'), 'alias.dxf').entities.length, 3);

// Reproduce the report's 36 records; a following LINE must still be read.
const start = text.indexOf('0\nMULTILEADER\n'), end = text.lastIndexOf('0\nENDSEC\n');
const repeated = parseDxf(text.slice(0, start) + text.slice(start, end).repeat(36) + '0\nLINE\n8\nAnnotations\n10\n0\n20\n0\n11\n100\n21\n0\n' + text.slice(end), '36-labels.dxf');
assert.equal(repeated.entities.filter(e => e.sourceType === 'MULTILEADER').length, 108);
assert.equal(repeated.entities.filter(e => e.kind === 'text').length, 36);
assert.equal(new Set(repeated.entities.filter(e => e.sourceType === 'MULTILEADER').map(e => e.groupId)).size, 36);
assert.equal(repeated.entities.at(-1)?.sourceType, 'LINE');

assert.throws(() => parseDxf(text.replace('8\nAnnotations\n', '8\nAnnotations\n60\n1\n'), 'hidden.dxf'), /Нема поддржана 2D/);
assert.throws(() => parseDxf(text.replace('8\nAnnotations\n', '8\nAnnotations\n67\n1\n'), 'paper.dxf'), /Нема поддржана 2D/);
const blockContent = parseDxf(text.replace('296\n0\n', '296\n1\n'), 'block.dxf');
assert.equal(blockContent.entities.length, 3);
assert.ok(blockContent.warnings.some(w => w.includes('блоковската содржина')));
const customArrow = parseDxf(text.replace('301\n}', '301\n}\n342\nABCD'), 'custom.dxf');
assert.ok(customArrow.entities.some(e => e.filled));
assert.ok(customArrow.warnings.some(w => w.includes('сопствените симболи')));
const missingAnchor = parseDxf(text.replace('12\n-2237.1284406528\n22\n609.2183823688756\n32\n0.0\n', ''), 'incomplete.dxf');
assert.equal(missingAnchor.entities.length, 2);
assert.ok(missingAnchor.warnings.some(w => w.includes('позицијата на текстот')));

// Imported annotations can be edited, saved as a project and plotted/exported.
const moved = transformEntities(drawing.entities, new Set(drawing.entities.map(e => e.id)), translation(100, 200));
assert.deepEqual(apply(moved[0].matrix, moved[0].points![0]), { x: line.points![0].x + 100, y: line.points![0].y + 200 });
const saved = parseProject(serializeProject({ ...drawing, entities: moved }));
assert.deepEqual(saved.entities, JSON.parse(JSON.stringify(moved)));
const roundtrip = parseDxf(exportDxf(drawing), 'exported.dxf');
assert.equal(roundtrip.entities.length, 3);
assert.equal(roundtrip.entities.find(e => e.kind === 'text')?.text, 'xx\nxx');
const svg = plotSvg(drawing, defaultPlot, new Set());
assert.ok(svg.includes('xx'));
assert.ok(!svg.includes('NaN'));
console.log('MULTILEADER_OK: real context coordinates, doglegs, 36 annotations, multiple branches, colors, visibility, project editing and plot/export.');
