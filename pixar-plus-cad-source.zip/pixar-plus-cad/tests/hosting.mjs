import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Worker } from 'node:worker_threads';

const root = path.resolve('site'), requests = [];
const prefixes = ['/pixar-plus-cad/', '/sub/cad/', '/'];
const types = { '.js': 'application/javascript', '.css': 'text/css', '.html': 'text/html', '.wasm': 'application/wasm', '.ttf': 'font/ttf', '.zip': 'application/zip' };
const server = createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  requests.push(pathname);
  const prefix = prefixes.find(value => pathname.startsWith(value));
  const relative = pathname.slice(prefix.length) || 'index.html';
  const target = path.resolve(root, relative);
  if (!target.startsWith(root + path.sep)) { res.writeHead(404); res.end(); return; }
  try { const bytes = await readFile(target); res.writeHead(200, { 'Content-Type': types[path.extname(target)] ?? 'application/octet-stream' }); res.end(bytes); }
  catch { res.writeHead(404); res.end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const files = await readdir(path.join(root, 'assets'));
const workerFile = files.find(name => name.startsWith('import.worker-') && name.endsWith('.js'));
assert.ok(workerFile);
const checks = [];

async function runImport(prefix, fixture) {
  const worker = new Worker(new URL('./worker-bridge.mjs', import.meta.url), { workerData: { entry: pathToFileURL(path.join(root, 'assets', workerFile)).href, url: `${origin}${prefix}assets/${workerFile}` } });
  const bytes = await readFile(path.resolve('tests/fixtures', fixture));
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { worker.terminate(); reject(Error('Built worker import timed out.')); }, 20000);
    worker.on('error', error => { clearTimeout(timer); worker.terminate(); reject(error); });
    worker.on('message', message => {
      if (message.ready) worker.postMessage({ name: fixture, buffer: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) });
      if (message.error) { clearTimeout(timer); worker.terminate(); reject(Error(message.error)); }
      if (message.drawing) { clearTimeout(timer); worker.terminate(); resolve(message.drawing); }
    });
  });
}

try {
  for (const prefix of prefixes) {
    const response = await fetch(origin + prefix);
    assert.equal(response.status, 200);
    const html = await response.text();
    const urls = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(match => match[1]);
    assert.ok(urls.some(value => value.endsWith('.js')));
    for (const relative of urls) {
      assert.ok(relative.startsWith('./'), `Absolute HTML asset: ${relative}`);
      const url = new URL(relative, origin + prefix);
      assert.ok(url.pathname.startsWith(prefix));
      const asset = await fetch(url);
      assert.equal(asset.status, 200, url.pathname);
      if (relative.endsWith('.css')) {
        const css = await asset.text();
        for (const [, font] of css.matchAll(/url\(([^)]+\.ttf)\)/g)) {
          const fontUrl = new URL(font, url);
          assert.ok(fontUrl.pathname.startsWith(prefix));
          assert.equal((await fetch(fontUrl)).status, 200);
        }
      }
    }
    assert.equal((await fetch(origin + prefix + 'pixar-plus-logo.jpg')).status, 200);
    const pdfFontUrl = new URL('fonts/DejaVuSans.ttf', origin + prefix);
    assert.equal((await fetch(pdfFontUrl)).status, 200);
    const wasm = await fetch(origin + prefix + 'wasm/libredwg-web.wasm');
    assert.equal(wasm.headers.get('content-type'), 'application/wasm');
    assert.equal(new Uint8Array(await wasm.arrayBuffer()).length, 9496803);
    assert.equal((await fetch(origin + prefix + 'pixar-plus-cad-source.zip')).status, 200);
    const before = requests.length;
    const drawing = await runImport(prefix, 'example_2018.dwg');
    assert.ok(drawing.entities.length > 10);
    const workerRequests = requests.slice(before);
    assert.ok(workerRequests.includes(prefix + 'wasm/libredwg-web.wasm'));
    assert.ok(workerRequests.every(value => value.startsWith(prefix)));
    checks.push({ path: prefix, assets: urls.length, dwgEntities: drawing.entities.length });
  }
  console.log('STATIC_HOSTING_OK ' + JSON.stringify(checks));
} finally { await new Promise(resolve => server.close(resolve)); }
