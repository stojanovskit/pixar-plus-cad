import assert from 'node:assert/strict';
import { newDrawing } from '../lib/cad/model';
import { readDwgLayerStates, applyDwgLayerStates } from '../lib/cad/dwg-layers';
import { parseDxf } from '../lib/cad/import';
import fs from 'node:fs';

const entries = [
    { name: 'On', off: 0, frozen: 0, locked: 0, plotflag: 1, frozen_in_new: 1 },
    { name: 'Off', off: 1, frozen: 0, locked: 1, plotflag: 0 },
    { name: 'Frozen', off: 0, frozen: 1, locked: 0, plotflag: 1 },
    { name: 'Invalid', off: null, frozen: null, locked: null, plotflag: null }
];
const states = readDwgLayerStates({ dwg_getall_LAYER: () => entries.map((_, i) => i), dwg_dynapi_entity_data: (i, field) => (entries[i] as Record<string, unknown>)[field] }, 1);
assert.equal(states.size, 3);
const base = newDrawing().layers[0];
const d = applyDwgLayerStates({ ...newDrawing(), layers: entries.map(e => ({ ...base, name: e.name, visible: false })) }, states);
assert.equal(d.layers[0].visible, true);
assert.equal(d.layers[1].visible, false);
assert.equal(d.layers[1].locked, true);
assert.equal(d.layers[1].plot, false);
assert.equal(d.layers[2].visible, false);
assert.equal(d.layers[3].visible, false);

// Freeze-in-new-viewports (bit 2) does not hide a layer in Model Space.
const text = fs.readFileSync('tests/fixtures/multileader-label.dxf', 'utf8');
const frozenInNew = parseDxf(text.replace('70\n0\n62\n4\n', '70\n2\n62\n4\n'), 'viewport.dxf');
assert.equal(frozenInNew.layers.find(l => l.name === 'Annotations')!.visible, true);
const frozen = parseDxf(text.replace('70\n0\n62\n4\n', '70\n1\n62\n4\n'), 'frozen.dxf');
assert.equal(frozen.layers.find(l => l.name === 'Annotations')!.visible, false);
const off = parseDxf(text.replace('62\n4\n', '62\n-4\n'), 'off.dxf');
assert.equal(off.layers.find(l => l.name === 'Annotations')!.visible, false);
console.log('DWG_LAYERS_OK: native on/off/frozen/lock/plot flags and DXF viewport-freeze semantics.');
