import assert from 'node:assert/strict';
import { useState } from 'react';
import { renderToString } from 'react-dom/server';
import { act, create, ReactTestRenderer } from 'react-test-renderer';
import CadApp from '../components/cad/CadApp';
import useAdvancedCad from '../components/cad/useAdvancedCad';
import { Tool } from '../components/cad/Workspace';
import { COMMANDS } from '../lib/cad/commands';
import { bounds, Drawing, Entity, hit, newDrawing, Point, point, polyline, samples } from '../lib/cad/model';
import { parseProject, serializeProject } from '../lib/cad/project';
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
let api: ReturnType<typeof useAdvancedCad>, state: any;
let commits: Drawing[] = [];
let renderer: ReactTestRenderer;
function Harness() { const [drawing, setDrawing] = useState<Drawing>(newDrawing), [selection, setSelection] = useState(new Set<string>()), [tool, setTool] = useState<Tool>('select'), [draft, setDraft] = useState<Point[]>([]), [activeLayer, setActiveLayer] = useState('0'), [hidden, setHidden] = useState(new Set<string>()), [message, report] = useState(''); const commit = (d: Drawing, m: string) => { commits.push(drawing); setDrawing(d); report(m); }; state = { drawing, selection, tool, draft, activeLayer, hidden, message, setDrawing, setSelection, setTool, setDraft }; api = useAdvancedCad({ drawing, selected: drawing.entities.filter(e => selection.has(e.id)), selection, activeLayer, tool, draft, view: { x: 0, y: 0, scale: 1 }, commit, append: (entities, message) => commit({ ...drawing, entities: [...drawing.entities, ...entities] }, message), setSelection, setActiveLayer, setTool, setDraft, report, hidden, setHidden, find: p => [...drawing.entities].reverse().find(e => !hidden.has(e.id) && hit(e, p, .01)), fitBounds: () => { } }); return <div />; }
await act(async () => { renderer = create(<Harness />); });
async function run(name: string, args: string[] = []) { let handled = false; await act(async () => { handled = api.execute(name, args); }); assert.ok(handled, name + ' was not handled'); }
async function click(x: number, y: number) { await act(async () => { assert.ok(api.consumePoint(point(x, y))); }); }
async function select(ids: string[]) { await act(async () => state.setSelection(new Set(ids))); }
function children(node: any): any[] { if (Array.isArray(node))
    return node.flatMap(children); if (!node || typeof node !== 'object')
    return []; const c = node.props?.children; return [node, ...(Array.isArray(c) ? c : [c]).flatMap(children)]; }
async function params(v: Record<string, string>) { for (const [key, value] of Object.entries(v)) {
    const fields = children(api.dialogs).filter(x => x.type === 'label' && x.props.className === 'field-label');
    const field = fields.find(x => x.key === key);
    assert.ok(field, 'Missing parameter ' + key);
    const control = children(field).find(x => x.type === 'input' || x.props?.onChange && x.props?.options);
    await act(async () => { control.props.onChange(control.type === 'input' ? { target: { value } } : value); });
} const form = children(api.dialogs).find(x => x.type === 'form'); assert.ok(form); await act(async () => form.props.onSubmit({ preventDefault() { } })); }
const line = (x1: number, y1: number, x2: number, y2: number) => polyline([point(x1, y1), point(x2, y2)], '0');
// Drawing stages use state from the latest render, with no browser or DOM.
await run('ELLIPSE');
await click(0, 0);
await click(20, 0);
await click(0, 10);
assert.equal(state.drawing.entities[0].kind, 'ellipse');
assert.equal(state.drawing.entities[0].radius, 20);
assert.equal(state.drawing.entities[0].ry, 10);
await run('POLYGON');
await params({ n: '5' });
await click(100, 100);
await click(120, 100);
assert.equal(state.drawing.entities.at(-1).points.length, 5);
await run('SPLINE');
await click(0, 0);
await click(10, 10);
await click(20, 0);
await act(async () => { api.finish(); });
assert.equal(state.drawing.entities.at(-1).sourceType, 'SPLINE');
assert.equal(state.tool, 'select');
await run('POINT');
await click(50, 50);
assert.equal(state.drawing.entities.at(-1).kind, 'point');
// OFFSET and TRIM flow through parameter entry, selection and commit.
const base = line(0, 0, 100, 0), cut1 = line(25, -20, 25, 20), cut2 = line(75, -20, 75, 20);
await act(async () => state.setDrawing({ ...newDrawing(), entities: [base, cut1, cut2] }));
await run('OFFSET', ['10']);
await click(50, 0);
await click(50, 20);
assert.equal(bounds([state.drawing.entities.at(-1)]).minY, 10);
assert.equal(state.draft.length, 0);
await run('TRIM');
await click(50, 0);
assert.ok(!state.drawing.entities.some((e: Entity) => e.id === base.id));
assert.equal(state.drawing.entities.filter((e: Entity) => e.kind === 'polyline' && samples(e).every(p => p.y === 0)).length, 2);
// FILLET via dialog, and break via clicks.
const first = line(0, 0, 100, 0), second = line(0, 0, 0, 100);
await act(async () => state.setDrawing({ ...newDrawing(), entities: [first, second] }));
await select([first.id, second.id]);
await run('FILLET');
await params({ radius: '10' });
assert.equal(state.drawing.entities.length, 3);
assert.equal(state.drawing.entities.at(-1).kind, 'arc');
await act(async () => { state.setDrawing({ ...newDrawing(), entities: [base] }); state.setSelection(new Set()); });
await run('BREAK');
await click(50, 0);
await click(30, 0);
await click(60, 0);
assert.equal(state.drawing.entities.length, 2);
assert.equal(state.tool, 'select');
// Named blocks retain definitions and grouping across project roundtrips.
await act(async () => { state.setDrawing({ ...newDrawing(), entities: [base] }); state.setSelection(new Set([base.id])); });
await run('BLOCK');
await params({ name: 'Test block', x: '0', y: '0' });
assert.equal(state.drawing.blocks.length, 1);
assert.equal(state.drawing.entities[0].blockName, 'Test block');
await run('INSERT');
await params({ scale: '2', angle: '90' });
await click(200, 200);
assert.equal(state.drawing.entities.length, 2);
const inserted = state.drawing.entities[1];
assert.ok(inserted.blockId);
assert.notEqual(inserted.blockId, state.drawing.entities[0].blockId);
assert.equal(Math.round(bounds([inserted]).maxY), 400);
assert.equal(parseProject(serializeProject(state.drawing)).blocks!.length, 1);
await run('EXPLODE');
assert.equal(state.drawing.entities.at(-1).blockId, undefined);
assert.equal(state.drawing.blocks.length, 1);
// Group properties, selection, layer visibility, isolation and hatching.
const square = polyline([point(0, 0), point(10, 0), point(10, 10), point(0, 10)], '0', true);
await act(async () => { state.setDrawing({ ...newDrawing(), entities: [square] }); state.setSelection(new Set([square.id])); });
await run('HATCH');
await params({ pattern: 'solid' });
assert.ok(state.drawing.entities.at(-1).filled);
await run('LAYISO');
await run('LAYUNISO');
await run('QSELECT');
await params({ kind: 'polyline' });
assert.equal(state.selection.size, 2);
await run('HIDEOBJECTS');
assert.equal(state.hidden.size, 2);
assert.equal(state.selection.size, 0);
await run('UNISOLATEOBJECTS');
assert.equal(state.hidden.size, 0);
await select([square.id]);
await run('CHPROP');
await params({ color: '#123456', weight: '0.5', dash: 'Dashed' });
assert.equal(state.drawing.entities.find((e: Entity) => e.id === square.id).color, '#123456');
assert.deepEqual(state.drawing.entities.find((e: Entity) => e.id === square.id).dash, [12, 6]);
// New aligned dimensions require two measurement points and placement.
await run('DIMALIGNED');
await click(0, 0);
await click(3, 4);
await click(0, 20);
const dim = state.drawing.entities.at(-1);
assert.equal(dim.text, '5');
assert.ok(dim.groupId);
assert.equal(state.tool, 'select');
// Crossing stretch moves only vertices inside its window.
await act(async () => { state.setDrawing({ ...newDrawing(), entities: [square] }); state.setSelection(new Set()); });
await run('STRETCH');
await click(5, -1);
await click(11, 11);
await click(0, 0);
await click(5, 0);
assert.equal(bounds(state.drawing.entities).maxX, 15);
assert.equal(bounds(state.drawing.entities).minX, 0);
// Locked selection does not mutate when an edit command is invoked.
await act(async () => { state.setDrawing({ ...state.drawing, layers: state.drawing.layers.map((l: any) => ({ ...l, locked: true })) }); state.setSelection(new Set([square.id])); });
const before = state.drawing;
await run('REVERSE');
assert.equal(state.drawing, before);
await act(async () => renderer.unmount());
const html = renderToString(<CadApp />);
assert.ok(html.includes('Pixar Plus Print &amp; Copy Studio'));
assert.ok(html.includes('TRIM'));
assert.ok(html.includes('cad-ribbon'));
assert.ok(html.includes('Layout 1'));
assert.ok(html.includes('cad-command'));
assert.ok(html.includes('mobile-cad-toolbar'));
assert.ok(html.includes('mobile-properties-button'));
assert.ok(html.includes('Избор на повеќе објекти'));
assert.ok(html.includes('data-slot="tabs-trigger"'));
assert.ok(html.includes('aria-label="CAD работна површина'));
console.log('COMMAND_FLOWS_OK ' + JSON.stringify({ commits: commits.length, commandCatalog: COMMANDS.length, ssrBytes: html.length, flows: 18, lockedEditsPrevented: true }));
