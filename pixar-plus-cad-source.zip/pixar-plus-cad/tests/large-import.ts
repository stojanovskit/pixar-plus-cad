import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseDxf} from '../lib/cad/import';
import {parseProject,serializeProject} from '../lib/cad/project';
import {bounds} from '../lib/cad/model';
import {SpatialIndex} from '../lib/cad/spatial';
import {MAX_ENTITIES} from '../lib/cad/limits';

const section=(name:string,body:string)=>`0\nSECTION\n2\n${name}\n${body}0\nENDSEC\n`;
const line='0\nLINE\n8\n0\n10\n0\n20\n0\n11\n1\n21\n1\n';
const insert=(name:string,x=0)=>`0\nINSERT\n8\n0\n2\n${name}\n10\n${x}\n20\n0\n`;
const block=(name:string,body:string)=>`0\nBLOCK\n2\n${name}\n70\n0\n10\n0\n20\n0\n${body}0\nENDBLK\n`;
const dxf=(entities:string,blocks='')=>section('BLOCKS',blocks)+section('ENTITIES',entities)+'0\nEOF\n';

// A drawing which previously failed regardless of its simple geometry.
const count=160000,progress:number[]=[];
const raw=dxf(line.repeat(count));
const drawing=parseDxf(raw,'large.dxf','DXF',n=>progress.push(n));
assert.equal(drawing.entities.length,count);
assert.equal(new Set(drawing.entities.map(e=>e.id)).size,count);
assert.equal(progress.at(-1),count);
const project=serializeProject(drawing);
assert.equal(parseProject(project).entities.length,count);
const index=new SpatialIndex(drawing.entities);
assert.equal(index.candidates({x:.5,y:.5},.001).length,count);
assert.deepEqual(bounds(drawing.entities),{minX:0,minY:0,maxX:1,maxY:1});

// Repeated nested blocks must retain every instance, including transforms.
const blocks=block('Leaf',line.repeat(100))+block('Nested',insert('Leaf'));
const expanded=parseDxf(dxf(Array.from({length:1600},(_,i)=>insert('Nested',i*2)).join(''),blocks),'blocks.dxf');
assert.equal(expanded.entities.length,count);
assert.equal(expanded.entities.at(-1)!.matrix[4],3198);
assert.equal(parseProject(serializeProject(expanded)).entities.length,count);

// Protect against hostile block expansion; never return a partial drawing.
const overflowBlocks=block('Overflow',line.repeat(101));
assert.throws(()=>parseDxf(dxf(insert('Overflow').repeat(Math.ceil(MAX_ENTITIES/101)),overflowBlocks),'overflow.dxf'),/надминува/);

if(process.env.CAD_LARGE_FIXTURE)fs.writeFileSync(process.env.CAD_LARGE_FIXTURE,raw);
console.log(`LARGE_IMPORT_OK: ${count} direct and nested objects, project reload, spatial selection, progress and overflow protection.`);
