import {MAX_ENTITIES,MAX_PROJECT_ENTITIES} from './limits';
import { Drawing, Entity, Layer, Point } from './model';
export function serializeProject(drawing: Drawing) { return JSON.stringify({ format: 'nook-cad', version: 2, drawing }, null, drawing.entities.length > 50000 ? undefined : 2); }
export function parseProject(text: string): Drawing {
    const data = JSON.parse(text);
    if (data?.format !== 'nook-cad' || data.version !== 2 || !data.drawing)
        throw Error('Невалиден Pixar Plus CAD проект.');
    const d = data.drawing, finite = (n: unknown) => typeof n === 'number' && Number.isFinite(n) && Math.abs(n) < 1e15, p = (x: Point) => !!x && finite(x.x) && finite(x.y);
    function entity(e: Entity) {
        if (!e || typeof e.id !== 'string' || typeof e.layer !== 'string' || !['polyline', 'circle', 'arc', 'ellipse', 'text', 'point'].includes(e.kind) || !Array.isArray(e.matrix) || e.matrix.length !== 6 || !e.matrix.every(finite))
            throw Error('Невалидна геометрија во проектот.');
        if (e.color && !/^#[0-9a-f]{6}$/i.test(e.color))
            throw Error('Невалидна боја.');
        if (e.points && (!Array.isArray(e.points) || e.points.length > 200000 || !e.points.every(p)))
            throw Error('Невалидни темиња.');
        if (e.loops && (!Array.isArray(e.loops) || e.loops.length > 10000 || e.loops.some(loop => !Array.isArray(loop) || loop.length < 3 || loop.length > 200000 || !loop.every(p))))
            throw Error('Невалидни контури.');
        if (e.center && !p(e.center))
            throw Error('Невалиден центар.');
        for (const k of ['radius', 'ry', 'start', 'end', 'rotation', 'height', 'lineWidth'] as const)
            if (e[k] !== undefined && !finite(e[k]))
                throw Error('Невалидна мерка.');
        if ((e.radius !== undefined && e.radius < 0) || (e.height !== undefined && e.height <= 0))
            throw Error('Невалидна големина.');
        if (e.text !== undefined && (typeof e.text !== 'string' || e.text.length > 100000))
            throw Error('Предолг текст.');
        if (e.dash && (!Array.isArray(e.dash) || e.dash.length > 16 || !e.dash.every(n => finite(n) && n >= 0)))
            throw Error('Невалиден тип на линија.');
        if (e.kind === 'polyline' && (!e.points || e.points.length < 2))
            throw Error('Недоволно темиња.');
        return e;
    }
    if (typeof d.name !== 'string' || d.name.length > 250 || !['mm', 'cm', 'm', 'in'].includes(d.unit) || !Array.isArray(d.layers) || !d.layers.length || d.layers.length > 10000 || !Array.isArray(d.entities) || d.entities.length > MAX_ENTITIES)
        throw Error('Невалидни податоци во проектот.');
    const names = new Set<string>();
    for (const l of d.layers as Layer[]) {
        if (!l || typeof l.name !== 'string' || !l.name.length || names.has(l.name) || !/^#[0-9a-f]{6}$/i.test(l.color) || !finite(l.lineWidth) || l.lineWidth < 0 || (['visible', 'locked', 'plot'] as const).some(k => typeof l[k] !== 'boolean'))
            throw Error('Невалиден леер.');
        names.add(l.name);
    }
    const ids = new Set<string>();
    for (const e of d.entities as Entity[]) {
        entity(e);
        if (ids.has(e.id) || !names.has(e.layer))
            throw Error('Невалидни врски со леер или дупликат ID.');
        ids.add(e.id);
    }
    if (d.blocks !== undefined && (!Array.isArray(d.blocks) || d.blocks.length > 10000))
        throw Error('Невалидни блокови.');
    let count = d.entities.length;
    for (const b of d.blocks ?? []) {
        if (typeof b.name !== 'string' || !b.name || !Array.isArray(b.entities))
            throw Error('Невалиден блок.');
        count += b.entities.length;
        if (count > MAX_PROJECT_ENTITIES)
            throw Error('Премногу геометрија во блоковите.');
        b.entities.forEach(entity);
    }
    return { name: d.name, entities: d.entities, layers: d.layers, unit: d.unit, blocks: d.blocks, warnings: Array.isArray(d.warnings) ? d.warnings.filter((x: unknown) => typeof x === 'string').slice(0, 100) : [], source: 'NEW' };
}
