// Share the drawing budget across import, editing and project reloads.
export const MAX_ENTITIES = 1_000_000;
export const MAX_PROJECT_ENTITIES = MAX_ENTITIES * 2;
export const entityLimitMessage = () => `Цртежот надминува ${MAX_ENTITIES.toLocaleString('mk-MK')} 2D објекти по проширување на блоковите.`;
