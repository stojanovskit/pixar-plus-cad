import { getAcadColor } from 'dxf-parser/dist/ParseHelpers';
import { Entity, Matrix, Point, point, uid } from './model';

type Group = { code: number; value: any };
type Section = { kind: 'root' | 'context' | 'leader' | 'line'; groups: Group[]; children: Section[] };
const value = (s: Section, code: number) => s.groups.find(g => g.code === code)?.value;
const num = (s: Section, code: number, fallback: number) => {
    const v = value(s, code);
    return v !== undefined && Number.isFinite(Number(v)) ? Number(v) : fallback;
};
const pos = (s: Section, code: number): Point | undefined => {
    const x = num(s, code, NaN), y = num(s, code + 10, NaN);
    return Number.isFinite(x) && Number.isFinite(y) ? point(x, y) : undefined;
};

// MLeader reuses coordinate/color codes at each nesting level. Keep the scopes
// separate so text, doglegs and repeated leader lines cannot overwrite each other.
// Autodesk DXF: common MLeader, context, leader node and leader line group codes.
function sections(groups: Group[]): Section {
    const root: Section = { kind: 'root', groups: [], children: [] }, stack = [root];
    const starts = { 300: 'context', 302: 'leader', 304: 'line' } as const;
    const markers = { context: 'CONTEXT_DATA{', leader: 'LEADER{', line: 'LEADER_LINE{' };
    const ends = { context: 301, leader: 303, line: 305 };
    for (const g of groups) {
        const current = stack[stack.length - 1], kind = starts[g.code as keyof typeof starts];
        const parent = kind === 'context' ? 'root' : kind === 'leader' ? 'context' : 'leader';
        if (kind && current.kind === parent && String(g.value).trim() === markers[kind]) {
            const next: Section = { kind, groups: [], children: [] };
            current.children.push(next); stack.push(next);
        } else if (current.kind !== 'root' && g.code === ends[current.kind] && String(g.value).trim() === '}') {
            stack.pop();
        } else current.groups.push(g);
    }
    return root;
}

export class MultiLeaderReader {
    ForEntityName = 'MULTILEADER';
    parseEntity(scanner: any) {
        const groups: Group[] = []; let g = scanner.next();
        while (!scanner.isEOF() && g.code !== 0) { groups.push(g); g = scanner.next(); }
        const data = sections(groups), ci = value(data, 62), trueColor = value(data, 420);
        return {
            type: this.ForEntityName, data, handle: value(data, 5), layer: value(data, 8) ?? '0',
            colorIndex: ci, color: trueColor ?? (ci > 0 && ci < 256 ? getAcadColor(ci) : undefined),
            lineweight: value(data, 370), lineType: value(data, 6),
            inPaperSpace: num(data, 67, 0) !== 0, visible: num(data, 60, 0) === 0
        };
    }
}
export class MLeaderReader extends MultiLeaderReader { ForEntityName = 'MLEADER'; }

function leaderColor(raw: any, inherited?: string): string | undefined {
    if (raw === undefined) return inherited;
    const n = Number(raw) >>> 0, method = n >>> 24;
    if (method === 0xc0 || n === 256) return undefined; // Explicit ByLayer.
    if (method === 0xc2) return '#' + (n & 0xffffff).toString(16).padStart(6, '0');
    const index = method === 0xc3 ? n & 0xffff : method === 0 ? n : 256;
    if (index > 0 && index < 256) return '#' + getAcadColor(index).toString(16).padStart(6, '0');
    return inherited;
}

export type LeaderBlockContent = { handle: string; matrix: Matrix; matrixFromDxf: boolean; color?: string; attributes: Map<string, string> };
export function multiLeaderGeometry(data: Section, common: Omit<Entity, 'kind'>, cleanText: (s: string) => string, resolveBlock?: (content: LeaderBlockContent) => Entity[] | undefined) {
    const entities: Entity[] = [], warnings = new Set<string>(), groupId = uid();
    const add = (e: Entity) => {
        if (e.points?.some(p => !Number.isFinite(p.x) || !Number.isFinite(p.y))) return;
        entities.push({ ...e, id: uid(), groupId, sourceType: common.sourceType });
    };
    const lineColor = leaderColor(value(data, 91), common.color);
    for (const context of data.children) {
        const h = Math.max(0.0001, num(context, 41, 2.5));
        const arrowSize = Math.max(0, num(context, 140, num(data, 42, h)));
        for (const node of context.children) {
            const last = num(node, 290, 1) ? pos(node, 10) : undefined;
            const dogleg = num(node, 291, 1) ? pos(node, 11) : undefined;
            for (const line of node.children) {
                if (num(line, 170, num(data, 170, 1)) === 0) continue;
                const vertices: Point[] = [];
                for (let i = 0; i < line.groups.length; i++) {
                    if (line.groups[i].code !== 10) continue;
                    const x = Number(line.groups[i].value), y = Number(line.groups[i + 1]?.code === 20 ? line.groups[i + 1].value : NaN);
                    if (Number.isFinite(x) && Number.isFinite(y)) vertices.push(point(x, y));
                }
                if (last && (!vertices.length || Math.hypot(vertices.at(-1)!.x - last.x, vertices.at(-1)!.y - last.y) > 1e-8)) vertices.push(last);
                if (vertices.length < 2) { warnings.add('MULTILEADER: недостасуваат координати за една од стрелките.'); continue; }
                const color = leaderColor(value(line, 92), lineColor), weight = num(line, 171, num(data, 171, 0));
                const style = { ...common, color, lineWidth: weight > 0 ? weight / 100 : common.lineWidth };
                const path = [...vertices];
                if (last && dogleg && num(data, 291, 1)) {
                    const length = Math.max(0, num(node, 40, num(data, 41, 0)));
                    if (length) path.push(point(last.x + dogleg.x * length, last.y + dogleg.y * length));
                }
                add({ ...style, kind: 'polyline', points: path });
                const tip = vertices[0], next = vertices.find(p => Math.hypot(p.x - tip.x, p.y - tip.y) > 1e-8);
                const size = Math.max(0, num(line, 40, 0) || arrowSize);
                if (next && size) {
                    const d = Math.hypot(next.x - tip.x, next.y - tip.y), ux = (next.x - tip.x) / d, uy = (next.y - tip.y) / d;
                    const base = point(tip.x + ux * size, tip.y + uy * size), halfWidth = size / 6;
                    add({ ...style, kind: 'polyline', points: [tip, point(base.x - uy * halfWidth, base.y + ux * halfWidth), point(base.x + uy * halfWidth, base.y - ux * halfWidth)], closed: true, filled: true });
                }
                if (num(line, 170, num(data, 170, 1)) === 2) warnings.add('MULTILEADER: заоблените водилки се прикажуваат како сегменти.');
                if (line.groups.some(g => g.code === 11) || node.groups.some(g => g.code === 12)) warnings.add('MULTILEADER: прекините во водилките не се задржуваат.');
            }
        }
        const text = cleanText(String(value(context, 304) ?? '')), anchor = pos(context, 12);
        if (num(context, 290, text ? 1 : 0) && text) {
            if (anchor) {
                const direction = pos(context, 13), angle = num(context, 42, direction ? Math.atan2(direction.y, direction.x) : 0);
                const attachment = num(data, 179, 1), row = Math.floor((Math.max(1, Math.min(9, attachment)) - 1) / 3);
                const offset = row === 0 ? -h : row === 1 ? -h / 2 : (text.split('\n').length - 1) * h * 1.3;
                const align = [2, 5, 8].includes(attachment) ? 'center' : [3, 6, 9].includes(attachment) ? 'right' : 'left';
                add({ ...common, kind: 'text', center: point(anchor.x - offset * Math.sin(angle), anchor.y + offset * Math.cos(angle)), height: h, rotation: angle, text, align, color: leaderColor(value(context, 90) ?? value(data, 92), common.color) });
            } else warnings.add('MULTILEADER: недостасува позицијата на текстот.');
        }
        if (num(context, 296, 0)) {
            const handle = String(value(context, 341) ?? value(data, 344) ?? '').toUpperCase();
            const values = context.groups.filter(g => g.code === 47).map(g => Number(g.value));
            const matrixFromDxf = values.length === 16 && values.every(Number.isFinite);
            let matrix: Matrix;
            if (matrixFromDxf) matrix = [values[0], values[4], values[1], values[5], values[3], values[7]];
            else {
                const p = pos(context, 15), scale = Math.max(0.0001, num(context, 40, 1));
                const sx = num(context, 16, num(data, 10, 1) * scale), sy = num(context, 26, num(data, 20, 1) * scale), a = num(context, 46, num(data, 43, 0));
                matrix = [Math.cos(a) * sx, Math.sin(a) * sx, -Math.sin(a) * sy, Math.cos(a) * sy, p?.x ?? NaN, p?.y ?? NaN];
            }
            const attributes = new Map<string, string>(); let attributeHandle = '';
            for (const g of data.groups) {
                if (g.code === 330) attributeHandle = String(g.value).toUpperCase();
                if (g.code === 302 && attributeHandle) attributes.set(attributeHandle, String(g.value));
            }
            const block = matrix.every(Number.isFinite) ? resolveBlock?.({ handle, matrix, matrixFromDxf, color: leaderColor(value(context, 93) ?? value(data, 93), common.color), attributes }) : undefined;
            if (block?.length) for (const entity of block) add(entity);
            else warnings.add('MULTILEADER: блоковската содржина не се вчитува; водилките се задржани.');
        }
        if (num(data, 271, 0)) warnings.add('MULTILEADER: вертикалниот текст се прикажува хоризонтално.');
    }
    const customArrows = [...data.groups.filter(g => g.code === 342 || g.code === 345), ...data.children.flatMap(c => c.children.flatMap(n => n.children.flatMap(l => l.groups.filter(g => g.code === 341))))];
    if (customArrows.some(g => String(g.value) !== '0')) warnings.add('MULTILEADER: сопствените симболи за стрелки се заменети со стандардни стрелки.');
    if (!entities.length) warnings.add('MULTILEADER: ознака без поддржана 2D геометрија.');
    return { entities, warnings: [...warnings] };
}
