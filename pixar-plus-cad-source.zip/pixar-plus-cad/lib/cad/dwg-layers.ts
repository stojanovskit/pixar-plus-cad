import { Drawing } from './model';

export type DwgLayerState = { visible: boolean; locked?: boolean; plot?: boolean };
type Reader = {
    dwg_getall_LAYER(data: number): number[];
    dwg_dynapi_entity_data(ptr: number, field: string): unknown;
};
const flag = (value: unknown) => typeof value === 'boolean' ? value : typeof value === 'number' && Number.isFinite(value) ? value !== 0 : undefined;
const name = (value: string) => value.replace(/\\U\+([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));

// LibreDWG's DXF writer can emit a negative ACI for a layer whose native `off`
// flag is zero. Read the native flags instead of guessing that every layer is on.
export function readDwgLayerStates(reader: Reader, data: number): Map<string, DwgLayerState> {
    const states = new Map<string, DwgLayerState>();
    for (const ptr of reader.dwg_getall_LAYER(data)) {
        const get = (field: string) => reader.dwg_dynapi_entity_data(ptr, field);
        const layerName = get('name'), off = flag(get('off')), frozen = flag(get('frozen'));
        if (typeof layerName !== 'string' || off === undefined || frozen === undefined) continue;
        states.set(name(layerName), { visible: !off && !frozen, locked: flag(get('locked')), plot: flag(get('plotflag')) });
    }
    return states;
}

export function applyDwgLayerStates(drawing: Drawing, states: Map<string, DwgLayerState>) {
    drawing.layers = drawing.layers.map(layer => {
        const native = states.get(layer.name);
        if (!native) return layer;
        return { ...layer, visible: native.visible, locked: native.locked ?? layer.locked, plot: native.plot ?? layer.plot };
    });
    return drawing;
}
