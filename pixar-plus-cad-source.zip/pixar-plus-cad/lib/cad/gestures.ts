import { distance, point, type Point } from './model';
import { screenToWorld, type View } from './render';

export type PointerMode = 'pan' | 'select' | 'draw';
export type CanvasGesture = {
  id: number; start: Point; view: View; mode: PointerMode; extend: boolean; pointerType: string;
};
type Pinch = { dist: number; world: Point; view: View };
export type PointerMotion = { view?: View; cursor?: Point; box?: { start: Point; end: Point } };

/** Keep navigation isolated from drawing until every finger has lifted. */
export class CadGestures {
  private pointers = new Map<number, Point>();
  private gesture: CanvasGesture | null = null;
  private pinch: Pinch | null = null;
  private navigating = false;

  private startPinch(view: View) {
    const [a, b] = [...this.pointers.values()];
    if (this.pointers.size !== 2) { this.pinch = null; return; }
    const mid = point((a.x + b.x) / 2, (a.y + b.y) / 2);
    this.pinch = { dist: distance(a, b), world: screenToWorld(mid, view), view };
  }

  down(id: number, position: Point, view: View, mode: PointerMode, extend: boolean, pointerType: string) {
    this.pointers.set(id, position);
    if (this.pointers.size > 1 || this.navigating) {
      this.navigating = true;
      this.gesture = null;
      this.startPinch(view);
      return null;
    }
    this.gesture = { id, start: position, view, mode, extend, pointerType };
    return this.gesture;
  }

  move(id: number, position: Point): PointerMotion {
    if (this.pointers.has(id)) this.pointers.set(id, position);
    if (this.navigating) {
      if (!this.pinch || this.pointers.size !== 2) return {};
      const [a, b] = [...this.pointers.values()];
      const mid = point((a.x + b.x) / 2, (a.y + b.y) / 2), old = this.pinch;
      const scale = Math.max(1e-7, Math.min(1e6, old.view.scale * distance(a, b) / Math.max(old.dist, 1)));
      return { view: { scale, x: mid.x - old.world.x * scale, y: mid.y + old.world.y * scale } };
    }
    const g = this.gesture;
    if (g && g.id !== id) return {};
    if (g?.mode === 'pan') return { view: { ...g.view, x: g.view.x + position.x - g.start.x, y: g.view.y + position.y - g.start.y } };
    return { cursor: position, ...(g?.mode === 'select' ? { box: { start: g.start, end: position } } : {}) };
  }

  up(id: number, view: View, cancelled = false) {
    if (!this.pointers.delete(id)) return null;
    if (this.navigating) {
      this.startPinch(view);
      if (!this.pointers.size) this.navigating = false;
      this.gesture = null;
      return null;
    }
    const g = this.gesture;
    if (g?.id !== id) return null;
    this.gesture = null;
    return cancelled ? null : g;
  }

  reset() { this.pointers.clear(); this.gesture = null; this.pinch = null; this.navigating = false; }
}

export const pointerHitRadius = (type: string) => type === 'touch' ? 16 : type === 'pen' ? 10 : 8;
export const pointerTapSlop = (type: string) => type === 'touch' ? 12 : 5;
export function resizeView(view: View, old: { w: number; h: number }, next: { w: number; h: number }): View {
  return { ...view, x: view.x + (next.w - old.w) / 2, y: view.y + (next.h - old.h) / 2 };
}
