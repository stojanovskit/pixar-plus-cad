export type Point = {x:number;y:number};
export type Matrix = [number,number,number,number,number,number];
export const IDENTITY:Matrix=[1,0,0,1,0,0];
export type Kind='polyline'|'circle'|'arc'|'ellipse'|'text'|'point';
export type Entity={id:string;groupId?:string;blockId?:string;blockName?:string;kind:Kind;layer:string;color?:string;lineWidth?:number;dash?:number[];matrix:Matrix;points?:Point[];loops?:Point[][];closed?:boolean;filled?:boolean;center?:Point;radius?:number;ry?:number;start?:number;end?:number;rotation?:number;text?:string;height?:number;align?:'left'|'center'|'right';sourceType?:string};
export type Layer={name:string;color:string;visible:boolean;locked:boolean;plot:boolean;lineWidth:number};
export type BlockDefinition={name:string;entities:Entity[]};
export type Drawing={blocks?:BlockDefinition[];name:string;entities:Entity[];layers:Layer[];unit:'mm'|'cm'|'m'|'in';warnings:string[];source:'DXF'|'DWG'|'NEW'|'DEMO'};
export type Bounds={minX:number;minY:number;maxX:number;maxY:number};
export const uid=()=>globalThis.crypto?.randomUUID?.()??`e${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
export const point=(x:number,y:number):Point=>({x,y});
export const apply=(m:Matrix,p:Point):Point=>({x:m[0]*p.x+m[2]*p.y+m[4],y:m[1]*p.x+m[3]*p.y+m[5]});
export function multiply(a:Matrix,b:Matrix):Matrix{return [a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];}
export function transformEntities(entities:Entity[],ids:Set<string>,m:Matrix,copy=false):Entity[]{const groups=new Map<string,string>();const fresh=(id?:string)=>{if(!id||!copy)return id;if(!groups.has(id))groups.set(id,uid());return groups.get(id);};const changed=entities.filter(e=>ids.has(e.id)).map(e=>({...e,id:copy?uid():e.id,groupId:fresh(e.groupId),blockId:fresh(e.blockId),matrix:multiply(m,e.matrix)}));const map=new Map(changed.map(e=>[e.id,e]));return copy?[...entities,...changed]:entities.map(e=>map.get(e.id)??e);}
export function translation(dx:number,dy:number):Matrix{return [1,0,0,1,dx,dy];}
export function rotation(deg:number,c:Point):Matrix{const a=deg*Math.PI/180,s=Math.sin(a),k=Math.cos(a);return [k,s,-s,k,c.x-k*c.x+s*c.y,c.y-s*c.x-k*c.y];}
export function scaling(n:number,c:Point):Matrix{return [n,0,0,n,c.x*(1-n),c.y*(1-n)];}
const sampleCache=new WeakMap<Entity,Point[]>();
export function samples(e:Entity):Point[]{let cached=sampleCache.get(e);if(cached)return cached;let p:Point[]=[];if(e.kind==='polyline')p=e.points??[];else if(e.kind==='point')p=[e.center??point(0,0)];else if(e.kind==='text'){const c=e.center??point(0,0),h=e.height??2.5,w=Math.max(...(e.text??'').split('\n').map(s=>s.length))*h*.6,lines=(e.text??'').split('\n').length;const off=e.align==='center'?-w/2:e.align==='right'?-w:0;const m=rotation((e.rotation??0)*180/Math.PI,c);p=[point(c.x+off,c.y),point(c.x+off+w,c.y),point(c.x+off+w,c.y+h),point(c.x+off,c.y-(lines-1)*h*1.3)];p=p.map(q=>apply(m,q));}else{const c=e.center??point(0,0),r=e.radius??1,ry=e.kind==='ellipse'?(e.ry??r):r;let s=e.start??0,t=e.end??Math.PI*2;if(e.kind==='circle'){s=0;t=Math.PI*2;}while(t<=s)t+=Math.PI*2;const steps=Math.max(12,Math.ceil((t-s)/(Math.PI*2)*192)),a=e.rotation??0;for(let i=0;i<=steps;i++){const u=s+(t-s)*i/steps,x=r*Math.cos(u),y=ry*Math.sin(u);p.push(point(c.x+x*Math.cos(a)-y*Math.sin(a),c.y+x*Math.sin(a)+y*Math.cos(a)));}}cached=p.map(q=>apply(e.matrix,q));sampleCache.set(e,cached);return cached;}
export function paths(e:Entity):Point[][]{return [samples(e),...(e.loops??[]).map(loop=>loop.map(p=>apply(e.matrix,p)))];}
export function bounds(entities:Entity[]):Bounds{let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const e of entities)for(const p of paths(e).flat()){if(!Number.isFinite(p.x)||!Number.isFinite(p.y))continue;minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}return Number.isFinite(minX)?{minX,minY,maxX,maxY}:{minX:0,minY:0,maxX:100,maxY:100};}
export function center(b:Bounds):Point{return point((b.minX+b.maxX)/2,(b.minY+b.maxY)/2);}
export const distance=(a:Point,b:Point)=>Math.hypot(a.x-b.x,a.y-b.y);
export function segmentDistance(p:Point,a:Point,b:Point){const l=(b.x-a.x)**2+(b.y-a.y)**2;if(!l)return distance(p,a);const t=Math.max(0,Math.min(1,((p.x-a.x)*(b.x-a.x)+(p.y-a.y)*(b.y-a.y))/l));return distance(p,point(a.x+t*(b.x-a.x),a.y+t*(b.y-a.y)));}
export function hit(e:Entity,p:Point,tol:number):boolean{if(e.kind==='text'){const b=bounds([e]);return p.x>=b.minX-tol&&p.x<=b.maxX+tol&&p.y>=b.minY-tol&&p.y<=b.maxY+tol;}for(const v of paths(e)){if(v.length===1&&distance(v[0],p)<=tol)return true;for(let i=1;i<v.length;i++)if(segmentDistance(p,v[i-1],v[i])<=tol)return true;if(e.closed&&v.length&&segmentDistance(p,v[v.length-1],v[0])<=tol)return true;}return false;}
export function snapPoints(e:Entity):Point[]{if(e.kind==='text'||e.kind==='point')return [apply(e.matrix,e.center??point(0,0))];if(e.kind==='circle'||e.kind==='ellipse'){const c=e.center??point(0,0);return [apply(e.matrix,c),...samples(e).filter((_,i)=>i%48===0)];}const v=samples(e);if(e.kind==='arc')return [v[0],v[v.length-1],apply(e.matrix,e.center??point(0,0))];const result=[...v];for(let i=1;i<v.length;i++)result.push(point((v[i].x+v[i-1].x)/2,(v[i].y+v[i-1].y)/2));return result;}
export const mmPerUnit={mm:1,cm:10,m:1000,in:25.4};
export function newDrawing():Drawing{return {name:'Нов цртеж',entities:[],layers:[{name:'0',color:'#d9e3eb',visible:true,locked:false,plot:true,lineWidth:.25}],unit:'mm',warnings:[],source:'NEW'};}
export function polyline(points:Point[],layer:string,closed=false):Entity{return {id:uid(),kind:'polyline',layer,matrix:[...IDENTITY],points,closed};}
export function demoDrawing():Drawing{
 const d=newDrawing();d.name='Studio 01 · основа';d.source='DEMO';d.layers=[{name:'A-WALL',color:'#72dcd2',visible:true,locked:false,plot:true,lineWidth:.4},{name:'A-DOOR',color:'#ecb56d',visible:true,locked:false,plot:true,lineWidth:.25},{name:'A-FURNITURE',color:'#839dab',visible:true,locked:false,plot:true,lineWidth:.18},{name:'A-DIMENSION',color:'#7e96bd',visible:true,locked:false,plot:true,lineWidth:.15},{name:'A-TEXT',color:'#d9e3eb',visible:true,locked:false,plot:true,lineWidth:.18},{name:'0',color:'#b0bac3',visible:true,locked:false,plot:true,lineWidth:.25}];
 const line=(x1:number,y1:number,x2:number,y2:number,l='A-WALL')=>d.entities.push(polyline([point(x1,y1),point(x2,y2)],l));
 const rect=(x:number,y:number,w:number,h:number,l='A-WALL')=>d.entities.push(polyline([point(x,y),point(x+w,y),point(x+w,y+h),point(x,y+h)],l,true));
 const text=(x:number,y:number,t:string,h=140,l='A-TEXT',a:'left'|'center'|'right'='center')=>d.entities.push({id:uid(),kind:'text',layer:l,matrix:[...IDENTITY],center:point(x,y),text:t,height:h,align:a});
 const circle=(x:number,y:number,r:number,l='A-FURNITURE')=>d.entities.push({id:uid(),kind:'circle',layer:l,matrix:[...IDENTITY],center:point(x,y),radius:r});
 const door=(x:number,y:number,r:number,a=0)=>{d.entities.push({id:uid(),kind:'arc',layer:'A-DOOR',matrix:[...IDENTITY],center:point(x,y),radius:r,start:a,end:a+Math.PI/2});line(x,y,x+r*Math.cos(a+Math.PI/2),y+r*Math.sin(a+Math.PI/2),'A-DOOR');};
 rect(0,0,10800,7600);rect(180,180,10440,7240);rect(4800,180,160,7240);rect(4960,3400,5660,160);rect(180,3400,4620,160);rect(7600,3560,160,3860);
 // Openings cut into the partitions.
 d.entities=d.entities.filter(e=>!(e.kind==='polyline'&&e.closed&&e.layer==='A-WALL'&&e.points?.[0].x===4800));
 rect(4800,180,160,2820);rect(4800,3900,160,3520);door(4960,3000,900,0);door(2000,3560,850,0);door(8400,3560,800,0);
 // Windows: three fine parallel lines.
 for(const [x,y,w,h] of [[900,7420,2400,180],[5300,7420,1800,180],[8550,7420,1300,180],[10620,800,180,2100],[0,900,180,1800]]){for(let k=0;k<3;k++)line(x+(w<200?k*70:0),y+(h<200?k*70:0),x+w-(w<200?180-k*70:0),y+h-(h<200?180-k*70:0),'A-DOOR');}
 // Living room seating and dining.
 rect(650,4200,1200,2500,'A-FURNITURE');rect(760,4350,960,1050,'A-FURNITURE');rect(760,5500,960,1050,'A-FURNITURE');rect(2300,4750,950,1250,'A-FURNITURE');rect(2400,4850,750,1050,'A-FURNITURE');rect(3850,5000,350,1600,'A-FURNITURE');
 circle(2200,1800,700);for(const [x,y] of [[1200,1800],[3200,1800],[2200,800],[2200,2800]])circle(x,y,230);
 // Bedroom: bed and side tables.
 rect(5200,5700,1800,1500,'A-FURNITURE');rect(5300,6600,740,470,'A-FURNITURE');rect(6140,6600,740,470,'A-FURNITURE');line(5200,6500,7000,6500,'A-FURNITURE');rect(5200,5200,450,350,'A-FURNITURE');rect(6550,5200,450,350,'A-FURNITURE');rect(5020,3700,900,600,'A-FURNITURE');rect(6150,3700,900,600,'A-FURNITURE');
 // Kitchen and bathroom.
 rect(8100,6650,2200,600,'A-FURNITURE');rect(9700,4050,600,2600,'A-FURNITURE');rect(8250,6790,900,320,'A-FURNITURE');for(let i=0;i<4;i++)circle(9980+(i%2)*120,4600+Math.floor(i/2)*160,60);rect(7800,4800,650,1200,'A-FURNITURE');rect(8500,1000,1700,800,'A-FURNITURE');rect(9000,2000,700,650,'A-FURNITURE');circle(5400,2300,230);rect(5120,2460,560,500,'A-FURNITURE');rect(5850,800,1500,700,'A-FURNITURE');
 text(2750,6950,'LIVING',135);text(6600,4600,'BEDROOM',120);text(8800,6000,'KITCHEN',120);text(6750,2900,'BATH',120);text(7150,2200,'ENTRY',120);text(2750,1100,'DINING',120);
 const dim=(x1:number,y1:number,x2:number,y2:number,t:string)=>{line(x1,y1,x2,y2,'A-DIMENSION');const hor=y1===y2;for(const [x,y] of [[x1,y1],[x2,y2]]){line(x-65,y-65,x+65,y+65,'A-DIMENSION');line(x,y-120,x,y+120,'A-DIMENSION');}text((x1+x2)/2+(hor?0:-170),(y1+y2)/2+(hor?100:0),t,130,'A-DIMENSION');};
 line(0,7600,0,8250,'A-DIMENSION');line(10800,7600,10800,8250,'A-DIMENSION');dim(0,8100,10800,8100,'10 800');dim(0,8600,4960,8600,'4 960');dim(4960,8600,10800,8600,'5 840');line(-450,0,0,0,'A-DIMENSION');line(-450,7600,0,7600,'A-DIMENSION');dim(-400,0,-400,7600,'7 600');
 text(0,-850,'STUDIO 01 / FLOOR PLAN',190,'A-TEXT','left');text(0,-1200,'2D WORKSPACE · DIMENSIONS IN mm',105,'A-DIMENSION','left');line(0,-480,10800,-480,'A-DIMENSION');text(10800,-1000,'01',300,'A-TEXT','right');
 return d;
}
