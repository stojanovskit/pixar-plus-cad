import {decodeDxf,parseDxf} from './import';
import {applyDwgLayerStates,readDwgLayerStates,DwgLayerState} from './dwg-layers';
self.onmessage=async(event:MessageEvent<{buffer:ArrayBuffer;name:string}>)=>{
 try{
  const {buffer,name}=event.data;let text:string;const ext=name.split('.').pop()?.toLowerCase();const warnings:string[]=[];let nativeLayers=new Map<string,DwgLayerState>();
  if(ext==='dwg'){
   self.postMessage({progress:'Се вчитува DWG читачот…'});
   const {createModule,LibreDwg}=await import('@mlightcad/libredwg-web');
   const engine=await createModule();
   self.postMessage({progress:'Се чита DWG цртежот…'});
   try{engine.FS.writeFile('input.dwg',new Uint8Array(buffer));const result=engine.dwg_write_dxf('input.dwg','output.dxf');if(result>=128||!engine.FS.analyzePath('output.dxf',false).exists)throw Error('DWG читачот не може да го прочита овој фајл. Пробај Save As DXF во CAD програмата.');const data=engine.FS.readFile('output.dxf');if(!data.byteLength)throw Error('DWG конверзијата врати празен DXF. Пробај Save As DXF во CAD програмата.');text=decodeDxf(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength) as ArrayBuffer);if(result!==0)warnings.push(`DWG читачот пријави предупредување (${result}); провери го цртежот пред печатење.`);
    const reader=LibreDwg.createByWasmInstance(engine),native=engine.dwg_read_file('input.dwg');
    if(native.data){try{if(native.error<128)nativeLayers=readDwgLayerStates(reader,native.data);}finally{reader.dwg_free(native.data);}}
    if(!nativeLayers.size)warnings.push('DWG: состојбата на леерите е земена од DXF конверзијата; провери го приказот на леерите.');
   }finally{for(const f of ['input.dwg','output.dxf'])if(engine.FS.analyzePath(f,false).exists)engine.FS.unlink(f);}
  }else if(ext==='dxf')text=decodeDxf(buffer);else throw Error('Избери .dxf или .dwg фајл.');
  self.postMessage({progress:'Се подготвува геометријата…'});const drawing=parseDxf(text!,name,ext==='dwg'?'DWG':'DXF',count=>self.postMessage({progress:`Се подготвува геометријата… ${count.toLocaleString('mk-MK')} објекти`}));if(ext==='dwg')applyDwgLayerStates(drawing,nativeLayers);drawing.warnings.push(...warnings);self.postMessage({drawing});
 }catch(error){self.postMessage({error:error instanceof Error?error.message:'Неуспешно читање на цртежот.'});}
};
