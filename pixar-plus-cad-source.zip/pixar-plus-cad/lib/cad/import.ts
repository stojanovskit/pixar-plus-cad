import DxfParser from 'dxf-parser';
import {MAX_ENTITIES,entityLimitMessage} from './limits';
import {MLeaderReader,MultiLeaderReader,multiLeaderGeometry} from './multileader';
import {Drawing,Entity,Layer,Matrix,Point,IDENTITY,uid,point,multiply,polyline,samples,translation,rotation} from './model';
type Raw=Record<string,any>;
export function decodeDxf(buffer:ArrayBuffer):string{
 const utf=new TextDecoder('utf-8').decode(buffer);const ver=/\$ACADVER\s*\n\s*1\s*\n\s*(AC\d+)/.exec(utf)?.[1];
 const cp=/\$DWGCODEPAGE\s*\n\s*3\s*\n\s*ANSI_(\d+)/.exec(utf)?.[1];
 if(cp&&ver&&Number(ver.slice(2))<1021){try{return new TextDecoder(`windows-${cp}`).decode(buffer);}catch{}}
 return utf.replace(/^\uFEFF/,'');
}
export function cleanText(text:string):string{return String(text??'').replace(/\\U\+([0-9a-fA-F]{4})/g,(_,h)=>String.fromCharCode(parseInt(h,16))).replace(/\\P/g,'\n').replace(/\\[fF][^;]*;/g,'').replace(/\\[ACcHhQqTtWwp][^;]*;/g,'').replace(/\\S([^;]+);/g,(_,s)=>s.replace(/[\^#]/g,'/')).replace(/\\[LlOoKk]/g,'').replace(/%%d/gi,'°').replace(/%%p/gi,'±').replace(/%%c/gi,'Ø').replace(/[{}]/g,'').replace(/\\~/g,' ');}
const decodeName=(s:string)=>s.replace(/\\U\+([0-9a-fA-F]{4})/g,(_,h)=>String.fromCharCode(parseInt(h,16)));
export const hex=(n:number)=>'#'+(n&0xffffff).toString(16).padStart(6,'0');
export function bulgePoints(v:Raw[],closed:boolean):Point[]{const out:Point[]=[];for(let i=0;i<v.length;i++){const a=v[i],b=v[(i+1)%v.length];out.push(point(a.x,a.y));if(i===v.length-1&&!closed)break;const bulge=Number(a.bulge??0);if(!bulge||!b)continue;const dx=b.x-a.x,dy=b.y-a.y,chord=Math.hypot(dx,dy);if(!chord)continue;const cx=(a.x+b.x)/2-dy*(1-bulge*bulge)/(4*bulge),cy=(a.y+b.y)/2+dx*(1-bulge*bulge)/(4*bulge),r=chord*(1+bulge*bulge)/(4*Math.abs(bulge)),theta=4*Math.atan(bulge),start=Math.atan2(a.y-cy,a.x-cx);const steps=Math.max(6,Math.ceil(Math.abs(theta)*32));for(let j=1;j<steps;j++)out.push(point(cx+r*Math.cos(start+theta*j/steps),cy+r*Math.sin(start+theta*j/steps)));}return out;}
function splinePoints(e:Raw):Point[]{const p:Point[]=e.controlPoints??e.fitPoints??[],degree=e.degreeOfSplineCurve??3,knots:number[]=e.knotValues??[];if(p.length<=degree||knots.length!==p.length+degree+1)return p;const out:Point[]=[],lo=knots[degree],hi=knots[p.length];if(!(hi>lo))return p;for(let j=0;j<=Math.max(64,p.length*12);j++){const t=lo+(hi-lo)*j/Math.max(64,p.length*12);let span=degree;while(span<p.length-1&&t>=knots[span+1])span++;const d=Array.from({length:degree+1},(_,i)=>({...p[span-degree+i]}));for(let r=1;r<=degree;r++)for(let k=degree;k>=r;k--){const i=span-degree+k,den=knots[i+degree-r+1]-knots[i],a=den?(t-knots[i])/den:0;d[k]=point((1-a)*d[k-1].x+a*d[k].x,(1-a)*d[k-1].y+a*d[k].y);}out.push(d[degree]);}return out;}
// Retain HATCH boundaries, including curved polyline paths. Pattern fills are deliberately reported as unsupported.
class HatchReader{
 ForEntityName='HATCH';
 parseEntity(scanner:any){const groups:{code:number;value:any}[]=[];let g=scanner.next();while(!scanner.isEOF()&&g.code!==0){groups.push(g);g=scanner.next();}const first=(n:number)=>groups.find(g=>g.code===n)?.value;return {type:'HATCH',layer:first(8)??'0',color:first(420),colorIndex:first(62),lineweight:first(370),inPaperSpace:first(67)===1,solid:first(70)===1,groups};}
}
function hatchPaths(e:Raw):Point[][]{const g=e.groups as {code:number;value:any}[],result:Point[][]=[];for(let i=0;i<g.length;i++){if(g[i].code!==92)continue;const flags=Number(g[i].value);let stop=i+1;while(stop<g.length&&![92,75,97].includes(g[stop].code))stop++;const part=g.slice(i+1,stop);if(flags&2){const v:Raw[]=[];for(const q of part){if(q.code===10)v.push({x:Number(q.value),y:0});if(q.code===20&&v.length)v[v.length-1].y=Number(q.value);if(q.code===42&&v.length)v[v.length-1].bulge=Number(q.value);}if(v.length)result.push(bulgePoints(v,true));}else{let path:Point[]=[];for(let k=0;k<part.length;k++){if(part[k].code!==72)continue;let end=k+1;while(end<part.length&&part[end].code!==72)end++;const edge=part.slice(k+1,end),get=(n:number)=>Number(edge.find(x=>x.code===n)?.value??0),type=Number(part[k].value);if(type===1){path.push(point(get(10),get(20)),point(get(11),get(21)));}else if(type===2||type===3){let start=get(50)*Math.PI/180,finish=get(51)*Math.PI/180;const ccw=get(73)!==0;if(ccw){while(finish<start)finish+=Math.PI*2;}else{while(finish>start)finish-=Math.PI*2;}const r=type===2?get(40):Math.hypot(get(11),get(21)),ry=type===2?r:r*get(40),rot=type===3?Math.atan2(get(21),get(11)):0;for(let j=0;j<=64;j++){const a=start+(finish-start)*j/64,x=r*Math.cos(a),y=ry*Math.sin(a);path.push(point(get(10)+x*Math.cos(rot)-y*Math.sin(rot),get(20)+x*Math.sin(rot)+y*Math.cos(rot)));}}}if(path.length)result.push(path);}}return result;}
export function parseDxf(text:string,name:string,source:'DXF'|'DWG'='DXF',onProgress?:(count:number)=>void):Drawing{
 if(text.startsWith('AutoCAD Binary DXF'))throw Error('Ова е бинарен DXF. Зачувај го како ASCII DXF во CAD програмата и отвори го повторно.');
 const parser=new DxfParser();for(const handler of [HatchReader,MultiLeaderReader,MLeaderReader])parser.registerEntityHandler(handler as any);const raw=parser.parseSync(text) as unknown as Raw;if(!raw?.entities)throw Error('Фајлот нема валидна DXF ENTITIES секција.');
 const layers:Layer[]=[],layersRaw:Raw=raw.tables?.layer?.layers??{};const warnings=new Set<string>();
 // Table flags preserve off/lock/plot settings which the parser does not expose.
 const layerExtra:Record<string,{flags:number;color:number;plot:boolean;width:number}>={};
 const tableLines=text.split(/\r?\n/);
 for(let i=0;i+1<tableLines.length;i+=2){if(tableLines[i].trim()!=='0'||tableLines[i+1].trim()!=='LAYER')continue;const vals:Record<string,string>={};let j=i+2;for(;j+1<tableLines.length;j+=2){const code=tableLines[j].trim();if(code==='0')break;vals[code]=tableLines[j+1].trim();}const n=vals['2'];if(n)layerExtra[n]={flags:Number(vals['70']??0),color:Number(vals['420']??NaN),plot:vals['290']!=='0',width:Number(vals['370']??25)/100};i=j-2;}

 for(const [n,value] of Object.entries(layersRaw)){const r=value as Raw,x=layerExtra[n];layers.push({name:decodeName(n),color:hex(Number.isFinite(x?.color)?x.color:r.color??0xffffff),visible:r.visible!==false&&!(x?x.flags&1:r.frozen),locked:!!((x?.flags??0)&4),plot:x?.plot!==false,lineWidth:x?.width>0?x.width:.25});}
 if(!layers.some(l=>l.name==='0'))layers.unshift({name:'0',color:'#e3e7ed',visible:true,locked:false,plot:true,lineWidth:.25});
 const entities:Entity[]=[];let approximated=false,hatchSeen=false,leaderSeen=false;const unknown=new Map<string,number>();
 const blocksByHandle=new Map<string,Raw>();for(const block of Object.values(raw.blocks??{}) as Raw[])if(block.ownerHandle)blocksByHandle.set(String(block.ownerHandle).toUpperCase(),block);
 function append(output:Entity[],entity:Entity){
  if(entities.length+(output===entities?0:output.length)>=MAX_ENTITIES)throw Error(entityLimitMessage());
  output.push(entity);if(output===entities&&entities.length%10000===0)onProgress?.(entities.length);
 }
 function visit(list:Raw[],matrix:Matrix=[...IDENTITY],parentLayer='0',byBlockColor?:string,ancestors=new Set<string>(),output:Entity[]=entities){
  if(ancestors.size>64)throw Error('Блоковите се вгнездени повеќе од 64 нивоа. Провери го цртежот во CAD програмата.');
  for(const r of list){if(r.inPaperSpace||r.visible===false)continue;
   const layer=decodeName(r.layer&&r.layer!=='0'?r.layer:parentLayer);const color=r.colorIndex===0?byBlockColor:((r.colorIndex===256||r.colorIndex===undefined)&&r.color===undefined)?undefined:hex(r.color??layersRaw[layer]?.color??0xffffff);
   let m=matrix;if((r.extrusionDirectionZ??r.extrusionDirection?.z)===-1)m=multiply(m,[-1,0,0,1,0,0]);
   const common={id:uid(),layer,matrix:m,color,lineWidth:r.lineweight>0?r.lineweight/100:undefined,sourceType:r.type,dash:raw.tables?.lineType?.lineTypes?.[r.lineType]?.pattern?.map((n:number)=>Math.abs(n))};
   let e:Entity|undefined;
   switch(r.type){
    case 'MULTILEADER':case 'MLEADER':{const result=multiLeaderGeometry(r.data,common,cleanText,content=>{
     const block=blocksByHandle.get(content.handle);if(!block||ancestors.has(block.name))return undefined;
     const next=new Set(ancestors);next.add(block.name);const blockEntities=(block.entities??[]).map((entity:Raw)=>entity.type==='ATTDEF'&&!entity.invisible?{...entity,type:'TEXT',text:content.attributes.get(String(entity.handle).toUpperCase())??entity.text,halign:entity.horizontalJustification}:entity);
     const base=block.position??point(0,0),local=content.matrixFromDxf?content.matrix:multiply(content.matrix,translation(-base.x,-base.y));const parts:Entity[]=[];
     visit(blockEntities,multiply(m,local),layer,content.color,next,parts);return parts;
    });for(const entity of result.entities)if(samples(entity).length&&samples(entity).every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))append(output,entity);for(const warning of result.warnings)warnings.add(warning);leaderSeen=true;break;}
    case 'INSERT':case 'DIMENSION':{
     const block=raw.blocks?.[r.name??r.block];if(!block||ancestors.has(block.name)){unknown.set(r.type,(unknown.get(r.type)??0)+1);break;}
     const pos=r.position??point(0,0),base=block.position??point(0,0),sx=r.xScale??1,sy=r.yScale??1,ang=(r.rotation??0)*Math.PI/180,cols=Math.min(r.columnCount??1,100),rows=Math.min(r.rowCount??1,100);const local:Matrix=[Math.cos(ang)*sx,Math.sin(ang)*sx,-Math.sin(ang)*sy,Math.cos(ang)*sy,pos.x,pos.y];const next=new Set(ancestors);next.add(block.name);
     for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){const offset=translation(-base.x+col*(r.columnSpacing??0),-base.y+row*(r.rowSpacing??0));visit(block.entities??[],multiply(m,multiply(local,offset)),layer,color,next,output);}break;
    }
    case 'LINE':e={...common,kind:'polyline',points:r.vertices};break;
    case 'LWPOLYLINE':case 'POLYLINE':e={...common,kind:'polyline',points:bulgePoints(r.vertices??[],!!r.shape),closed:!!r.shape};if(r.vertices?.some((v:Raw)=>v.bulge))approximated=true;break;
    case 'CIRCLE':e={...common,kind:'circle',center:r.center,radius:r.radius};break;
    case 'ARC':e={...common,kind:'arc',center:r.center,radius:r.radius,start:r.startAngle,end:r.endAngle};break;
    case 'ELLIPSE':{const a=r.majorAxisEndPoint??point(1,0),radius=Math.hypot(a.x,a.y);e={...common,kind:'ellipse',center:r.center,radius,ry:radius*(r.axisRatio??1),rotation:Math.atan2(a.y,a.x),start:r.startAngle,end:r.endAngle};break;}
    case 'TEXT':case 'MTEXT':case 'ATTRIB':case 'ATTDEF':{if(r.type==='ATTDEF')break;const a=r.halign===1||r.attachmentPoint&&[2,5,8].includes(r.attachmentPoint)?'center':r.halign===2||r.attachmentPoint&&[3,6,9].includes(r.attachmentPoint)?'right':'left';const h=r.textHeight??r.height??2.5;const c=r.halign&&r.endPoint?r.endPoint:r.startPoint??r.position??point(0,0);const rot=r.directionVector?Math.atan2(r.directionVector.y,r.directionVector.x):(r.rotation??0)*Math.PI/180;const offset=r.type==='MTEXT'?((r.attachmentPoint??1)<=3?-h:(r.attachmentPoint??1)<=6?-h*.5:(cleanText(r.text).split('\n').length-1)*h*1.3):0;e={...common,kind:'text',center:point(c.x-offset*Math.sin(rot),c.y+offset*Math.cos(rot)),text:cleanText(r.text),height:h,rotation:rot,align:a};break;}
    case 'SOLID':case '3DFACE':{let v=r.points??r.vertices??[];if(r.type==='SOLID'&&v.length===4)v=[v[0],v[1],v[3],v[2]];e={...common,kind:'polyline',points:v,closed:true,filled:r.type==='SOLID'};break;}
    case 'SPLINE':e={...common,kind:'polyline',points:splinePoints(r),closed:!!r.closed};approximated=true;break;
    case 'POINT':e={...common,kind:'point',center:r.position};break;
    case 'HATCH':{if(!r.solid)hatchSeen=true;const paths=hatchPaths(r);if(r.solid&&paths.length)append(output,{...common,id:uid(),kind:'polyline',points:paths[0],loops:paths.slice(1),closed:true,filled:true});else for(const p of paths)append(output,{...common,id:uid(),kind:'polyline',points:p,closed:true});break;}
    default:unknown.set(r.type,(unknown.get(r.type)??0)+1);
   }
   if(e&&samples(e).length&&samples(e).every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))append(output,e);
  }
 }
 visit(raw.entities);
 // Detect discarded unsupported records without pretending the drawing is complete.
 const known=new Set(['LINE','LWPOLYLINE','POLYLINE','VERTEX','SEQEND','CIRCLE','ARC','ELLIPSE','TEXT','MTEXT','ATTRIB','ATTDEF','SOLID','3DFACE','SPLINE','POINT','INSERT','DIMENSION','HATCH','MULTILEADER','MLEADER','ENDBLK','ENDSEC','VIEWPORT']);
 const sec=text.split(/\r?\n\s*2\s*\r?\nENTITIES\s*\r?\n/)[1]?.split(/\r?\n\s*0\s*\r?\nENDSEC/)[0]??'';for(const match of sec.matchAll(/(?:^|\r?\n)\s*0\s*\r?\n(3D[A-Z0-9_]+|[A-Z][A-Z0-9_]+)/g))if(!known.has(match[1]))unknown.set(match[1],(unknown.get(match[1])??0)+1);
 for(const [t,n] of unknown)warnings.add(`${t}: ${n} неподдржани објекти.`);if(leaderSeen)warnings.add('MULTILEADER ознаките се претворени во групирани 2D линии, стрелки и текст.');if(approximated)warnings.add('Spline и заоблените полилинии се претворени во сегменти.');if(hatchSeen)warnings.add('Шрафурите се прикажуваат како контури, без шаблонот за полнење.');
 if(entities.some(e=>e.kind==='text'))warnings.add('Текстот користи DejaVu Sans; оригиналните SHX фонтови не се вчитуваат.');
 const layerNames=new Set(layers.map(l=>l.name));for(const e of entities)if(!layerNames.has(e.layer)){layerNames.add(e.layer);layers.push({name:e.layer,color:'#d9e3eb',visible:true,locked:false,plot:true,lineWidth:.25});}
 const code=raw.header?.$INSUNITS,unit=code===4?'mm':code===5?'cm':code===6?'m':code===1?'in':'mm';if(![1,4,5,6].includes(code))warnings.add('Единиците не се препознаени. Поставени се mm; провери ги пред плотирање.');
 if(!entities.length)throw Error('Нема поддржана 2D геометрија во Model Space на овој цртеж.');
 return {name:name.replace(/\.(dxf|dwg)$/i,''),entities,layers,unit,warnings:[...warnings],source};
}
