import { apply, Bounds, bounds, center, distance, Entity, IDENTITY, Matrix, multiply, Point, point, polyline, rotation, samples, scaling, translation, uid } from './model';
const EPS = 1e-8;
const add = (a: Point, b: Point) => point(a.x + b.x, a.y + b.y);
const sub = (a: Point, b: Point) => point(a.x - b.x, a.y - b.y);
const mul = (a: Point, t: number) => point(a.x * t, a.y * t);
const dot = (a: Point, b: Point) => a.x * b.x + a.y * b.y;
const cross = (a: Point, b: Point) => a.x * b.y - a.y * b.x;
const unit = (a: Point) => {
    const n = Math.hypot(a.x, a.y);
    if (n < EPS)
        throw Error('Точките мора да се разликуваат.');
    return mul(a, 1 / n);
};
export function lineIntersection(a: Point, b: Point, c: Point, d: Point, finiteA = false, finiteB = false) {
    const u = sub(b, a), v = sub(d, c), den = cross(u, v);
    if (Math.abs(den) < EPS)
        return undefined;
    const w = sub(c, a), t = cross(w, v) / den, s = cross(w, u) / den;
    if ((finiteA && (t < -EPS || t > 1 + EPS)) || (finiteB && (s < -EPS || s > 1 + EPS)))
        return undefined;
    return { point: add(a, mul(u, t)), t, s };
}
export function worldEntity(e: Entity): Entity {
    if (e.kind === 'polyline')
        return { ...e, matrix: [...IDENTITY], points: (e.points ?? []).map(p => apply(e.matrix, p)), loops: e.loops?.map(loop => loop.map(p => apply(e.matrix, p))) };
    if (e.kind === 'point')
        return { ...e, matrix: [...IDENTITY], center: apply(e.matrix, e.center ?? point(0, 0)) };
    const [a, b, c, d] = e.matrix, scale = Math.hypot(a, b), sim = Math.abs(a * c + b * d) < EPS * Math.max(1, scale * scale) && Math.abs(scale - Math.hypot(c, d)) < EPS * Math.max(1, scale) && a * d - b * c > 0;
    if (sim && (e.kind === 'circle' || e.kind === 'arc'))
        return { ...e, matrix: [...IDENTITY], center: apply(e.matrix, e.center ?? point(0, 0)), radius: (e.radius ?? 1) * scale, start: (e.start ?? 0) + Math.atan2(b, a), end: (e.end ?? Math.PI * 2) + Math.atan2(b, a) };
    if (sim && e.kind === 'text')
        return { ...e, matrix: [...IDENTITY], center: apply(e.matrix, e.center ?? point(0, 0)), height: (e.height ?? 2.5) * scale, rotation: (e.rotation ?? 0) + Math.atan2(b, a) };
    return { ...e, kind: 'polyline', matrix: [...IDENTITY], points: samples(e), closed: e.closed || e.kind === 'circle' || (e.kind === 'ellipse' && !e.start && !e.end) };
}
function path(e: Entity) {
    let points = samples(e);
    if (e.closed || e.kind === 'circle' || (e.kind === 'ellipse' && (e.end ?? Math.PI * 2) - (e.start ?? 0) >= Math.PI * 2 - EPS)) {
        if (distance(points[0], points[points.length - 1]) > EPS)
            points = [...points, points[0]];
    }
    const stations = [0];
    for (let i = 1; i < points.length; i++)
        stations.push(stations[i - 1] + distance(points[i - 1], points[i]));
    return { points, stations, total: stations[stations.length - 1] ?? 0 };
}
function projectPath(e: Entity, p: Point) {
    const data = path(e);
    let best = { station: 0, dist: Infinity, point: data.points[0] ?? point(0, 0), index: 0 };
    for (let i = 1; i < data.points.length; i++) {
        const a = data.points[i - 1], b = data.points[i], u = sub(b, a), l = dot(u, u), t = l ? Math.max(0, Math.min(1, dot(sub(p, a), u) / l)) : 0, q = add(a, mul(u, t)), dist = distance(p, q);
        if (dist < best.dist)
            best = { station: data.stations[i - 1] + t * Math.sqrt(l), dist, point: q, index: i - 1 };
    }
    return { ...data, ...best };
}
function at(data: ReturnType<typeof path>, s: number) {
    for (let i = 1; i < data.stations.length; i++)
        if (s <= data.stations[i] + EPS) {
            const len = data.stations[i] - data.stations[i - 1];
            return add(data.points[i - 1], mul(sub(data.points[i], data.points[i - 1]), len ? (s - data.stations[i - 1]) / len : 0));
        }
    return data.points[data.points.length - 1];
}
function slice(e: Entity, a: number, b: number): Entity | null {
    const data = path(e);
    if (b - a < EPS)
        return null;
    const pts = [at(data, a), ...data.points.filter((_, i) => data.stations[i] > a + EPS && data.stations[i] < b - EPS), at(data, b)];
    return { ...polyline(pts, e.layer), color: e.color, lineWidth: e.lineWidth, dash: e.dash, sourceType: e.sourceType };
}
export function intersections(e: Entity, cutters: Entity[]) {
    const data = path(e), result: number[] = [];
    for (let i = 1; i < data.points.length; i++)
        for (const cutter of cutters) {
            if (cutter.id === e.id || cutter.kind === 'text' || cutter.kind === 'point')
                continue;
            const other = path(cutter);
            for (let j = 1; j < other.points.length; j++) {
                const q = lineIntersection(data.points[i - 1], data.points[i], other.points[j - 1], other.points[j], true, true);
                if (q)
                    result.push(data.stations[i - 1] + q.t * (data.stations[i] - data.stations[i - 1]));
            }
        }
    return [...new Set(result.map(n => Math.round(n * 1e7) / 1e7))].filter(s => s > EPS && s < data.total - EPS).sort((a, b) => a - b);
}
export function trim(e: Entity, cutters: Entity[], pick: Point): Entity[] {
    if (e.kind === 'text' || e.kind === 'point' || e.filled)
        throw Error('TRIM бара линија, полилинија или крива.');
    const p = projectPath(e, pick), cuts = intersections(e, cutters);
    if (!cuts.length)
        throw Error('Нема пресек со границите. Избери објект што ги пресекува.');
    const all = [0, ...cuts, p.total];
    let i = all.findIndex((s, j) => j < all.length - 1 && p.station >= s - EPS && p.station < all[j + 1] - EPS);
    if (i < 0)
        i = all.length - 2;
    const closed = e.closed || e.kind === 'circle' || distance(p.points[0], p.points[p.points.length - 1]) < EPS;
    if (closed && (i === 0 || i === all.length - 2)) {
        return [slice(e, cuts[0], cuts[cuts.length - 1])].filter(Boolean) as Entity[];
    }
    const first = slice(e, 0, all[i]), last = slice(e, all[i + 1], p.total);
    if (closed && first && last) {
        return [{ ...last, points: [...last.points!, ...first.points!.slice(1)] }];
    }
    return [first, last].filter(Boolean) as Entity[];
}
export function extend(e: Entity, cutters: Entity[], pick: Point): Entity {
    const w = worldEntity(e);
    if (w.kind !== 'polyline' || w.closed || (w.points?.length ?? 0) < 2)
        throw Error('EXTEND работи со отворена линија или полилинија.');
    const pts = [...w.points!], start = distance(pick, pts[0]) < distance(pick, pts[pts.length - 1]), end = start ? pts[0] : pts[pts.length - 1], inside = start ? pts[1] : pts[pts.length - 2];
    let best: Point | undefined, nearest = Infinity;
    for (const cut of cutters) {
        if (cut.id === e.id)
            continue;
        const data = path(cut);
        for (let i = 1; i < data.points.length; i++) {
            const q = lineIntersection(inside, end, data.points[i - 1], data.points[i], false, true);
            if (q && q.t > 1 + EPS && distance(end, q.point) < nearest) {
                nearest = distance(end, q.point);
                best = q.point;
            }
        }
    }
    if (!best)
        throw Error('Нема граница во правецот на продолжувањето.');
    pts[start ? 0 : pts.length - 1] = best;
    return { ...w, points: pts };
}
export function offset(e: Entity, amount: number, side: Point): Entity {
    if (!Number.isFinite(amount) || amount <= 0)
        throw Error('OFFSET растојанието мора да биде позитивно.');
    const w = worldEntity(e);
    if (e.filled)
        throw Error('OFFSET бара контурна линија, а не пополнување.');
    if (w.kind === 'circle' || w.kind === 'arc') {
        const c = w.center!, r = w.radius!, sign = distance(c, side) < r ? -1 : 1;
        if (r + amount * sign <= EPS)
            throw Error('Офсетот го намалува радиусот под нула.');
        return { ...w, id: uid(), radius: r + amount * sign, blockId: undefined, blockName: undefined, groupId: undefined };
    }
    if (w.kind !== 'polyline' || !w.points || w.points.length < 2)
        throw Error('OFFSET работи со линии, полилинии, кругови и лакови.');
    const p = [...w.points];
    if (w.closed && distance(p[0], p[p.length - 1]) < EPS)
        p.pop();
    const near = projectPath(w, side), dir = unit(sub(p[(near.index + 1) % p.length], p[near.index % p.length])), sign = cross(dir, sub(side, near.point)) >= 0 ? 1 : -1;
    const segments: Array<[
        Point,
        Point
    ]> = [];
    for (let i = 0; i < (w.closed ? p.length : p.length - 1); i++) {
        const a = p[i], b = p[(i + 1) % p.length], u = unit(sub(b, a)), n = point(-u.y * amount * sign, u.x * amount * sign);
        segments.push([add(a, n), add(b, n)]);
    }
    const points: Point[] = [];
    for (let i = 0; i < p.length; i++) {
        if (!w.closed && i === 0) {
            points.push(segments[0][0]);
            continue;
        }
        if (!w.closed && i === p.length - 1) {
            points.push(segments[segments.length - 1][1]);
            continue;
        }
        const prev = segments[(i - 1 + segments.length) % segments.length], next = segments[i % segments.length], q = lineIntersection(...prev, ...next);
        const joined = q?.point ?? next[0];
        if (distance(joined, p[i]) > amount * 100)
            throw Error('Острите агли создаваат нестабилен офсет.');
        points.push(joined);
    }
    return { ...w, id: uid(), points, blockId: undefined, blockName: undefined, groupId: undefined };
}
function linePair(a: Entity, b: Entity) {
    const x = worldEntity(a), y = worldEntity(b);
    if (x.kind !== 'polyline' || y.kind !== 'polyline' || x.points?.length !== 2 || y.points?.length !== 2 || x.closed || y.closed)
        throw Error('Избери две прави линии.');
    const q = lineIntersection(x.points[0], x.points[1], y.points[0], y.points[1]);
    if (!q)
        throw Error('Паралелни линии не формираат агол.');
    const i = q.point, farA = distance(i, x.points[0]) > distance(i, x.points[1]) ? 0 : 1, farB = distance(i, y.points[0]) > distance(i, y.points[1]) ? 0 : 1, u = unit(sub(x.points[farA], i)), v = unit(sub(y.points[farB], i));
    return { x, y, i, farA, farB, u, v };
}
export function fillet(a: Entity, b: Entity, radius: number): Entity[] {
    if (radius < 0 || !Number.isFinite(radius))
        throw Error('Радиусот мора да биде нула или позитивен.');
    const { x, y, i, farA, farB, u, v } = linePair(a, b), theta = Math.acos(Math.max(-1, Math.min(1, dot(u, v))));
    if (theta < EPS || Math.PI - theta < EPS)
        throw Error('Линиите не формираат валиден агол.');
    const t = radius / Math.tan(theta / 2);
    if (t > distance(i, x.points![farA]) + EPS || t > distance(i, y.points![farB]) + EPS)
        throw Error('Радиусот е преголем за избраните линии.');
    const p = add(i, mul(u, t)), q = add(i, mul(v, t));
    x.points = x.points!.map((a, j) => j === farA ? a : p);
    y.points = y.points!.map((a, j) => j === farB ? a : q);
    if (radius === 0)
        return [x, y];
    const c = add(i, mul(unit(add(u, v)), radius / Math.sin(theta / 2)));
    let start = Math.atan2(p.y - c.y, p.x - c.x), end = Math.atan2(q.y - c.y, q.x - c.x);
    const delta = ((end - start) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    if (delta > Math.PI)
        [start, end] = [end, start];
    while (end <= start)
        end += Math.PI * 2;
    return [x, y, { id: uid(), kind: 'arc', matrix: [...IDENTITY], layer: a.layer, color: a.color, lineWidth: a.lineWidth, center: c, radius, start, end }];
}
export function chamfer(a: Entity, b: Entity, first: number, second: number): Entity[] {
    if (!Number.isFinite(first) || !Number.isFinite(second) || first < 0 || second < 0)
        throw Error('Внеси позитивни растојанија.');
    const { x, y, i, farA, farB, u, v } = linePair(a, b);
    if (first > distance(i, x.points![farA]) + EPS || second > distance(i, y.points![farB]) + EPS)
        throw Error('Растојанието е подолго од линијата.');
    const p = add(i, mul(u, first)), q = add(i, mul(v, second));
    x.points = x.points!.map((a, j) => j === farA ? a : p);
    y.points = y.points!.map((a, j) => j === farB ? a : q);
    return [x, y, ...(distance(p, q) > EPS ? [polyline([p, q], a.layer)] : [])];
}
export function breakPath(e: Entity, a: Point, b: Point): Entity[] {
    if (e.kind === 'text' || e.kind === 'point' || e.filled)
        throw Error('BREAK бара линија или крива.');
    const p = projectPath(e, a), q = projectPath(e, b), lo = Math.min(p.station, q.station), hi = Math.max(p.station, q.station);
    if (e.closed || e.kind === 'circle') {
        const first = slice(e, 0, lo), last = slice(e, hi, p.total);
        if (first && last)
            return [{ ...last, points: [...last.points!, ...first.points!.slice(1)] }];
        return [first, last].filter(Boolean) as Entity[];
    }
    return [slice(e, 0, lo), slice(e, hi, p.total)].filter(Boolean) as Entity[];
}
export function join(entities: Entity[], tolerance = .001): Entity {
    if (entities.length < 2)
        throw Error('Избери најмалку две поврзани линии или полилинии.');
    const paths = entities.map(e => worldEntity(e));
    if (paths.some(e => e.kind !== 'polyline' || e.closed || !e.points?.length))
        throw Error('JOIN бара отворени линии или полилинии.');
    let pts = [...paths.shift()!.points!];
    while (paths.length) {
        let matched = false;
        for (let i = 0; i < paths.length; i++) {
            const p = paths[i].points!;
            if (distance(pts[pts.length - 1], p[0]) <= tolerance)
                pts.push(...p.slice(1));
            else if (distance(pts[pts.length - 1], p[p.length - 1]) <= tolerance)
                pts.push(...[...p].reverse().slice(1));
            else if (distance(pts[0], p[p.length - 1]) <= tolerance)
                pts = [...p.slice(0, -1), ...pts];
            else if (distance(pts[0], p[0]) <= tolerance)
                pts = [...[...p].reverse().slice(0, -1), ...pts];
            else
                continue;
            paths.splice(i, 1);
            matched = true;
            break;
        }
        if (!matched)
            throw Error('Објектите не се поврзани во една патека.');
    }
    const closed = distance(pts[0], pts[pts.length - 1]) <= tolerance;
    if (closed)
        pts.pop();
    return { ...polyline(pts, entities[0].layer, closed), color: entities[0].color, lineWidth: entities[0].lineWidth };
}
export function explode(e: Entity): Entity[] {
    const w = worldEntity(e);
    if (e.groupId || e.blockId)
        return [{ ...e, groupId: undefined, blockId: undefined, blockName: undefined }];
    if (w.kind !== 'polyline')
        return [e];
    const out: Entity[] = [];
    for (const pts of [w.points ?? [], ...(w.loops ?? [])]) {
        for (let i = 1; i < pts.length; i++)
            out.push({ ...polyline([pts[i - 1], pts[i]], e.layer), color: e.color, lineWidth: e.lineWidth, dash: e.dash });
        if (w.closed && pts.length > 2)
            out.push({ ...polyline([pts[pts.length - 1], pts[0]], e.layer), color: e.color, lineWidth: e.lineWidth, dash: e.dash });
    }
    return out;
}
export function stretch(entities: Entity[], box: Bounds, delta: Point) {
    const inside = (p: Point) => p.x >= box.minX - EPS && p.x <= box.maxX + EPS && p.y >= box.minY - EPS && p.y <= box.maxY + EPS;
    return entities.map(e => {
        if (e.kind === 'polyline') {
            const w = worldEntity(e);
            return { ...w, points: w.points!.map(p => inside(p) ? add(p, delta) : p), loops: w.loops?.map(loop => loop.map(p => inside(p) ? add(p, delta) : p)) };
        }
        if (e.center && inside(apply(e.matrix, e.center)))
            return { ...e, matrix: multiply(translation(delta.x, delta.y), e.matrix) };
        return e;
    });
}
export function alignMatrix(source1: Point, source2: Point, dest1: Point, dest2: Point, rescale = false): Matrix {
    const a = sub(source2, source1), b = sub(dest2, dest1), l = distance(source1, source2), n = distance(dest1, dest2);
    if (l < EPS || n < EPS)
        throw Error('Парот точки мора да има различни координати.');
    return multiply(translation(dest1.x - source1.x, dest1.y - source1.y), multiply(rotation((Math.atan2(b.y, b.x) - Math.atan2(a.y, a.x)) * 180 / Math.PI, source1), scaling(rescale ? n / l : 1, source1)));
}
export function arrayRect(entities: Entity[], rows: number, columns: number, dx: number, dy: number): Entity[] {
    if (!Number.isInteger(rows) || !Number.isInteger(columns) || rows < 1 || columns < 1 || rows * columns < 2 || rows * columns * entities.length > 30000 || !Number.isFinite(dx) || !Number.isFinite(dy))
        throw Error('Внеси позитивни редови/колони; максимум 30 000 резултатни објекти.');
    const out: Entity[] = [];
    for (let r = 0; r < rows; r++)
        for (let c = 0; c < columns; c++)
            if (r || c) {
                const groups = new Map<string, string>();
                out.push(...entities.map(e => clone(e, translation(c * dx, r * dy), groups)));
            }
    return out;
}
function clone(e: Entity, m: Matrix, groups = new Map<string, string>()): Entity {
    const fresh = (id?: string) => {
        if (!id)
            return undefined;
        if (!groups.has(id))
            groups.set(id, uid());
        return groups.get(id);
    };
    return { ...e, id: uid(), matrix: multiply(m, e.matrix), groupId: fresh(e.groupId), blockId: fresh(e.blockId) };
}
export function arrayPolar(entities: Entity[], count: number, c: Point, angle: number, rotateItems = true): Entity[] {
    if (!Number.isInteger(count) || count < 2 || count * entities.length > 30000 || !Number.isFinite(angle) || !Number.isFinite(c.x) || !Number.isFinite(c.y))
        throw Error('Внеси број од 2 нагоре; максимум 30 000 резултатни објекти.');
    const pivot = center(bounds(entities)), full = Math.abs(Math.abs(angle) - 360) < EPS, step = angle / (full ? count : count - 1), out: Entity[] = [];
    for (let i = 1; i < count; i++) {
        const m = rotation(step * i, c), rotated = apply(m, pivot), transform = rotateItems ? m : translation(rotated.x - pivot.x, rotated.y - pivot.y);
        const groups = new Map<string, string>();
        out.push(...entities.map(e => clone(e, transform, groups)));
    }
    return out;
}
export function polygon(c: Point, r: number, n: number, layer: string, angle = 0) {
    if (!Number.isInteger(n) || n < 3 || n > 1024 || !Number.isFinite(r) || r <= 0)
        throw Error('POLYGON бара 3–1024 страни и позитивен радиус.');
    return polyline(Array.from({ length: n }, (_, i) => point(c.x + r * Math.cos(angle + i * 2 * Math.PI / n), c.y + r * Math.sin(angle + i * 2 * Math.PI / n))), layer, true);
}
export function spline(points: Point[], layer: string, closed = false) {
    if (points.length < 3)
        throw Error('SPLINE бара најмалку три точки.');
    const out: Point[] = [];
    for (let i = 0; i < (closed ? points.length : points.length - 1); i++) {
        const p0 = points[(i - 1 + points.length) % points.length], p1 = points[i], p2 = points[(i + 1) % points.length], p3 = points[(i + 2) % points.length];
        const a = !closed && i === 0 ? p1 : p0, d = !closed && i === points.length - 2 ? p2 : p3;
        for (let j = 0; j < 20; j++) {
            const t = j / 20, t2 = t * t, t3 = t2 * t;
            const coord = (axis: 'x' | 'y') => .5 * ((2 * p1[axis]) + (-a[axis] + p2[axis]) * t + (2 * a[axis] - 5 * p1[axis] + 4 * p2[axis] - d[axis]) * t2 + (-a[axis] + 3 * p1[axis] - 3 * p2[axis] + d[axis]) * t3);
            out.push(point(coord('x'), coord('y')));
        }
    }
    if (!closed)
        out.push(points[points.length - 1]);
    return { ...polyline(out, layer, closed), sourceType: 'SPLINE' };
}
export function areaPerimeter(e: Entity) { const w = worldEntity(e); if (w.kind === 'circle')
    return { area: Math.PI * w.radius! ** 2, perimeter: 2 * Math.PI * w.radius!, closed: true }; const data = path(e), loops = [data.points, ...(w.loops ?? [])]; const closed = !!(e.closed || e.kind === 'ellipse'); let area = 0, perimeter = data.total; function contains(loop: Point[], q: Point) { let inside = false; for (let i = 0, j = loop.length - 1; i < loop.length; j = i++) {
    const a = loop[i], b = loop[j];
    if ((a.y > q.y) !== (b.y > q.y) && q.x < (b.x - a.x) * (q.y - a.y) / (b.y - a.y) + a.x)
        inside = !inside;
} return inside; } for (const [index, loop] of loops.entries()) {
    let signed = 0;
    for (let i = 0; i < loop.length; i++)
        signed += cross(loop[i], loop[(i + 1) % loop.length]);
    const depth = loops.filter((other, j) => j !== index && loop.length && contains(other, loop[0])).length;
    area += Math.abs(signed / 2) * (depth % 2 ? -1 : 1);
    if (index) {
        for (let i = 0; i < loop.length; i++)
            perimeter += distance(loop[i], loop[(i + 1) % loop.length]);
    }
} return { area: Math.abs(area), perimeter, closed }; }
export function hatch(e: Entity, pattern: 'solid' | 'ansi31' | 'cross', spacing: number, angle: number, layer: string): Entity[] {
    const w = worldEntity(e);
    if (!w.closed && w.kind !== 'circle' && w.kind !== 'ellipse')
        throw Error('HATCH бара затворена граница.');
    if (w.kind !== 'polyline')
        w.points = samples(w);
    const points = w.points!;
    if (pattern === 'solid')
        return [{ ...polyline(points, layer, true), filled: true, loops: w.loops, sourceType: 'HATCH' }];
    if (!Number.isFinite(spacing) || spacing <= 0)
        throw Error('Растојанието на шрафурата мора да биде позитивно.');
    const out: Entity[] = [];
    for (const deg of pattern === 'cross' ? [angle, angle + 90] : [angle]) {
        if (!Number.isFinite(deg))
            throw Error('Внеси валиден агол.');
        const m = rotation(-deg, point(0, 0)), contours = [points, ...(w.loops ?? [])].map(loop => loop.map(q => apply(m, q))), p = contours.flat(), min = p.reduce((n, q) => Math.min(n, q.y), Infinity), max = p.reduce((n, q) => Math.max(n, q.y), -Infinity);
        if ((max - min) / spacing > 2000)
            throw Error('Премала скала на шрафура. Зголеми го растојанието.');
        for (let y = Math.ceil(min / spacing) * spacing; y < max - EPS; y += spacing) {
            const cuts: number[] = [];
            for (const loop of contours)
                for (let i = 0; i < loop.length; i++) {
                    const a = loop[i], b = loop[(i + 1) % loop.length];
                    if ((a.y <= y && b.y > y) || (b.y <= y && a.y > y))
                        cuts.push(a.x + (y - a.y) * (b.x - a.x) / (b.y - a.y));
                }
            cuts.sort((a, b) => a - b);
            for (let i = 1; i < cuts.length; i += 2) {
                out.push({ ...polyline([apply(rotation(deg, point(0, 0)), point(cuts[i - 1], y)), apply(rotation(deg, point(0, 0)), point(cuts[i], y))], layer), sourceType: 'HATCH' });
                if (out.length > 10000)
                    throw Error('Шрафурата има премногу сегменти.');
            }
        }
    }
    const groupId = uid();
    return out.map(e => ({ ...e, groupId }));
}
export function pathMarkers(e: Entity, value: number, byDistance = false): Entity[] {
    const p = path(e);
    if (value <= 0 || !Number.isFinite(value) || (!byDistance && !Number.isInteger(value)))
        throw Error('Внеси позитивна вредност.');
    const step = byDistance ? value : p.total / value, count = Math.ceil(p.total / step) - 1;
    if (count > 10000)
        throw Error('Максимум 10 000 точки.');
    const out: Entity[] = [];
    for (let s = step; s < p.total - EPS; s += step)
        out.push({ id: uid(), kind: 'point', matrix: [...IDENTITY], center: at(p, s), layer: e.layer });
    return out;
}
export function lengthen(e: Entity, value: number) {
    const w = worldEntity(e);
    if (w.kind !== 'polyline' || w.points?.length !== 2 || value <= 0 || !Number.isFinite(value))
        throw Error('LENGTHEN бара права линија и позитивна должина.');
    return { ...w, points: [w.points[0], add(w.points[0], mul(unit(sub(w.points[1], w.points[0])), value))] };
}
export function dimension(a: Point, b: Point, placement: Point, layer: string, height: number, mode: 'aligned' | 'linear' = 'aligned'): Entity[] {
    const h = height;
    if (distance(a, b) < EPS)
        throw Error('Точките за кота мора да се разликуваат.');
    let u: Point, p: Point, q: Point, len: number;
    if (mode === 'linear') {
        const horizontal = Math.abs(placement.y - (a.y + b.y) / 2) > Math.abs(placement.x - (a.x + b.x) / 2);
        u = horizontal ? point(1, 0) : point(0, 1);
        p = horizontal ? point(a.x, placement.y) : point(placement.x, a.y);
        q = horizontal ? point(b.x, placement.y) : point(placement.x, b.y);
        len = horizontal ? Math.abs(b.x - a.x) : Math.abs(b.y - a.y);
    }
    else {
        u = unit(sub(b, a));
        const n = point(-u.y, u.x), off = dot(sub(placement, a), n);
        p = add(a, mul(n, off));
        q = add(b, mul(n, off));
        len = distance(a, b);
    }
    const n = point(-u.y, u.x), tick = (c: Point) => polyline([add(c, point(-h * .4, -h * .4)), add(c, point(h * .4, h * .4))], layer), groupId = uid();
    let ang = Math.atan2(u.y, u.x);
    if (ang > Math.PI / 2 || ang < -Math.PI / 2)
        ang += Math.PI;
    return [polyline([a, add(p, mul(n, h * .5))], layer), polyline([b, add(q, mul(n, h * .5))], layer), polyline([p, q], layer), tick(p), tick(q), { id: uid(), kind: 'text' as const, layer, matrix: [...IDENTITY] as Matrix, center: add(mul(add(p, q), .5), mul(n, h * .4)), height: h, text: len.toLocaleString('en-US', { maximumFractionDigits: 2 }), rotation: ang, align: 'center' as const }].map(e => ({ ...e, groupId, sourceType: 'DIMENSION' }));
}
export function radialDimension(e: Entity, pick: Point, layer: string, height: number, diameter = false): Entity[] {
    const w = worldEntity(e);
    if (w.kind !== 'circle' && w.kind !== 'arc')
        throw Error('Избери круг или лак.');
    const c = w.center!, r = w.radius!, u = unit(sub(pick, c)), edge = add(c, mul(u, r)), start = diameter ? add(c, mul(u, -r)) : c, groupId = uid();
    return [polyline([start, edge, pick], layer), polyline([edge, add(edge, mul(u, -height)), add(edge, mul(point(-u.y, u.x), height * .3)), edge], layer), { id: uid(), kind: 'text' as const, layer, matrix: [...IDENTITY] as Matrix, center: add(pick, point(height * .3, height * .3)), height, text: (diameter ? '⌀' : 'R') + (r * (diameter ? 2 : 1)).toLocaleString('en-US', { maximumFractionDigits: 2 }) }].map(e => ({ ...e, groupId, sourceType: 'DIMENSION' }));
}
export function angularDimension(a: Entity, b: Entity, pick: Point, layer: string, height: number): Entity[] {
    const { i, u, v } = linePair(a, b), r = distance(i, pick);
    if (r < EPS)
        throw Error('Избери позиција подалеку од пресекот.');
    let start = Math.atan2(u.y, u.x), end = Math.atan2(v.y, v.x);
    while (end <= start)
        end += Math.PI * 2;
    if (end - start > Math.PI) {
        [start, end] = [end, start + Math.PI * 2];
    }
    const mid = (start + end) / 2, c = add(i, mul(point(Math.cos(mid), Math.sin(mid)), r + height)), groupId = uid();
    return [{ id: uid(), kind: 'arc' as const, layer, matrix: [...IDENTITY] as Matrix, center: i, radius: r, start, end }, polyline([i, add(i, mul(point(Math.cos(start), Math.sin(start)), r + height))], layer), polyline([i, add(i, mul(point(Math.cos(end), Math.sin(end)), r + height))], layer), { id: uid(), kind: 'text' as const, layer, matrix: [...IDENTITY] as Matrix, center: c, height, text: ((end - start) * 180 / Math.PI).toFixed(2) + '°', align: 'center' as const }].map(e => ({ ...e, groupId, sourceType: 'DIMENSION' }));
}
export function deduplicate(entities: Entity[], tolerance = .0001) {
    const seen = new Set<string>();
    return entities.filter(e => {
        const w = worldEntity(e), v = samples(w).map(p => `${Math.round(p.x / tolerance)},${Math.round(p.y / tolerance)}`);
        const forward = v.join(';'), back = [...v].reverse().join(';'), key = `${e.layer}|${e.kind}|${e.text ?? ''}|${e.filled ?? false}|${e.color ?? ''}|${e.lineWidth ?? ''}|${e.dash ?? ''}|${JSON.stringify(w.loops ?? [])}|${forward < back ? forward : back}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
}
